/**
 * 
 */
package org.jvnet.flamingo.common;

import javax.swing.ButtonModel;

public interface PopupButtonModel extends ButtonModel {
	/**
	 * Adds an <code>PopupActionListener</code> to the model.
	 * 
	 * @param l
	 *            the listener to add
	 */
	void addPopupActionListener(PopupActionListener l);

	/**
	 * Removes an <code>PopupActionListener</code> from the model.
	 * 
	 * @param l
	 *            the listener to remove
	 */
	void removePopupActionListener(PopupActionListener l);

	void setPopupPressed(boolean b);

	boolean isPopupPressed();
}