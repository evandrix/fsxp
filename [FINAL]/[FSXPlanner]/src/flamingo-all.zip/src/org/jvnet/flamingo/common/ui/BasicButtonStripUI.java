/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common.ui;

import java.awt.*;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;

import org.jvnet.flamingo.common.JButtonStrip;
import org.jvnet.flamingo.common.JButtonStrip.StripOrientation;

/**
 * Basic UI for button strip {@link JButtonStrip}.
 * 
 * @author Kirill Grouchnikov
 */
public class BasicButtonStripUI extends ButtonStripUI {
	/**
	 * The associated button strip.
	 */
	protected JButtonStrip buttonStrip;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicButtonStripUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#installUI(javax.swing.JComponent)
	 */
	@Override
	public void installUI(JComponent c) {
		this.buttonStrip = (JButtonStrip) c;
		c.setLayout(createLayoutManager());
		c.setBorder(new EmptyBorder(0, 0, 0, 0));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		c.setLayout(null);

		this.buttonStrip = null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void paint(Graphics g, JComponent c) {
		int buttonCount = this.buttonStrip.getButtonCount();
		Insets insets = c.getInsets();
		for (int i = 0; i < buttonCount; i++) {
			AbstractButton currButton = this.buttonStrip.getButton(i);
			boolean isFirst = this.buttonStrip.isFirst(currButton);
			boolean isLast = this.buttonStrip.isLast(currButton);
			Graphics2D graphics = (Graphics2D) g.create(currButton.getX(),
					currButton.getY(), currButton.getWidth(), currButton
							.getHeight());
			if (this.buttonStrip.getOrientation() == StripOrientation.HORIZONTAL) {
				this.paintStripButton(graphics, currButton, isFirst, isLast, c
						.getWidth()
						- insets.left - insets.right, currButton.getX());
			} else {
				this.paintStripButton(graphics, currButton, isFirst, isLast, c
						.getHeight()
						- insets.top - insets.bottom, currButton.getY());
			}
			graphics.dispose();
		}
	}

	/**
	 * Paints a single strip button. This function should provide continuous
	 * appearance throughout the whole strip (especially if the painting uses
	 * gradients).
	 * 
	 * @param g
	 *            Graphics context.
	 * @param button
	 *            The button itself.
	 * @param isFirst
	 *            If <code>true</code>, the button is the first button in its
	 *            strip.
	 * @param isLast
	 *            If <code>true</code>, the button is the last button in its
	 *            strip.
	 * @param totalStripDimension
	 *            The total width / height of the button strip in pixels.
	 * @param relativeOffset
	 *            The location of the button relative to the strip.
	 */
	protected void paintStripButton(Graphics g, AbstractButton button,
			boolean isFirst, boolean isLast, int totalStripDimension,
			int relativeOffset) {
		this.paintStripButtonBackground(g, button, isFirst, isLast,
				totalStripDimension, relativeOffset);

		this.paintButtonContents(g, button);

		this.paintStripButtonBorder(g, button, isFirst, isLast);
	}

	/**
	 * Paints the button contents.
	 * 
	 * @param g
	 *            Graphics context.
	 * @param button
	 *            Button to paint.
	 */
	protected void paintButtonContents(Graphics g, AbstractButton button) {
		button.paint(g);
	}

	/**
	 * Paints background of a single strip button. This function should provide
	 * continuous appearance throughout the whole strip (especially if the
	 * painting uses gradients).
	 * 
	 * @param g
	 *            Graphics context.
	 * @param button
	 *            The button itself.
	 * @param isFirst
	 *            If <code>true</code>, the button is the first button in its
	 *            strip.
	 * @param isLast
	 *            If <code>true</code>, the button is the last button in its
	 *            strip.
	 * @param totalStripDimension
	 *            The total width / height of the button strip in pixels.
	 * @param relativeOffset
	 *            The location of the button relative to the strip.
	 */
	protected void paintStripButtonBackground(Graphics g,
			AbstractButton button, boolean isFirst, boolean isLast,
			int totalStripDimension, int relativeOffset) {
		if (button.isOpaque()) {
			g.setColor(button.getBackground());
			g.fillRect(0, 0, button.getWidth(), button.getHeight());
		}
	}

	/**
	 * Paints border of a single strip button. This function should provide
	 * continuous appearance throughout the whole strip.
	 * 
	 * @param g
	 *            Graphics context.
	 * @param button
	 *            The button itself.
	 * @param isFirst
	 *            If <code>true</code>, the button is the first button in its
	 *            strip.
	 * @param isLast
	 *            If <code>true</code>, the button is the last button in its
	 *            strip.
	 */
	protected void paintStripButtonBorder(Graphics g, AbstractButton button,
			boolean isFirst, boolean isLast) {
		Border border = button.getBorder();
		if (border != null)
			border.paintBorder(button, g, 0, 0, button.getWidth(), button
					.getHeight());
	}

	/**
	 * Invoked by <code>installUI</code> to create a layout manager object to
	 * manage the {@link JButtonStrip}.
	 * 
	 * @return a layout manager object
	 */
	protected LayoutManager createLayoutManager() {
		return new ButtonStripLayout();
	}

	/**
	 * Layout for the button strip.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class ButtonStripLayout implements LayoutManager {
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container c) {
			int width = 0;
			int height = 0;
			if (buttonStrip.getOrientation() == StripOrientation.HORIZONTAL) {
				for (int i = 0; i < buttonStrip.getButtonCount(); i++) {
					width += buttonStrip.getButton(i).getPreferredSize().width;
					height = Math.max(height, buttonStrip.getButton(i)
							.getPreferredSize().height);
				}
			} else {
				for (int i = 0; i < buttonStrip.getButtonCount(); i++) {
					height += buttonStrip.getButton(i).getPreferredSize().height;
					width = Math.max(width, buttonStrip.getButton(i)
							.getPreferredSize().width);
				}
			}
			Insets ins = c.getInsets();
			return new Dimension(width + ins.left + ins.right, height + ins.top
					+ ins.bottom);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container c) {
			return this.preferredLayoutSize(c);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container c) {
			if (buttonStrip.getButtonCount() == 0)
				return;
			Insets ins = c.getInsets();
			int height = c.getHeight() - ins.top - ins.bottom;
			int width = c.getWidth() - ins.left - ins.right;
			if (buttonStrip.getOrientation() == StripOrientation.HORIZONTAL) {
				int totalPreferredWidth = 0;
				for (int i = 0; i < buttonStrip.getButtonCount(); i++) {
					AbstractButton currButton = buttonStrip.getButton(i);
					totalPreferredWidth += currButton.getPreferredSize().width;
				}
				int deltaX = (width - totalPreferredWidth)
						/ buttonStrip.getButtonCount();
				int x = ins.left;
				for (int i = 0; i < buttonStrip.getButtonCount(); i++) {
					AbstractButton currButton = buttonStrip.getButton(i);
					currButton.setBounds(x, ins.top, currButton
							.getPreferredSize().width
							+ deltaX, height);
					x += (currButton.getPreferredSize().width + deltaX);
				}
			} else {
				int totalPreferredHeight = 0;
				for (int i = 0; i < buttonStrip.getButtonCount(); i++) {
					AbstractButton currButton = buttonStrip.getButton(i);
					totalPreferredHeight += currButton.getPreferredSize().height;
				}
				float deltaY = (float) (height - totalPreferredHeight)
						/ (float) buttonStrip.getButtonCount();
				float y = ins.top;
				for (int i = 0; i < buttonStrip.getButtonCount(); i++) {
					AbstractButton currButton = buttonStrip.getButton(i);
					float buttonHeight = (currButton.getPreferredSize().height + deltaY);
					currButton.setBounds(ins.left, (int) y, width, (int) Math
							.ceil(buttonHeight));
					y += buttonHeight;
				}
			}
		}
	}
}
