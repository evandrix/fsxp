/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common;

import java.awt.*;

import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.UIResource;

import org.jvnet.flamingo.utils.FlamingoUtilities;

/**
 * Popup gallery that hosts groups of icons.
 * 
 * @author Kirill Grouchnikov
 */
public class JIconPopupPanel extends JPopupPanel {
	/**
	 * Maximum dimension of <code>this</code> popup gallery.
	 */
	protected Dimension maxDimension;

	protected JCommandButtonPanel iconPanel;

	/**
	 * Scroll panel that hosts {@link #iconPanel}.
	 */
	protected JScrollPane scroll;

	/**
	 * Creates new popup gallery.
	 * 
	 * @param maxWidth
	 *            Maximum width of <code>this</code> popup gallery in pixels.
	 * @param maxHeight
	 *            Maximum height of <code>this</code> popup gallery in pixels.
	 */
	public JIconPopupPanel(JCommandButtonPanel iconPanel, int maxButtonColumns,
			int maxVisibleButtonRows) {
		this.iconPanel = iconPanel;
		this.iconPanel.setMaxButtonColumns(maxButtonColumns);

		int maxButtonWidth = 0;
		int maxButtonHeight = 0;
		int groupCount = iconPanel.getGroupCount();
		for (int i = 0; i < groupCount; i++) {
			for (AbstractCommandButton button : iconPanel.getGroupButtons(i)) {
				maxButtonWidth = Math.max(maxButtonWidth, button
						.getPreferredSize().width);
				maxButtonHeight = Math.max(maxButtonHeight, button
						.getPreferredSize().height);
			}
		}

		Dimension prefIconPanelDim = this.iconPanel.getPreferredSize();
		this.maxDimension = new Dimension(prefIconPanelDim.width,
				maxVisibleButtonRows * maxButtonHeight);

		this.scroll = new JScrollPane(this.iconPanel,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		this.scroll.setBorder(null);
		this.scroll.setOpaque(false);
		this.scroll.getViewport().setOpaque(false);
		this.setLayout(new IconPopupLayout());

		// JViewport viewport = this.scroll.getViewport();
		// viewport.setPreferredSize(new Dimension(maxDimension.width
		// + this.scroll.getVerticalScrollBar().getPreferredSize().width,
		// maxDimension.height));
		// this.setPreferredSize(this.maxDimension);
		this.add(this.scroll);

		Border b = this.getBorder();
		if (b == null || b instanceof UIResource) {
			Border toSet = UIManager.getBorder("PopupGallery.border");
			if (toSet == null)
				toSet = new BorderUIResource.LineBorderUIResource(
						FlamingoUtilities.getColor(Color.gray,
								"TextField.inactiveForeground",
								"Button.disabledText",
								"ComboBox.disabledForeground"));
			this.setBorder(toSet);
		}
	}

	// public int getMaxHeight() {
	// return maxDimension.height;
	// }
	//
	// public int getMaxWidth() {
	// return maxDimension.width;
	// }
	//
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.flamingo.common.AbstractPopupPanel#isEmpty()
	 */
	@Override
	public boolean isEmpty() {
		return (this.iconPanel.getGroupCount() == 0);
	}

	/**
	 * Layout manager for <code>this</code> popup gallery.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class IconPopupLayout implements LayoutManager {
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component comp) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component comp) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container parent) {
			Insets insets = parent.getInsets();
			int left = insets.left;
			int right = insets.right;
			int top = insets.top;
			int bottom = insets.bottom;
			scroll.setBounds(left, top, parent.getWidth() - left - right,
					parent.getHeight() - top - bottom);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container parent) {
			return this.preferredLayoutSize(parent);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container parent) {
			Insets insets = parent.getInsets();
			int left = insets.left;
			int right = insets.right;
			int top = insets.top;
			int bottom = insets.bottom;
			Dimension controlPanelDim = iconPanel.getPreferredSize();
			if (controlPanelDim == null)
				controlPanelDim = new Dimension(0, 0);
			int w = Math.min(controlPanelDim.width, maxDimension.width) + left
					+ right;
			int h = Math.min(controlPanelDim.height, maxDimension.height) + top
					+ bottom;
			if (h == (maxDimension.height + top + bottom)) {
				w += UIManager.getInt("ScrollBar.width");
				// h += 5;
			}
			return new Dimension(w, h);
		}
	}
}
