/*
 * Copyright (c) 2003-2008 Flamingo Kirill Grouchnikov
 * and <a href="http://www.topologi.com">Topologi</a>. 
 * Contributed by <b>Rick Jelliffe</b> of <b>Topologi</b> 
 * in January 2006. in All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov Topologi nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * Created on Nov 10, 2003
 */
package org.jvnet.flamingo.bcb;

import java.awt.Color;
import java.awt.event.MouseListener;
import java.util.*;

import javax.swing.*;

import org.jvnet.flamingo.bcb.ui.BasicBreadcrumbBarUI;
import org.jvnet.flamingo.bcb.ui.BreadcrumbBarUI;
import org.jvnet.flamingo.common.StringValuePair;

/**
 * Breadcrumb bar. It is basically a way of lazily navigating around a tree, but
 * just by manipulating the sections of a path.
 */
public class BreadcrumbBar<T> extends JComponent {
	/**
	 * Serial version ID.
	 */
	private static final long serialVersionUID = 3258407339731400502L;

	/**
	 * Contains the item path (particles and selectors).
	 */
	protected BreadcrumbStack stack;

	/**
	 * Optional main icon for <code>this</code> breadcrumb bar.
	 */
	protected Icon icon;

	/**
	 * Separator for string presentation.
	 */
	protected String separator;

	/**
	 * Optional OK button.
	 */
	protected JButton okButton;

	/**
	 * Optional application callback. If set, will be used to retrieve choices
	 * for the activated selector.
	 */
	protected BreadcrumbBarCallBack<T> callback;

	/**
	 * Underline color for rollover effects.
	 */
	protected Color underlineColor = null;

	/**
	 * Box color for rollover effects.
	 */
	protected Color boxColor = null;

	/**
	 * Listeners on <code>this</code> breadcrumb bar.
	 */
	private List<BreadcrumbBarListener<T>> listeners = null;

	/**
	 * Marks that no events should be passed to listeners.
	 */
	private boolean noEvent = false;

	/**
	 * The popup listener on <code>this</code> breadcrumb bar.
	 */
	private MouseListener popupListener = null;

	protected List<BreadcrumbBarExceptionHandler> exceptionHandlers;

	/**
	 * The UI class ID string.
	 */
	public static final String uiClassID = "BreadcrumbBarUI";

	/**
	 * Base interface for elements in breadcrumb bar.
	 */
	public interface BreadcrumbBarElement {
		/**
		 * Returns the text presentation of <code>this</code> element.
		 * 
		 * @return The text presentation of <code>this</code> element.
		 */
		public String getText();

		/**
		 * Returns the index of <code>this</code> element.
		 * 
		 * @return The index of <code>this</code> element.
		 */
		public int getIndex();
	}

	/**
	 * Sets the popup listener on <code>this</code> breadcrumb bar.
	 * 
	 * @param pl
	 *            Popup listener to set on <code>this</code> breadcrumb bar.
	 */
	public void setPopupListener(MouseListener pl) {
		this.popupListener = pl;
	}

	/**
	 * Retrieves the popup listener set on <code>this</code> breadcrumb bar.
	 * 
	 * @return The popup listener set on <code>this</code> breadcrumb bar.
	 */
	public MouseListener getPopupListener() {
		return popupListener;
	}

	/**
	 * Adds new listener on <code>this</code> breadcrumb bar.
	 * 
	 * @param lst
	 *            Listener to add on <code>this</code> breadcrumb bar.
	 */
	public void addListener(BreadcrumbBarListener<T> lst) {
		if (listeners == null)
			listeners = new ArrayList<BreadcrumbBarListener<T>>();
		if (!listeners.contains(lst))
			listeners.add(lst);
	}

	/**
	 * Removes the specified listener from <code>this</code> breadcrumb bar.
	 * 
	 * @param lst
	 *            Listener to remove from <code>this</code> breadcrumb bar.
	 */
	public void removeListener(BreadcrumbBarListener<T> lst) {
		if (listeners != null)
			listeners.remove(lst);
	}

	/**
	 * Fires the specified breadcrumb bar event.
	 * 
	 * @param event
	 *            The event to fire.
	 */
	public void fireBreadcrumbBarEvent(BreadcrumbBarEvent<T> event) {
		if (noEvent || listeners == null || listeners.isEmpty())
			return;
		for (int i = 0; i < listeners.size(); i++) {
			(listeners.get(i)).breadcrumbBarEvent(event);
		}
	}

	public BreadcrumbBar() {
		this(null, null, null, null);
	}

	/**
	 * Creates a new breadcrumb bar.
	 * 
	 * @param icon
	 *            Optional main icon.
	 * @param separator
	 *            the separator delimiter
	 * @param okButton
	 *            The button used to submit the path for use. Can be
	 *            <code>null</code>l
	 * @param callback
	 *            The application callback.
	 */
	public BreadcrumbBar(Icon icon, String separator, JButton okButton,
			BreadcrumbBarCallBack<T> callback) {
		super();
		// assert (separator != null);
		// assert (callback != null);
		this.icon = icon;
		this.stack = new BreadcrumbStack();
		this.separator = separator;
		this.okButton = okButton;
		this.callback = callback;

		if (this.callback != null)
			this.callback.setup();

		this.exceptionHandlers = new ArrayList<BreadcrumbBarExceptionHandler>();

		this.updateUI();
	}

	/**
	 * Creates a new breadcrumb bar.
	 * 
	 * @param icon
	 *            Optional main icon.
	 * @param separator
	 *            the separator delimiter
	 * @param callback
	 *            The application callback.
	 */
	public BreadcrumbBar(Icon icon, String separator,
			BreadcrumbBarCallBack callback) {
		this(icon, separator, null, callback);
	}

	/**
	 * Creates a new breadcrumb bar.
	 * 
	 * @param separator
	 *            the separator delimiter
	 * @param okButton
	 *            The button used to submit the path for use. Can be
	 *            <code>null</code>l
	 * @param callback
	 *            The application callback.
	 */
	public BreadcrumbBar(String separator, JButton okButton,
			BreadcrumbBarCallBack callback) {
		this(null, separator, okButton, callback);
	}

	/**
	 * Creates a new breadcrumb bar.
	 * 
	 * @param separator
	 *            the separator delimiter
	 * @param callback
	 *            The application callback.
	 */
	public BreadcrumbBar(String separator, BreadcrumbBarCallBack callback) {
		this(null, separator, null, callback);
	}

	/**
	 * Sets the underline color for rollover effects.
	 * 
	 * @param color
	 *            The underline color for rollover effects.
	 */
	public void setUnderlineColor(Color color) {
		this.underlineColor = color;
	}

	/**
	 * Sets the box color for rollover effects.
	 * 
	 * @param color
	 *            The box color for rollover effects.
	 */
	public void setBoxColor(Color color) {
		this.boxColor = color;
	}

	/**
	 * Retrieves the box color for rollover effects.
	 * 
	 * @return The box color for rollover effects.
	 */
	public Color getBoxColor() {
		return this.boxColor;
	}

	/**
	 * Retrieves the separator string.
	 * 
	 * @return The separator string.
	 */
	public String getSeparator() {
		return this.separator;
	}

	/**
	 * Sets new path as the current path in <code>this</code> breadcrumb bar.
	 * 
	 * @param newPath
	 *            New path for <code>this</code> breadcrumb bar.
	 */
	public synchronized void setPath(final BreadcrumbItem<T>[] newPath) {
		final BreadcrumbItem<T>[] old = getPath();
		stack.clear();
		noEvent = true;
		SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
			@Override
			protected Void doInBackground() throws Exception {
				List<StringValuePair<T>> pathChoices = callback
						.getPathChoices(null);
				BreadcrumbItemChoices<T> bic = new BreadcrumbItemChoices<T>(
						pathChoices);
				pushChoices(bic, false);
				for (int i = 0; newPath != null && i < newPath.length; i++) {
					BreadcrumbItem<T> bi = newPath[i];
					pushChoice(bi, false);
					// now check if it has any children
					BreadcrumbItem<T>[] subPath = new BreadcrumbItem[i + 1];
					System.arraycopy(newPath, 0, subPath, 0, i + 1);
					bic = new BreadcrumbItemChoices<T>(callback
							.getPathChoices(subPath));
					if ((bic.getChoices() != null)
							&& (bic.getChoices().length > 0)) {
						// add the selector - the current item has children
						pushChoices(bic, false);
					}
				}
				return null;
			}

			@Override
			protected void done() {
				// now add the "root" elements
				getUI().updateComponents();
				// now fire event
				noEvent = false;
				fireBreadcrumbBarEvent(new BreadcrumbBarEvent<T>(this,
						BreadcrumbBarEvent.PATH_CHANGED, old, newPath));
			}
		};
		worker.execute();
	}

	/**
	 * Returns the current path of <code>this</code> breadcrumb bar.
	 * 
	 * @return The current path of <code>this</code> breadcrumb bar.
	 */
	public BreadcrumbItem<T>[] getPath() {
		return getPath(-1);
	}

	/**
	 * Returns the trailing part of the current path of <code>this</code>
	 * breadcrumb bar that starts at the specified index. If the index is
	 * negative, the complete path is returned.
	 * 
	 * @param beginIndex
	 *            The begin index of the path to return.
	 * @return The trailing part of the current path of <code>this</code>
	 *         breadcrumb bar.
	 */
	public BreadcrumbItem<T>[] getPath(int beginIndex) {
		assert (beginIndex <= stack.size());
		Vector<BreadcrumbItem<T>> path = new Vector<BreadcrumbItem<T>>();
		for (Iterator<T> it = stack.listIterator(0); it.hasNext();) {
			Object elem = it.next();
			if (elem instanceof BreadcrumbItem) {
				path.add((BreadcrumbItem<T>) elem);
			}
			if (stack.indexOf(elem) == beginIndex)
				break;
		}
		BreadcrumbItem<T>[] array = new BreadcrumbItem[path.size()];
		int i = 0;
		while (!path.isEmpty())
			array[i++] = path.remove(0);
		return array;
	}

	/**
	 * Returns the last item in <code>this</code> breadcrumb bar.
	 * 
	 * @return The last item in <code>this</code> breadcrumb bar.
	 */
	public BreadcrumbItem<T> getLastItem() {
		if (stack.isEmpty())
			return null;
		Object last = stack.get(stack.size() - 1);
		if (last instanceof BreadcrumbItem)
			return (BreadcrumbItem<T>) last;
		return null;
	}

	public BreadcrumbItem<T> getItem(int index) {
		if (stack.isEmpty())
			return null;

		if ((index < 0) || (index >= stack.size()))
			return null;

		Object last = stack.get(index);
		if (last instanceof BreadcrumbItem)
			return (BreadcrumbItem<T>) last;
		return null;

	}

	/**
	 * Returns the string representation of the current path inhe last item in
	 * <code>this</code> breadcrumb bar.
	 * 
	 * @return The string representation of the current path inhe last item in
	 *         <code>this</code> breadcrumb bar.
	 */
	public String getRootedPath() {
		return getRootedPath(-1);
	}

	/**
	 * Returns the string representation of the trailing part of the current
	 * path of <code>this</code> breadcrumb bar that starts at the specified
	 * index. If the index is negative, the complete path is returned.
	 * 
	 * @param beginIndex
	 *            The begin index of the path to return.
	 * @return The the string representation of the trailing part of the current
	 *         path of <code>this</code> breadcrumb bar.
	 */
	public String getRootedPath(int beginIndex) {
		assert (beginIndex <= stack.size());
		StringBuffer path = new StringBuffer();
		for (Iterator it = stack.listIterator(0); it.hasNext();) {
			Object elem = it.next();
			if (elem instanceof BreadcrumbItemChoices) {
				path.append(separator);
			} else if (elem instanceof BreadcrumbItem) {
				path.append(((BreadcrumbItem<T>) elem).getKey());
			}
			if (stack.indexOf(elem) == beginIndex)
				break;
		}
		return path.toString();
	}

	/**
	 * Pushes a choice to the top position of the stack. If the current top is
	 * already a {@link BreadcrumbItemChoices}, replace it.
	 * 
	 * @param bic
	 *            The choice item to push.
	 * @return The item that has been pushed.
	 */
	public Object pushChoices(BreadcrumbItemChoices<T> bic) {
		return pushChoices(bic, true);
	}

	/**
	 * Pushes a choice to the top position of the stack. If the current top is
	 * already a {@link BreadcrumbItemChoices}, replace it.
	 * 
	 * @param bic
	 *            The choice item to push.
	 * @param toUpdateUI
	 *            Indication whether the bar should be repainted.
	 * @return The item that has been pushed.
	 */
	public synchronized Object pushChoices(BreadcrumbItemChoices<T> bic,
			boolean toUpdateUI) {
		if (bic == null)
			return null;
		if (okButton != null)
			okButton.setEnabled(true);
		Object result;
		synchronized (stack) {
			// BreadcrumbItem[] old = getPath();
			if (stack.size() % 2 == 1) {
				stack.pop();
			}
			bic.setIndex(stack.size());
			result = stack.push(bic);
		}
		if (toUpdateUI) {
			// if (this.getUI() != null)
			this.getUI().updateComponents();
		}
		// // warn listeners
		// fireBreadcrumbBarEvent(new
		// BreadcrumbBarEvent(BreadcrumbBarEvent.PATH_CHANGED, old, getPath()));
		return result;
	}

	// /**
	// * Creates a new {@link BreadcrumbItemChoices} object from the specified
	// * array of strings.
	// *
	// * @param choices
	// * The string array.
	// * @return The choices object.
	// */
	// public static BreadcrumbItemChoices<T> makeChoices(String[] choices) {
	// if (choices == null)
	// return null;
	// BreadcrumbItem<T>[] items = new BreadcrumbItem[choices.length];
	// for (int i = 0; i < choices.length; i++) {
	// items[i] = new BreadcrumbItem<T>(new String[] { choices[i] });
	// }
	// return new BreadcrumbItemChoices<T>(items);
	// }
	//
	// /**
	// * Creates a new {@link BreadcrumbItemChoices} object from the specified
	// * vector of strings.
	// *
	// * @param choices
	// * The string vector.
	// * @return The choices object.
	// */
	// public static BreadcrumbItemChoices makeChoices(Vector<String> choices) {
	// if (choices == null)
	// return null;
	// BreadcrumbItem[] items = new BreadcrumbItem[choices.size()];
	// for (int i = 0; i < choices.size(); i++) {
	// items[i] = new BreadcrumbItem(new String[] { choices.get(i) });
	// }
	// return new BreadcrumbItemChoices(items);
	// }

	/**
	 * Pushes an item to the top position of the stack. If the current top is
	 * already a {@link BreadcrumbItem}, replace it.
	 * 
	 * @param bi
	 *            The item to push.
	 * @return The item that has been pushed.
	 */
	public Object pushChoice(BreadcrumbItem<T> bi) {
		return pushChoice(bi, true);
	}

	/**
	 * Pushes an item to the top position of the stack. If the current top is
	 * already a {@link BreadcrumbItemChoices}, replace it.
	 * 
	 * @param bi
	 *            The item to push.
	 * @param toUpdateUI
	 *            Indication whether the bar should be repainted.
	 * @return The item that has been pushed.
	 */
	public Object pushChoice(BreadcrumbItem<T> bi, boolean toUpdateUI) {
		assert (bi != null);
		if (okButton != null)
			okButton.setEnabled(true);
		Object old = getPath();
		Object result;
		synchronized (stack) {
			if (!stack.isEmpty() && stack.size() % 2 == 0) {
				stack.pop();
			}
			bi.setIndex(stack.size());
			result = stack.push(bi);
		}
		if (toUpdateUI) {
			this.getUI().updateComponents();
			revalidate();
			repaint();
		}
		// warn listeners
		fireBreadcrumbBarEvent(new BreadcrumbBarEvent<T>(this,
				BreadcrumbBarEvent.PATH_CHANGED, old, getPath()));
		return result;
	}

	/**
	 * Pops the last item from the path.
	 * 
	 * @return The item that has been removed from the path.
	 */
	public Object pop() {
		if (stack.size() <= 1 && okButton != null)
			okButton.setEnabled(false);
		return stack.pop();
	}

	public int getItemCount() {
		return this.stack.size();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Component#toString()
	 */
	@Override
	public String toString() {
		return Arrays.asList(getPath()).toString();
	}

	/**
	 * Returns the application callback.
	 * 
	 * @return The application callback.
	 */
	public BreadcrumbBarCallBack<T> getCallback() {
		return this.callback;
	}

	/**
	 * Sets the new UI delegate.
	 * 
	 * @param ui
	 *            New UI delegate.
	 */
	public void setUI(BreadcrumbBarUI ui) {
		super.setUI(ui);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.JComponent#updateUI()
	 */
	@Override
	public void updateUI() {
		if (UIManager.get(getUIClassID()) != null) {
			setUI((BreadcrumbBarUI) UIManager.getUI(this));
		} else {
			setUI(new BasicBreadcrumbBarUI());
		}
	}

	/**
	 * Returns the UI object which implements the L&F for this component.
	 * 
	 * @return a <code>BreadcrumbBarUI</code> object
	 * @see #setUI
	 */
	public BreadcrumbBarUI getUI() {
		return (BreadcrumbBarUI) ui;
	}

	/**
	 * Returns the name of the UI class that implements the L&F for this
	 * component.
	 * 
	 * @return the string "BreadcrumbBarUI"
	 * @see JComponent#getUIClassID
	 * @see UIDefaults#getUI
	 */
	@Override
	public String getUIClassID() {
		return uiClassID;
	}

	/**
	 * Returns the current path.
	 * 
	 * @return The current path.
	 */
	public BreadcrumbStack getStack() {
		return this.stack;
	}

	/**
	 * Returns the main icon.
	 * 
	 * @return The main icon.
	 */
	public Icon getIcon() {
		return this.icon;
	}

	/**
	 * Returns the OK button.
	 * 
	 * @return OK button.
	 */
	public JButton getOkButton() {
		return this.okButton;
	}

	/**
	 * Returns the underline color for the rollover effects.
	 * 
	 * @return The underline color for the rollover effects.
	 */
	public Color getUnderlineColor() {
		return this.underlineColor;
	}

	/**
	 * Registers the specified exception handler.
	 * 
	 * @param handler
	 *            Exception handler.
	 */
	public void addExceptionHandler(BreadcrumbBarExceptionHandler handler) {
		this.exceptionHandlers.add(handler);
	}

	/**
	 * Unregisters the specified exception handler.
	 * 
	 * @param handler
	 *            Exception handler.
	 */
	public void removeExceptionHandler(BreadcrumbBarExceptionHandler handler) {
		this.exceptionHandlers.remove(handler);
	}

	/**
	 * Returns the list of currently registered exception handlers.
	 * 
	 * @return List of currently registered exception handlers.
	 */
	public List<BreadcrumbBarExceptionHandler> getExceptionHandlers() {
		return Collections.unmodifiableList(this.exceptionHandlers);
	}

	/**
	 * Sets the indication whether the operations of this breadcrumb bar will
	 * throw {@link BreadcrumbBarException}.
	 * 
	 * @param throwsExceptions
	 *            If <code>true</code>, the operations of this breadcrumb bar
	 *            will throw {@link BreadcrumbBarException}.
	 */
	public void setThrowsExceptions(boolean throwsExceptions) {
		if (this.callback != null) {
			this.callback.setThrowsExceptions(throwsExceptions);
		}
	}
}