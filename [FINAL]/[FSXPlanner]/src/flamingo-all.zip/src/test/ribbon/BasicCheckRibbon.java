/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package test.ribbon;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;

import org.jvnet.flamingo.common.*;
import org.jvnet.flamingo.common.icon.DecoratedResizableIcon;
import org.jvnet.flamingo.common.icon.ResizableIcon;
import org.jvnet.flamingo.ribbon.*;
import org.jvnet.flamingo.svg.SvgBatikResizableIcon;

import test.TestImageCreator;

public class BasicCheckRibbon extends JFrame {
	private class PopupMouseListener extends MouseAdapter {
		@Override
		public void mouseClicked(MouseEvent e) {
			JPopupMenu popupMenu = new JPopupMenu();
			popupMenu.add(new JMenuItem("Test menu item 1"));
			popupMenu.add(new JMenuItem("Test menu item 2"));
			popupMenu.addSeparator();
			popupMenu.add(new JMenuItem("Test menu item 3"));
			popupMenu.add(new JMenuItem("Test menu item 4"));
			popupMenu.add(new JMenuItem("Test menu item 5"));

			popupMenu.show((Component) e.getSource(), e.getX(), e.getY());
		}
	}

	private class SamplePopupActionListener implements PopupMenuListener {
		@Override
		public void menuAboutToShow(JPopupMenu popupMenu) {
			popupMenu.add(new JMenuItem("Test menu item 1"));
			popupMenu.add(new JMenuItem("Test menu item 2"));
			popupMenu.addSeparator();
			popupMenu.add(new JMenuItem("Test menu item 3"));
			popupMenu.add(new JMenuItem("Test menu item 4"));
			popupMenu.add(new JMenuItem("Test menu item 5"));
		}
	}

	private class ExpandActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(BasicCheckRibbon.this,
					"Expand button clicked");
		}
	}

	private AbstractButton getIconButton(Icon icon, boolean isToggle,
			boolean isSelected, boolean hasPopup) {
		AbstractButton button = isToggle ? new JToggleButton(icon)
				: new JButton(icon);
		if (isSelected)
			button.setSelected(true);
		button.setPreferredSize(new Dimension(icon.getIconWidth(), icon
				.getIconHeight()));
		button.setMargin(new Insets(2, 2, 2, 2));
		if (hasPopup)
			button.addMouseListener(new PopupMouseListener());
		return button;
	}

	private JRibbonBand getActionBand() {
		JRibbonBand fontBand = new JRibbonBand("Action", SvgBatikResizableIcon
				.getSvgIcon(BasicCheckRibbon.class.getClassLoader()
						.getResource("test/svg/document-new.svg"),
						new Dimension(32, 32)), new ExpandActionListener());

		JCommandButton themeGalleryButton = new JCommandButton("Address book",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/address-book-new.svg"),
						new Dimension(32, 32)));
		fontBand
				.addGalleryButton(themeGalleryButton, RibbonElementPriority.TOP);

		JCommandButton colorsButton = new JCommandButton("Appointment",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/appointment-new.svg"), new Dimension(
						32, 32)));
		fontBand.addGalleryButton(colorsButton, RibbonElementPriority.MEDIUM);

		JCommandButton fontsButton = new JCommandButton("Bookmark",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/bookmark-new.svg"), new Dimension(32,
						32)));
		fontBand.addGalleryButton(fontsButton, RibbonElementPriority.MEDIUM);

		JCommandButton effectsButton = new JCommandButton("Contact",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/contact-new.svg"), new Dimension(32,
						32)));
		fontBand.addGalleryButton(effectsButton, RibbonElementPriority.MEDIUM);

		return fontBand;
	}

	private JRibbonBand getPageSetupBand() {
		JRibbonBand pageSetupBand = new JRibbonBand("Preferences",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/preferences-system.svg"),
						new Dimension(32, 32)), new ExpandActionListener());

		JCommandButton marginsButton = new JCommandButton(
				"Accessibility",
				SvgBatikResizableIcon
						.getSvgIcon(
								BasicCheckRibbon.class
										.getClassLoader()
										.getResource(
												"test/svg/preferences-desktop-accessibility.svg"),
								new Dimension(32, 32)));
		pageSetupBand
				.addGalleryButton(marginsButton, RibbonElementPriority.TOP);

		JCommandButton orientationButton = new JCommandButton(
				"Assistive technologies",
				SvgBatikResizableIcon
						.getSvgIcon(
								BasicCheckRibbon.class
										.getClassLoader()
										.getResource(
												"test/svg/preferences-desktop-assistive-technology.svg"),
								new Dimension(32, 32)));
		pageSetupBand.addGalleryButton(orientationButton,
				RibbonElementPriority.TOP);

		JCommandButton sizeButton = new JCommandButton("Font",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/preferences-desktop-font.svg"),
						new Dimension(32, 32)));
		pageSetupBand.addGalleryButton(sizeButton, RibbonElementPriority.TOP);

		JCommandButton printAreaButton = new JCommandButton(
				"Keyboard shortcuts",
				SvgBatikResizableIcon
						.getSvgIcon(
								BasicCheckRibbon.class
										.getClassLoader()
										.getResource(
												"test/svg/preferences-desktop-keyboard-shortcuts.svg"),
								new Dimension(32, 32)));
		printAreaButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.POPUP_ONLY);
		printAreaButton.addPopupActionListener(new SamplePopupActionListener());
		pageSetupBand.addGalleryButton(printAreaButton,
				RibbonElementPriority.TOP);

		JCommandButton breaksButton = new JCommandButton("Locale",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/preferences-desktop-locale.svg"),
						new Dimension(32, 32)));
		pageSetupBand.addGalleryButton(breaksButton, RibbonElementPriority.TOP);

		JCommandButton printTitlesButton = new JCommandButton(
				"Screensaver",
				SvgBatikResizableIcon
						.getSvgIcon(
								BasicCheckRibbon.class
										.getClassLoader()
										.getResource(
												"test/svg/preferences-desktop-screensaver.svg"),
								new Dimension(32, 32)));
		pageSetupBand.addGalleryButton(printTitlesButton,
				RibbonElementPriority.TOP);

		JCommandButton backgroundButton = new JCommandButton("Themes",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/preferences-desktop-theme.svg"),
						new Dimension(32, 32)));
		pageSetupBand.addGalleryButton(backgroundButton,
				RibbonElementPriority.TOP);

		return pageSetupBand;
	}

	private JRibbonBand getArrangeBand() {
		JRibbonBand arrangeBand = new JRibbonBand("Applications",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/applications-other.svg"),
						new Dimension(32, 32)), new ExpandActionListener());

		JCommandButton bringToFrontButton = new JCommandButton("Accessories",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/applications-accessories.svg"),
						new Dimension(32, 32)));
		arrangeBand.addGalleryButton(bringToFrontButton,
				RibbonElementPriority.MEDIUM);

		JCommandButton alignShapesButton = new JCommandButton("Games",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/applications-games.svg"),
						new Dimension(32, 32)));
		arrangeBand.addGalleryButton(alignShapesButton,
				RibbonElementPriority.MEDIUM);

		JCommandButton groupButton = new JCommandButton("Graphics",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/applications-graphics.svg"),
						new Dimension(32, 32)));
		arrangeBand.addGalleryButton(groupButton, RibbonElementPriority.LOW);

		JCommandButton ungroupButton = new JCommandButton("Internet",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/applications-internet.svg"),
						new Dimension(32, 32)));
		arrangeBand.addGalleryButton(ungroupButton, RibbonElementPriority.LOW);

		JCommandButton rotateButton = new JCommandButton("Multimedia",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/applications-multimedia.svg"),
						new Dimension(32, 32)));
		arrangeBand.addGalleryButton(rotateButton, RibbonElementPriority.LOW);

		return arrangeBand;
	}

	private JRibbonBand getFontBand() {
		JRibbonBand fontBand = new JRibbonBand("Font", SvgBatikResizableIcon
				.getSvgIcon(BasicCheckRibbon.class.getClassLoader()
						.getResource("test/svg/preferences-desktop-font.svg"),
						new Dimension(32, 32)), new ExpandActionListener());

		JPanel mainPanel = new JPanel(new GridLayout(2, 1));

		JPanel topPanel = new JPanel(new FlowLayout());
		topPanel.setBorder(new EmptyBorder(0, 0, 0, 0));
		JPanel bottomPanel = new JPanel(new FlowLayout());

		mainPanel.setOpaque(false);
		topPanel.setOpaque(false);
		bottomPanel.setOpaque(false);

		mainPanel.add(topPanel);
		mainPanel.add(bottomPanel);

		topPanel.add(new JComboBox(
				new Object[] { "+ Minor (Calibri)              " }));
		topPanel.add(new JComboBox(new Object[] { "11     " }));

		JButtonStrip sizeStrip = new JButtonStrip();
		sizeStrip.add(this.getIconButton(
				TestImageCreator.getFontIncreaseIcon(), true, true, false));
		sizeStrip.add(this.getIconButton(
				TestImageCreator.getFontDecreaseIcon(), true, false, false));
		topPanel.add(sizeStrip);

		JButtonStrip styleStrip = new JButtonStrip();
		styleStrip.add(this.getIconButton(TestImageCreator.getBoldIcon(), true,
				true, false));
		styleStrip.add(this.getIconButton(TestImageCreator.getItalicIcon(),
				true, false, false));
		styleStrip.add(this.getIconButton(TestImageCreator.getUnderlineIcon(),
				true, false, false));
		styleStrip.add(this.getIconButton(TestImageCreator.getSubscriptIcon(),
				true, false, false));
		styleStrip.add(this.getIconButton(
				TestImageCreator.getSuperscriptIcon(), true, false, false));
		styleStrip.add(this.getIconButton(TestImageCreator.getFontsIcon(),
				true, false, true));

		bottomPanel.add(styleStrip);

		JButtonStrip colorStrip = new JButtonStrip();
		colorStrip.add(this.getIconButton(TestImageCreator.getFontColorIcon(),
				false, false, true));
		colorStrip.add(this.getIconButton(TestImageCreator.getBackColorIcon(),
				false, false, true));

		bottomPanel.add(colorStrip);

		fontBand.addPanel(mainPanel);

		return fontBand;
	}

	private JRibbonBand getParagraphBand() {
		JRibbonBand paragraphBand = new JRibbonBand("Paragraph",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/format-justify-fill.svg"),
						new Dimension(32, 32)), new ExpandActionListener());

		JPanel buttonsPanel = new JPanel(new GridLayout(2, 1));
		paragraphBand.addPanel(buttonsPanel);

		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		topPanel.setBorder(new EmptyBorder(8, 0, 0, 0));
		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

		buttonsPanel.add(topPanel);
		buttonsPanel.add(bottomPanel);
		topPanel.setOpaque(false);
		bottomPanel.setOpaque(false);
		buttonsPanel.setOpaque(false);

		JButtonStrip listStrip = new JButtonStrip();
		listStrip.add(this.getIconButton(TestImageCreator.getListBulletsIcon(),
				false, false, true));
		listStrip.add(this.getIconButton(TestImageCreator.getListInnerIcon(),
				false, false, true));
		listStrip.add(this.getIconButton(TestImageCreator.getListNumbersIcon(),
				false, false, true));

		topPanel.add(listStrip);

		JButtonStrip indentStrip = new JButtonStrip();
		indentStrip.add(this.getIconButton(
				TestImageCreator.getIndentLeftIcon(), false, false, false));
		indentStrip.add(this.getIconButton(TestImageCreator
				.getIndentRightIcon(), false, false, false));

		topPanel.add(indentStrip);

		JButtonStrip fontSortStrip = new JButtonStrip();
		fontSortStrip.add(this.getIconButton(
				TestImageCreator.getFontSortIcon(), false, false, false));
		topPanel.add(fontSortStrip);

		JButtonStrip alignStrip = new JButtonStrip();
		ButtonGroup alignGroup = new ButtonGroup();
		AbstractButton al = this.getIconButton(TestImageCreator
				.getAlignLeftIcon(), true, true, false);
		alignGroup.add(al);
		alignStrip.add(al);
		AbstractButton ac = this.getIconButton(TestImageCreator
				.getAlignCenterIcon(), true, false, false);
		alignGroup.add(ac);
		alignStrip.add(ac);
		AbstractButton ar = this.getIconButton(TestImageCreator
				.getAlignRightIcon(), true, false, false);
		alignGroup.add(ar);
		alignStrip.add(ar);
		AbstractButton af = this.getIconButton(TestImageCreator
				.getAlignFillIcon(), true, false, false);
		alignGroup.add(af);
		alignStrip.add(af);

		bottomPanel.add(alignStrip);

		bottomPanel.add(this.getIconButton(TestImageCreator.getSpacingIcon(),
				false, false, true));

		bottomPanel.add(this.getIconButton(TestImageCreator.getParagraphIcon(),
				false, false, false));

		JCommandButton bordersButton = new JCommandButton("Computer",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource("test/svg/computer.svg"),
						new Dimension(20, 20)));
		paragraphBand.addGalleryButton(bordersButton,
				RibbonElementPriority.MEDIUM);

		JCommandButton shadingButton = new JCommandButton("Photo",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/camera-photo.svg"), new Dimension(20,
						20)));
		paragraphBand.addGalleryButton(shadingButton,
				RibbonElementPriority.MEDIUM);

		JCommandButton dropCapButton = new JCommandButton("Video",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/camera-video.svg"), new Dimension(20,
						20)));
		paragraphBand.addGalleryButton(dropCapButton,
				RibbonElementPriority.MEDIUM);

		return paragraphBand;
	}

	private JRibbonBand getClipboardBand() {
		JRibbonBand clipboardBand = new JRibbonBand("Clipboard",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader()
						.getResource("test/svg/edit-paste.svg"), new Dimension(
						32, 32)), new ExpandActionListener());

		JCommandButton mainButton = new JCommandButton("Paste",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader()
						.getResource("test/svg/edit-paste.svg"), new Dimension(
						32, 32)));
		mainButton.setMnemonic('P');
		mainButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Pasted!");
			}
		});
		mainButton.addPopupActionListener(new SamplePopupActionListener());
		mainButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_ACTION);

		clipboardBand.addGalleryButton(mainButton, RibbonElementPriority.TOP);

		JCommandButton cutButton = new JCommandButton("Cut",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource("test/svg/edit-cut.svg"),
						new Dimension(32, 32)));
		cutButton.addPopupActionListener(new SamplePopupActionListener());
		cutButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_ACTION);
		clipboardBand.addGalleryButton(cutButton, RibbonElementPriority.MEDIUM);

		JCommandButton copyButton = new JCommandButton("Copy",
				SvgBatikResizableIcon.getSvgIcon(
						BasicCheckRibbon.class.getClassLoader().getResource(
								"test/svg/edit-copy.svg"),
						new Dimension(32, 32)));
		copyButton.addPopupActionListener(new SamplePopupActionListener());
		copyButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_POPUP);
		clipboardBand
				.addGalleryButton(copyButton, RibbonElementPriority.MEDIUM);

		JCommandButton pasteButton = new JCommandButton("Paste",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader()
						.getResource("test/svg/edit-paste.svg"), new Dimension(
						32, 32)));
		pasteButton.addPopupActionListener(new SamplePopupActionListener());
		pasteButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.POPUP_ONLY);
		clipboardBand.addGalleryButton(pasteButton,
				RibbonElementPriority.MEDIUM);

		return clipboardBand;
	}

	private JRibbonBand getFindBand() {
		JRibbonBand findBand = new JRibbonBand("Find", SvgBatikResizableIcon
				.getSvgIcon(BasicCheckRibbon.class.getClassLoader()
						.getResource("test/svg/edit-find.svg"), new Dimension(
						32, 32)));

		JCommandButton findButton = new JCommandButton("Find",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/system-search.svg"), new Dimension(
						32, 32)));
		findBand.addGalleryButton(findButton, RibbonElementPriority.TOP);

		JCommandButton replaceButton = new JCommandButton("Find",
				SvgBatikResizableIcon.getSvgIcon(
						BasicCheckRibbon.class.getClassLoader().getResource(
								"test/svg/edit-find.svg"),
						new Dimension(32, 32)));
		findBand.addGalleryButton(replaceButton, RibbonElementPriority.MEDIUM);

		JCommandButton goToButton = new JCommandButton("Find replace",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/edit-find-replace.svg"),
						new Dimension(32, 32)));
		findBand.addGalleryButton(goToButton, RibbonElementPriority.MEDIUM);

		JCommandButton selectButton = new JCommandButton("Select all",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/edit-select-all.svg"), new Dimension(
						32, 32)));
		findBand.addGalleryButton(selectButton, RibbonElementPriority.MEDIUM);

		return findBand;
	}

	private JRibbonBand getQuickStylesBand() {
		JRibbonBand quickStylesBand = new JRibbonBand("Quick Styles",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/preferences-desktop-theme.svg"),
						new Dimension(32, 32)));

		Map<ElementState, Integer> stylesGalleryVisibleButtonCounts = new HashMap<ElementState, Integer>();
		stylesGalleryVisibleButtonCounts.put(ElementState.SMALL, 1);
		stylesGalleryVisibleButtonCounts.put(ElementState.MEDIUM, 2);
		stylesGalleryVisibleButtonCounts.put(ElementState.BIG, 2);

		List<StringValuePair<List<JCommandToggleButton>>> stylesGalleryButtons = new ArrayList<StringValuePair<List<JCommandToggleButton>>>();
		List<JCommandToggleButton> stylesGalleryButtonsList = new ArrayList<JCommandToggleButton>();
		List<JCommandToggleButton> stylesGalleryButtonsList2 = new ArrayList<JCommandToggleButton>();
		for (int i = 0; i < 30; i++) {
			final int index = i;
			ResizableIcon fontIcon = SvgBatikResizableIcon.getSvgIcon(
					BasicCheckRibbon.class.getClassLoader().getResource(
							"test/svg/font-x-generic.svg"), new Dimension(32,
							32));
			ResizableIcon finalIcon = new DecoratedResizableIcon(fontIcon,
					new DecoratedResizableIcon.IconDecorator() {
						@Override
						public void paintIconDecoration(Component c,
								Graphics g, int x, int y, int width, int height) {
							Graphics2D g2d = (Graphics2D) g.create();
							g2d.setColor(Color.black);
							g2d.drawString("" + index, x + 2, y + height - 2);
						}
					});
			JCommandToggleButton jrb = new JCommandToggleButton("Style " + i,
					finalIcon);
			jrb.setName("Index " + i);
			jrb.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.out.println("Invoked action on " + index);
				}
			});
			if (i < 10)
				stylesGalleryButtonsList.add(jrb);
			else
				stylesGalleryButtonsList2.add(jrb);
		}

		stylesGalleryButtons
				.add(new StringValuePair<List<JCommandToggleButton>>("Styles",
						stylesGalleryButtonsList));
		stylesGalleryButtons
				.add(new StringValuePair<List<JCommandToggleButton>>(
						"Extended Styles", stylesGalleryButtonsList2));

		quickStylesBand.addRibbonGallery(stylesGalleryButtons,
				stylesGalleryVisibleButtonCounts, 6, 4,
				RibbonElementPriority.TOP);

		JCommandButton stylesButton1 = new JCommandButton("Styles1",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/font-x-generic.svg"), new Dimension(
						32, 32)));
		quickStylesBand.addGalleryButton(stylesButton1,
				RibbonElementPriority.MEDIUM);

		JCommandButton styles2Button = new JCommandButton("Styles2",
				SvgBatikResizableIcon.getSvgIcon(BasicCheckRibbon.class
						.getClassLoader().getResource(
								"test/svg/image-x-generic.svg"), new Dimension(
						32, 32)));
		quickStylesBand.addGalleryButton(styles2Button,
				RibbonElementPriority.MEDIUM);

		JCommandButton styles3Button = new JCommandButton("Styles3",
				SvgBatikResizableIcon.getSvgIcon(
						BasicCheckRibbon.class.getClassLoader().getResource(
								"test/svg/text-html.svg"),
						new Dimension(32, 32)));
		quickStylesBand.addGalleryButton(styles3Button,
				RibbonElementPriority.MEDIUM);

		return quickStylesBand;
	}

	private JRibbonBand getPreviewBand() {
		JRibbonBand previewBand = new JRibbonBand("Preview",
				new SimpleResizableIcon(RibbonElementPriority.TOP, 32, 32));

		JCommandButton findButton = new JCommandButton("Preview",
				new SimpleResizableIcon(RibbonElementPriority.TOP, 32, 32));
		previewBand.addGalleryButton(findButton, RibbonElementPriority.TOP);

		JCommandButton slideShowButton = new JCommandButton("Slide Show",
				new SimpleResizableIcon(RibbonElementPriority.TOP, 32, 32));
		previewBand
				.addGalleryButton(slideShowButton, RibbonElementPriority.TOP);

		return previewBand;
	}

	private JRibbonBand getAnimationBand() {
		JRibbonBand animationBand = new JRibbonBand("Animation...",
				new SimpleResizableIcon(RibbonElementPriority.TOP, 32, 32));

		JCommandButton findButton = new JCommandButton("Custom Animation",
				new SimpleResizableIcon(RibbonElementPriority.TOP, 32, 32));
		animationBand.addGalleryButton(findButton, RibbonElementPriority.TOP);

		return animationBand;
	}

	private JRibbonBand getTransitionBand() {
		JRibbonBand transitionBand = new JRibbonBand(
				"Transition To This Slide", new SimpleResizableIcon(
						RibbonElementPriority.TOP, 32, 32));

		Map<ElementState, Integer> transitionGalleryVisibleButtonCounts = new HashMap<ElementState, Integer>();
		transitionGalleryVisibleButtonCounts.put(ElementState.SMALL, 2);
		transitionGalleryVisibleButtonCounts.put(ElementState.MEDIUM, 4);
		transitionGalleryVisibleButtonCounts.put(ElementState.BIG, 6);

		List<StringValuePair<List<JCommandToggleButton>>> transitionGalleryButtons = new ArrayList<StringValuePair<List<JCommandToggleButton>>>();
		List<JCommandToggleButton> transitionGalleryButtonsList = new ArrayList<JCommandToggleButton>();

		for (int i = 1; i <= 20; i++) {
			JCommandToggleButton additionalButton = new JCommandToggleButton(
					"Trans no." + i, new NumberedResizableIcon(i, 100, 80));
			transitionGalleryButtonsList.add(additionalButton);
		}

		transitionGalleryButtons
				.add(new StringValuePair<List<JCommandToggleButton>>(
						"Transitions", transitionGalleryButtonsList));
		transitionBand.addRibbonGallery(transitionGalleryButtons,
				transitionGalleryVisibleButtonCounts, 6, 3,
				RibbonElementPriority.TOP);

		JPanel stuffPanel = new JPanel(new GridLayout(3, 1, 0, 0));
		JPanel soundPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
		soundPanel.add(new JLabel("Sound", new SimpleResizableIcon(
				RibbonElementPriority.TOP, 16, 16), JLabel.LEADING));
		soundPanel.add(new JComboBox(new Object[] { "[No Sound]     " }));
		stuffPanel.add(soundPanel);
		JPanel speedPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
		speedPanel.add(new JLabel("Speed", new SimpleResizableIcon(
				RibbonElementPriority.TOP, 16, 16), JLabel.LEADING));
		speedPanel.add(new JComboBox(new Object[] { "Medium           " }));
		stuffPanel.add(speedPanel);
		JPanel applyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
		applyPanel.add(new JLabel("Apply To All", new SimpleResizableIcon(
				RibbonElementPriority.TOP, 16, 16), JLabel.LEADING));
		stuffPanel.add(applyPanel);

		transitionBand.addPanel(stuffPanel);

		return transitionBand;
	}

	private JRibbonBand getTransitionNextBand() {
		JRibbonBand transitionBand = new JRibbonBand(
				"Transition To Next Slide", new SimpleResizableIcon(
						RibbonElementPriority.TOP, 32, 32));

		JPanel stuffPanel = new JPanel(new GridLayout(3, 1, 0, 0));
		JPanel mouseClickPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2,
				0));
		JCheckBox mouseClickCheckBox = new JCheckBox("On Mouse Click");
		mouseClickCheckBox.setSelected(true);
		mouseClickPanel.add(mouseClickCheckBox);
		stuffPanel.add(mouseClickPanel);

		JPanel afterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
		afterPanel.add(new JCheckBox("Automatically After"));
		stuffPanel.add(afterPanel);

		JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
		timePanel.add(new JLabel(new SimpleResizableIcon(
				RibbonElementPriority.TOP, 16, 16)));
		timePanel.add(new JSpinner(new SpinnerDateModel()));
		stuffPanel.add(timePanel);

		transitionBand.addPanel(stuffPanel);

		return transitionBand;
	}

	protected JRibbon ribbon;

	public BasicCheckRibbon() {
		super("Ribbon test");
		this.setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB));

		this.setLayout(new BorderLayout());
		this.ribbon = new JRibbon();
		ribbon.add(new JLabel("File"));
		ribbon.add(new JSeparator(JSeparator.VERTICAL));

		this.add(ribbon, BorderLayout.NORTH);
	}

	public void configureRibbon() {
		RibbonTask pageLayoutTask = new RibbonTask();
		JRibbonBand themeBand = this.getActionBand();
		pageLayoutTask.addBand(themeBand);

		JRibbonBand pageSetupBand = this.getPageSetupBand();
		pageLayoutTask.addBand(pageSetupBand);

		JRibbonBand arrangeBand = this.getArrangeBand();
		pageLayoutTask.addBand(arrangeBand);

		RibbonTask writeTask = new RibbonTask();
		JRibbonBand clipboardBand = this.getClipboardBand();
		writeTask.addBand(clipboardBand);

		JRibbonBand quickStylesBand = this.getQuickStylesBand();
		writeTask.addBand(quickStylesBand);

		JRibbonBand fontBand = this.getFontBand();
		writeTask.addBand(fontBand);

		JRibbonBand paragraphBand = this.getParagraphBand();
		writeTask.addBand(paragraphBand);

		JRibbonBand findBand = this.getFindBand();
		writeTask.addBand(findBand);

		RibbonTask animationsTask = new RibbonTask();
		JRibbonBand previewBand = this.getPreviewBand();
		animationsTask.addBand(previewBand);

		JRibbonBand animationBand = this.getAnimationBand();
		animationsTask.addBand(animationBand);

		JRibbonBand transitionBand = this.getTransitionBand();
		animationsTask.addBand(transitionBand);

		JRibbonBand transitionNextBand = this.getTransitionNextBand();
		animationsTask.addBand(transitionNextBand);

		ribbon.addTask("Write", writeTask);
		ribbon.addTask("Page Layout", pageLayoutTask);
		ribbon.addTask("Animations", animationsTask);
		ribbon.setHelpTask(animationsTask);

		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		this.configureControlPanel(controlPanel);

		this.add(controlPanel, BorderLayout.SOUTH);
	}

	protected void configureControlPanel(JPanel controlPanel) {
		JButton bl = new JButton("Align left");
		bl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ribbon.setAlignment(SwingConstants.LEFT);
			}
		});
		controlPanel.add(bl);
		JButton bc = new JButton("Align center");
		bc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ribbon.setAlignment(SwingConstants.CENTER);
			}
		});
		bc.setMnemonic('c');
		controlPanel.add(bc);
		JButton br = new JButton("Align right");
		br.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ribbon.setAlignment(SwingConstants.RIGHT);
			}
		});
		controlPanel.add(br);

		LookAndFeelInfo[] lafs = UIManager.getInstalledLookAndFeels();
		final JComboBox jcb = new JComboBox(lafs);
		jcb.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						JFrame frame = BasicCheckRibbon.this;
						boolean wasDecoratedByOS = !frame.isUndecorated();
						try {
							LookAndFeelInfo selected = (LookAndFeelInfo) jcb
									.getSelectedItem();
							UIManager.setLookAndFeel(selected.getClassName());
							SwingUtilities.updateComponentTreeUI(frame);
						} catch (Exception exc) {
							exc.printStackTrace();
						}
						boolean canBeDecoratedByLAF = UIManager
								.getLookAndFeel()
								.getSupportsWindowDecorations();
						if (canBeDecoratedByLAF == wasDecoratedByOS) {
							boolean wasVisible = frame.isVisible();

							frame.setVisible(false);
							frame.dispose();
							if (!canBeDecoratedByLAF) {
								// see the java docs under the method
								// JFrame.setDefaultLookAndFeelDecorated(boolean
								// value) for description of these 2 lines:
								frame.setUndecorated(false);
								frame.getRootPane().setWindowDecorationStyle(
										JRootPane.NONE);

							} else {
								frame.setUndecorated(true);
								frame.getRootPane().setWindowDecorationStyle(
										JRootPane.FRAME);
							}
							frame.setVisible(wasVisible);
							wasDecoratedByOS = !frame.isUndecorated();
						}
					}
				});
			}
		});
		jcb.setRenderer(new DefaultListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList list,
					Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				return super.getListCellRendererComponent(list,
						((LookAndFeelInfo) value).getName(), index, isSelected,
						cellHasFocus);
			}
		});
		controlPanel.add(jcb);
	}

	public static void main(String[] args) {
		UIManager.installLookAndFeel("JGoodies Plastic",
				"com.jgoodies.looks.plastic.PlasticLookAndFeel");
		UIManager.installLookAndFeel("JGoodies PlasticXP",
				"com.jgoodies.looks.plastic.PlasticXPLookAndFeel");
		UIManager.installLookAndFeel("JGoodies Plastic3D",
				"com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
		UIManager.installLookAndFeel("JGoodies Windows",
				"com.jgoodies.looks.windows.WindowsLookAndFeel");

		UIManager.installLookAndFeel("Synthetica base",
				"de.javasoft.plaf.synthetica.SyntheticaStandardLookAndFeel");
		UIManager.installLookAndFeel("Synthetica BlackMoon",
				"de.javasoft.plaf.synthetica.SyntheticaBlackMoonLookAndFeel");
		UIManager.installLookAndFeel("Synthetica BlackStar",
				"de.javasoft.plaf.synthetica.SyntheticaBlackStarLookAndFeel");
		UIManager.installLookAndFeel("Synthetica BlueIce",
				"de.javasoft.plaf.synthetica.SyntheticaBlueIceLookAndFeel");
		UIManager.installLookAndFeel("Synthetica BlueMoon",
				"de.javasoft.plaf.synthetica.SyntheticaBlueMoonLookAndFeel");
		UIManager.installLookAndFeel("Synthetica BlueSteel",
				"de.javasoft.plaf.synthetica.SyntheticaBlueSteelLookAndFeel");
		UIManager.installLookAndFeel("Synthetica GreenDream",
				"de.javasoft.plaf.synthetica.SyntheticaGreenDreamLookAndFeel");
		UIManager
				.installLookAndFeel("Synthetica MauveMetallic",
						"de.javasoft.plaf.synthetica.SyntheticaMauveMetallicLookAndFeel");
		UIManager
				.installLookAndFeel("Synthetica OrangeMetallic",
						"de.javasoft.plaf.synthetica.SyntheticaOrangeMetallicLookAndFeel");
		UIManager.installLookAndFeel("Synthetica SkyMetallic",
				"de.javasoft.plaf.synthetica.SyntheticaSkyMetallicLookAndFeel");
		UIManager.installLookAndFeel("Synthetica SilverMoon",
				"de.javasoft.plaf.synthetica.SyntheticaSilverMoonLookAndFeel");
		UIManager.installLookAndFeel("Synthetica WhiteVision",
				"de.javasoft.plaf.synthetica.SyntheticaWhiteVisionLookAndFeel");

		UIManager.installLookAndFeel("A03", "a03.swing.plaf.A03LookAndFeel");
		UIManager.installLookAndFeel("Liquid",
				"com.birosoft.liquid.LiquidLookAndFeel");
		UIManager.installLookAndFeel("Napkin",
				"net.sourceforge.napkinlaf.NapkinLookAndFeel");
		UIManager.installLookAndFeel("Pagosoft",
				"com.pagosoft.plaf.PgsLookAndFeel");
		UIManager.installLookAndFeel("Squareness",
				"net.beeger.squareness.SquarenessLookAndFeel");

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				BasicCheckRibbon c = new BasicCheckRibbon();
				c.configureRibbon();
				Rectangle r = GraphicsEnvironment.getLocalGraphicsEnvironment()
						.getMaximumWindowBounds();
				c.setPreferredSize(new Dimension(r.width, r.height / 2));
				c.pack();
				// center the frame in the physical screen
				c.setLocation(r.x, r.y);
				c.setVisible(true);
				c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
	}
}
