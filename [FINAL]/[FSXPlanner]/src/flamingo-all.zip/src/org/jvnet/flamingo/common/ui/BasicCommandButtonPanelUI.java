/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common.ui;

import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;

import org.jvnet.flamingo.common.AbstractCommandButton;
import org.jvnet.flamingo.common.JCommandButtonPanel;
import org.jvnet.flamingo.utils.FlamingoUtilities;

/**
 * Basic UI for command button panel {@link JCommandButtonPanel}.
 * 
 * @author Kirill Grouchnikov
 */
public class BasicCommandButtonPanelUI extends CommandButtonPanelUI {
	protected JCommandButtonPanel buttonPanel;

	protected Rectangle[] groupRects;

	protected PropertyChangeListener propertyChangeListener;

	protected static final Insets INSETS = new Insets(4, 4, 4, 4);

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicCommandButtonPanelUI((JCommandButtonPanel) c);
	}

	public BasicCommandButtonPanelUI(JCommandButtonPanel panel) {
	}

	@Override
	public void installUI(JComponent c) {
		this.buttonPanel = (JCommandButtonPanel) c;

		this.buttonPanel.setLayout(createLayoutManager());
		installDefaults();
		installComponents();
		installListeners();
	}

	protected void installDefaults() {
		this.buttonPanel.setLayout(new CommandButtonPanelLayout());

		Font titleFont = FlamingoUtilities.getFont("CommandButtonPanel.font",
				"Button.font", "Panel.font");
		this.buttonPanel.setFont(titleFont);
	}

	protected void installComponents() {
	}

	protected void installListeners() {
		this.propertyChangeListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if ("maxButtonColumns".equals(evt.getPropertyName())) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							buttonPanel.doLayout();
						}
					});
				}

				if ("toShowGroupLabels".equals(evt.getPropertyName())) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							buttonPanel.doLayout();
						}
					});
				}
			}
		};
		this.buttonPanel.addPropertyChangeListener(this.propertyChangeListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		c.setLayout(null);

		uninstallListeners();
		uninstallComponents();
		uninstallDefaults();
		this.buttonPanel = null;
	}

	protected void uninstallDefaults() {
	}

	protected void uninstallComponents() {
	}

	protected void uninstallListeners() {
		this.buttonPanel
				.removePropertyChangeListener(this.propertyChangeListener);
		this.propertyChangeListener = null;
	}

	protected LayoutManager createLayoutManager() {
		return new CommandButtonPanelLayout();
	}

	@Override
	public void paint(Graphics g, JComponent c) {
		for (int i = 0; i < this.buttonPanel.getGroupCount(); i++) {
			Rectangle groupRect = this.groupRects[i];
			this.paintGroupBackground(g, i, groupRect.x, groupRect.y,
					groupRect.width, groupRect.height);
			if (buttonPanel.isToShowGroupLabels()) {
				this.paintGroupTitle(g, this.buttonPanel.getGroupTitleAt(i), i,
						groupRect.x, groupRect.y, groupRect.width,
						groupRect.height);
			}
		}
	}

	protected void paintGroupBackground(Graphics g, int groupIndex, int x,
			int y, int width, int height) {
		Color c = UIManager.getColor("Panel.background");
		if (c == null)
			c = new Color(190, 190, 190);
		if (groupIndex % 2 == 1) {
			c = c.darker();
		}
		g.setColor(c);
		g.fillRect(x, y, width, height);
	}

	protected void paintGroupTitle(Graphics g, String groupTitle,
			int groupIndex, int x, int y, int width, int height) {
		Color color = UIManager.getColor("Label.foreground");
		if (color == null)
			color = Color.black;
		g.setColor(color);
		int titleHeight = getGroupTitleHeight();
		g.drawString(groupTitle, x + 5, y + titleHeight - 2);
	}

	protected int getGroupTitleHeight() {
		JLabel dummy = new JLabel(" ");
		return dummy.getPreferredSize().height;
	}

	protected Insets getGroupInsets() {
		return INSETS;
	}

	/**
	 * Layout for the button panel.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class CommandButtonPanelLayout implements LayoutManager {
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component comp) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component comp) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container parent) {
			Insets bInsets = parent.getInsets();
			Insets groupInsets = getGroupInsets();
			int left = bInsets.left;
			int right = bInsets.right;
			int top = bInsets.top + groupInsets.top;
			// int bottom = bInsets.bottom + STRUT;
			int y = top;

			JCommandButtonPanel panel = (JCommandButtonPanel) parent;

			// compute max width of buttons
			int maxButtonWidth = 0;
			int maxButtonHeight = 0;
			int groupCount = panel.getGroupCount();
			for (int i = 0; i < groupCount; i++) {
				for (AbstractCommandButton button : panel.getGroupButtons(i)) {
					maxButtonWidth = Math.max(maxButtonWidth, button
							.getPreferredSize().width);
					maxButtonHeight = Math.max(maxButtonHeight, button
							.getPreferredSize().height);
				}
			}
			groupRects = new Rectangle[groupCount];

			int gap = getLayoutGap();
			int maxWidth = parent.getWidth() - bInsets.left - bInsets.right
					- groupInsets.left - groupInsets.right;
			// for N buttons, there are N-1 gaps. Add the gap to the
			// available width and divide by the max button width + gap.
			int buttonsInRow = (maxButtonWidth == 0) ? 0 : (maxWidth + gap)
					/ (maxButtonWidth + gap);

			for (int i = 0; i < groupCount; i++) {
				int topGroupY = y;
				y += groupInsets.top;
				y += buttonPanel.isToShowGroupLabels() ? getGroupTitleHeight()
						: 0;
				int currX = left + groupInsets.left;

				int buttonRows = (buttonsInRow == 0) ? 0 : (int) (Math
						.ceil((double) panel.getGroupButtons(i).size()
								/ buttonsInRow));
				// spread the buttons so that we don't have extra space
				// on the right
				int actualButtonWidth = (buttonRows > 1) ? (maxWidth - (buttonsInRow - 1)
						* gap)
						/ buttonsInRow
						: maxButtonWidth;

				for (AbstractCommandButton button : panel.getGroupButtons(i)) {
					int endX = currX + actualButtonWidth;
					if (endX > (parent.getWidth() - right - groupInsets.right)) {
						currX = left + groupInsets.left;
						y += maxButtonHeight;
						y += gap;
					}
					button.setBounds(currX, y, actualButtonWidth,
							maxButtonHeight);
					// System.out.println(button.getText() + ":"
					// + button.isVisible() + ":" + button.getBounds());
					currX += actualButtonWidth;
					currX += gap;
				}
				y += maxButtonHeight + groupInsets.bottom;
				int bottomGroupY = y;
				groupRects[i] = new Rectangle(left, topGroupY, (parent
						.getWidth()
						- left - right), (bottomGroupY - topGroupY));
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container parent) {
			return this.preferredLayoutSize(parent);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container parent) {
			JCommandButtonPanel panel = (JCommandButtonPanel) parent;

			int maxButtonColumnsToUse = panel.getMaxButtonColumns();

			// go over all groups and see how many rows each one needs
			Insets bInsets = parent.getInsets();
			// int left = bInsets.left + STRUT;
			// int right = bInsets.right + STRUT;
			Insets groupInsets = getGroupInsets();
			int top = bInsets.top + groupInsets.top;
			int bottom = bInsets.bottom + groupInsets.bottom;
			int height = top + bottom;

			// compute max width of buttons
			int maxButtonWidth = 0;
			int maxButtonHeight = 0;
			int groupCount = panel.getGroupCount();
			for (int i = 0; i < groupCount; i++) {
				for (AbstractCommandButton button : panel.getGroupButtons(i)) {
					maxButtonWidth = Math.max(maxButtonWidth, button
							.getPreferredSize().width);
					maxButtonHeight = Math.max(maxButtonHeight, button
							.getPreferredSize().height);
				}
			}
			// int maxWidth = maxWidthToUse - bInsets.left - bInsets.right
			// - groupInsets.left - groupInsets.right;
			// int buttonsInRow = (maxButtonWidth == 0) ? 0 : maxWidth
			// / maxButtonWidth;

			// total height
			int gap = getLayoutGap();
			boolean usePanelWidth = (maxButtonColumnsToUse <= 0);
			if (usePanelWidth) {
				// this hasn't been set. Compute using the available
				// width
				maxButtonColumnsToUse = (panel.getWidth() + gap)
						/ (maxButtonWidth + gap);
			}
			for (int i = 0; i < groupCount; i++) {
				height += buttonPanel.isToShowGroupLabels() ? getGroupTitleHeight()
						: 0;

				height += (groupInsets.top + groupInsets.bottom);

				int buttonRows = (int) (Math.ceil((double) panel
						.getGroupButtons(i).size()
						/ maxButtonColumnsToUse));
				height += buttonRows * maxButtonHeight + (buttonRows - 1) * gap;
			}
			int prefWidth = usePanelWidth ? panel.getWidth()
					: maxButtonColumnsToUse * maxButtonWidth
							+ (maxButtonColumnsToUse - 1) * gap + bInsets.left
							+ bInsets.right + groupInsets.left
							+ groupInsets.right;
			return new Dimension(prefWidth, height);
		}
	}

	protected int getLayoutGap() {
		return 4;
	}
}
