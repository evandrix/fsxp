/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common.icon;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.SwingWorker;

import org.apache.batik.util.EventDispatcher;
import org.apache.batik.util.EventDispatcher.Dispatcher;
import org.jvnet.flamingo.common.AsynchronousLoadListener;
import org.jvnet.flamingo.common.AsynchronousLoading;
import org.jvnet.flamingo.utils.FlamingoUtilities;

abstract class ImageWrapperIcon implements Icon, AsynchronousLoading {
	/**
	 * The current image.
	 */
	protected BufferedImage bufferedImage;

	protected InputStream imageInputStream;

	protected BufferedImage originalImage;

	/**
	 * Contains all precomputed images.
	 */
	protected Map<String, BufferedImage> cachedImages = new LinkedHashMap<String, BufferedImage>() {
		@Override
		protected boolean removeEldestEntry(
				Map.Entry<String, BufferedImage> eldest) {
			return size() > 5;
		};
	};

	/**
	 * The width of the rendered image.
	 */
	protected int width;

	/**
	 * The height of the rendered image.
	 */
	protected int height;

	/**
	 * The listeners.
	 */
	protected List asyncListeners;

	/**
	 * Create a new SVG icon.
	 * 
	 * @param inputStream
	 *            The input stream to read the SVG document from.
	 * @param w
	 *            The width of the icon.
	 * @param h
	 *            The height of the icon.
	 */
	@SuppressWarnings("unchecked")
	public ImageWrapperIcon(InputStream inputStream, int w, int h)
			throws IOException {
		this.imageInputStream = inputStream;
		this.width = w;
		this.height = h;
		this.asyncListeners = Collections.synchronizedList(new LinkedList());
		this.renderImage();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.flamingo.common.AsynchronousLoading#addAsynchronousLoadListener(org.jvnet.flamingo.common.AsynchronousLoadListener)
	 */
	@SuppressWarnings("unchecked")
	public void addAsynchronousLoadListener(AsynchronousLoadListener l) {
		asyncListeners.add(l);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.flamingo.common.AsynchronousLoading#removeAsynchronousLoadListener(org.jvnet.flamingo.common.AsynchronousLoadListener)
	 */
	public void removeAsynchronousLoadListener(AsynchronousLoadListener l) {
		asyncListeners.remove(l);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#getIconWidth()
	 */
	public int getIconWidth() {
		return width;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#getIconHeight()
	 */
	public int getIconHeight() {
		return height;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#paintIcon(java.awt.Component, java.awt.Graphics,
	 *      int, int)
	 */
	public void paintIcon(Component c, Graphics g, int x, int y) {
		// System.out.println("Paint " + bufferedImage);
		if (bufferedImage != null) {
			int dx = (this.width - bufferedImage.getWidth()) / 2;
			int dy = (this.height - bufferedImage.getHeight()) / 2;
			g.drawImage(bufferedImage, x + dx, y + dy, null);
		}
	}

	/**
	 * Sets the preferred size for <code>this</code> icon. The rendering is
	 * scheduled automatically.
	 * 
	 * @param dim
	 *            Preferred size.
	 */
	public synchronized void setPreferredSize(Dimension dim) {
		this.width = dim.width;
		this.height = dim.height;

		// System.out.println("Before call to render");
		this.renderImage();
		// System.out.println("After call to render");
	}

	/**
	 * Renders the image.
	 */
	protected synchronized boolean renderImage() {
		// System.out.println("In render - requested size " + this.width + "*"
		// + this.height);

		String key = this.width + ":" + this.height;
		if (this.cachedImages.containsKey(key)) {
			this.bufferedImage = this.cachedImages.get(key);
			fireAsyncEvent(asyncCompletedDispatcher, true);
			return true;
		}

		// System.out.println("Starting worker");

		SwingWorker<BufferedImage, Void> worker = new SwingWorker<BufferedImage, Void>() {
			@Override
			protected BufferedImage doInBackground() throws Exception {
				synchronized (imageInputStream) {
					if (originalImage == null) {
						// System.out.println("Loading input stream");
						// read original image
						originalImage = ImageIO.read(imageInputStream);
					}
				}
				// System.out.println("Input stream " + originalImage);

				BufferedImage result = originalImage;
				float scaleX = (float) originalImage.getWidth() / (float) width;
				float scaleY = (float) originalImage.getHeight()
						/ (float) height;

				float scale = Math.max(scaleX, scaleY);
				if (scale > 1.0f) {
					int finalWidth = (int) (originalImage.getWidth() / scale);
					result = FlamingoUtilities.createThumbnail(originalImage,
							finalWidth);
				}

				return result;
			}

			@Override
			protected void done() {
				try {
					bufferedImage = get();

					cachedImages.put(width + ":" + height, bufferedImage);

					fireAsyncEvent(asyncCompletedDispatcher, true);
				} catch (Exception exc) {
					fireAsyncEvent(asyncCompletedDispatcher, false);
				}
			}
		};
		worker.execute();

		// executorService.execute(new Renderer(this.width, this.height));
		return false;
	}

	/**
	 * Fires an asynchronous event on the specified dispatcher.
	 * 
	 * @param dispatcher
	 *            Event dispatcher.
	 * @param event
	 *            Event.
	 */
	protected void fireAsyncEvent(Dispatcher dispatcher, Object event) {
		EventDispatcher.fireEvent(dispatcher, asyncListeners, event, true);
	}

	/**
	 * Dispatcher for rendering completion.
	 */
	static Dispatcher asyncCompletedDispatcher = new Dispatcher() {
		public void dispatch(Object listener, Object event) {
			((AsynchronousLoadListener) listener).completed((Boolean) event);
		}
	};
}
