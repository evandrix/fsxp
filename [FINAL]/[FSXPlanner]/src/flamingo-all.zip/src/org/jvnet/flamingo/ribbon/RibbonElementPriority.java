package org.jvnet.flamingo.ribbon;

/**
 * Priority of band components.
 * 
 * @author Kirill Grouchnikov
 */
public enum RibbonElementPriority {
	/**
	 * Top priority.
	 */
	TOP,

	/**
	 * Medium priority.
	 */
	MEDIUM,

	/**
	 * Low priority.
	 */
	LOW
}