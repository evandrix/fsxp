/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.svg;

import java.awt.*;
import java.awt.geom.Dimension2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.Icon;

import org.apache.batik.bridge.InterruptedBridgeException;
import org.apache.batik.bridge.UserAgentAdapter;
import org.apache.batik.swing.gvt.*;
import org.apache.batik.transcoder.*;
import org.apache.batik.transcoder.image.ImageTranscoder;
import org.apache.batik.util.EventDispatcher;
import org.apache.batik.util.EventDispatcher.Dispatcher;
import org.jvnet.flamingo.utils.FlamingoUtilities;

/**
 * A Swing Icon that draws an SVG image.
 * 
 * @author <a href="mailto:cam%40mcc%2eid%2eau">Cameron McCormack</a>
 * @authot <a href="mailto:kirillcool%40yahoo%2ecom">Kirill Grouchnikov</a>
 */
public class SvgBatikIcon extends UserAgentAdapter implements Icon {
	/**
	 * The current image generated from the SVG document.
	 */
	protected BufferedImage bufferedImage;

	/**
	 * Contains all precomputed images.
	 */
	protected Map<String, BufferedImage> cachedImages = new HashMap<String, BufferedImage>();

	/**
	 * The width of the rendered image.
	 */
	protected int width;

	/**
	 * The height of the rendered image.
	 */
	protected int height;

	/**
	 * SVG byte array.
	 */
	protected byte[] svgBytes;

	/**
	 * Whether a render was requested.
	 */
	protected boolean needRender;

	/**
	 * The listener.
	 */
	protected Listener listener;

	/**
	 * The listeners.
	 */
	protected List listeners;

	/**
	 * The currently running renderer.
	 */
	protected Renderer renderer;

	/**
	 * Executor service.
	 */
	protected static ExecutorService executorService = Executors
			.newFixedThreadPool(10);

	/**
	 * Create a new SVG icon.
	 * 
	 * @param inputStream
	 *            The input stream to read the SVG document from.
	 * @param w
	 *            The width of the icon.
	 * @param h
	 *            The height of the icon.
	 */
	@SuppressWarnings("unchecked")
	public SvgBatikIcon(InputStream inputStream, int w, int h)
			throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] b = new byte[1024];
		while (true) {
			int count = inputStream.read(b);
			if (count < 0)
				break;
			baos.write(b, 0, count);
		}
		this.svgBytes = baos.toByteArray();
		this.width = w;
		this.height = h;
		this.listeners = Collections.synchronizedList(new LinkedList());

		this.addGVTTreeRendererListener(new Listener());
		this.scheduleGVTRendering();
	}

	/**
	 * Renderer thread.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class Renderer implements Runnable {
		/**
		 * Input for the transcoder.
		 */
		byte[] in;

		/**
		 * Requested width.
		 */
		int width;

		/**
		 * Requested height.
		 */
		int height;

		/**
		 * Creates renderer.
		 * 
		 * @param in
		 *            Input for the transcoder.
		 * @param width
		 *            Requested width.
		 * @param height
		 *            Requested height.
		 */
		public Renderer(byte[] in, int width, int height) {
			super();
			this.in = in;
			this.width = width;
			this.height = height;
		}

		public void run() {
			// System.out.println("Running for " + width + "*" + height);
			GVTTreeRendererEvent ev = new GVTTreeRendererEvent(this, null);
			try {
				// if (isHalted()) {
				// fireEvent(cancelledDispatcher, ev);
				// return;
				// }
				//
				ev = new GVTTreeRendererEvent(this, null);
				fireEvent(startedDispatcher, ev);

				BufferedImageTranscoder t = new BufferedImageTranscoder();
				if (width != 0 && height != 0) {
					t.setDimensions(width, height);
				}

				// t.transcode(in, new TranscoderOutput(new
				// BufferedOutputStream(
				// new ByteArrayOutputStream())));

				// FileOutputStream fos = null;
				// try {
				// fos = new FileOutputStream(
				// "C:/jtools/tango-icon-theme-0.8.0/scalable/actions/edit-copy.jpg");
				// } catch (FileNotFoundException e) {
				// System.out.println(e);
				// }
				// OutputStream os = new BufferedOutputStream(fos);
				//
				// System.out.println("Creating InputStream...");

				// FileInputStream fis = null;
				// try {
				// fis = new FileInputStream(
				// "C:/jtools/tango-icon-theme-0.8.0/scalable/actions/edit-copy.svg");
				// } catch (FileNotFoundException e) {
				// System.out.println(e);
				// }
				InputStream is = new ByteArrayInputStream(this.in);

				// System.out.println("Creating TranscoderInput/Output...");

				TranscoderInput ti = new TranscoderInput(is);
				// TranscoderOutput to = new TranscoderOutput(os);

				// System.out.println("Transcoding...");

				t.transcode(ti, null);

				bufferedImage = t.getBufferedImage();
				width = bufferedImage.getWidth();
				height = bufferedImage.getHeight();

				synchronized (SvgBatikIcon.this) {
					cachedImages.put(width + ":" + height, bufferedImage);
				}

				// if (isHalted()) {
				// fireEvent(cancelledDispatcher, ev);
				// return;
				// }
				//
				ev = new GVTTreeRendererEvent(this, bufferedImage);
				fireEvent(completedDispatcher, ev);
			} catch (InterruptedBridgeException e) {
				// this sometimes happens with SVG Fonts since the glyphs
				// are
				// not built till the rendering stage
				fireEvent(cancelledDispatcher, ev);
			} catch (ThreadDeath td) {
				fireEvent(failedDispatcher, ev);
				throw td;
			} catch (Throwable t) {
				// t.printStackTrace();
				fireEvent(failedDispatcher, ev);
			}
		}
	}

	/**
	 * A transcoder that generates a BufferedImage.
	 */
	public static class BufferedImageTranscoder extends ImageTranscoder {

		/**
		 * The BufferedImage generated from the SVG document.
		 */
		protected BufferedImage bufferedImage;

		/**
		 * Creates a new ARGB image with the specified dimension.
		 * 
		 * @param width
		 *            the image width in pixels
		 * @param height
		 *            the image height in pixels
		 */
		@Override
		public BufferedImage createImage(int width, int height) {
			return new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		}

		/**
		 * Writes the specified image to the specified output.
		 * 
		 * @param img
		 *            the image to write
		 * @param output
		 *            the output where to store the image
		 * @param TranscoderException
		 *            if an error occured while storing the image
		 */
		@Override
		public void writeImage(BufferedImage img, TranscoderOutput output)
				throws TranscoderException {
			bufferedImage = img;
		}

		/**
		 * Returns the {@link BufferedImage} generated from the SVG document.
		 * 
		 * @return {@link BufferedImage} generated from the SVG document.
		 */
		public BufferedImage getBufferedImage() {
			return bufferedImage;
		}

		/**
		 * Set the dimensions to be used for the image.
		 * 
		 * @param w
		 *            Width.
		 * @param h
		 *            Height.
		 */
		public void setDimensions(int w, int h) {
			hints.put(KEY_WIDTH, new Float(w));
			hints.put(KEY_HEIGHT, new Float(h));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#getIconWidth()
	 */
	public int getIconWidth() {
		return width;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#getIconHeight()
	 */
	public int getIconHeight() {
		return height;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.Icon#paintIcon(java.awt.Component, java.awt.Graphics,
	 *      int, int)
	 */
	public void paintIcon(Component c, Graphics g, int x, int y) {
		// System.out.println("Paint " + bufferedImage);
		if (bufferedImage != null) {
			int currWidth = this.bufferedImage.getWidth();
			if (currWidth == this.width) {
				g.drawImage(bufferedImage, x, y, null);
			} else {
				g.drawImage(FlamingoUtilities.createThumbnail(
						this.bufferedImage, this.width), x, y, null);
			}
		}
	}

	// UserAgent /////////////////////////////////////////////////////////////

	/**
	 * Returns the default size of this user agent.
	 */
	@Override
	public Dimension2D getViewportSize() {
		return new Dimension(width, height);
	}

	/**
	 * Sets the preferred size for <code>this</code> icon. The rendering is
	 * scheduled automatically.
	 * 
	 * @param dim
	 *            Preferred size.
	 */
	public synchronized void setPreferredSize(Dimension dim) {
		this.width = dim.width;
		this.height = dim.height;
		this.scheduleGVTRendering();
	}

	public byte[] getSvgBytes() {
		return this.svgBytes;
	}

	/**
	 * Fires event.
	 * 
	 * @param dispatcher
	 *            Event dispatcher.
	 * @param event
	 *            Event data.
	 */
	public void fireEvent(Dispatcher dispatcher, Object event) {
		EventDispatcher.fireEvent(dispatcher, listeners, event, true);
	}

	/**
	 * Schedules a new GVT rendering.
	 */
	protected void scheduleGVTRendering() {
		if (renderer != null) {
			needRender = true;
			// renderer.halt();
		} else {
			renderGVTTree();
		}
	}

	/**
	 * Renders the GVT tree.
	 */
	protected boolean renderGVTTree() {
		String key = this.width + ":" + this.height;
		if (this.cachedImages.containsKey(key)) {
			this.bufferedImage = this.cachedImages.get(key);
			return true;
		}

		// if (renderer != null)
		// renderer.halt();
		//
		// TranscoderInput ti = null;
		// if (this.uri != null)
		// ti = new TranscoderInput(this.uri);
		// else {
		// if (this.inputStream != null) {
		// ti = new TranscoderInput(this.inputStream);
		// }
		// }

		executorService.execute(new Renderer(this.svgBytes, this.width,
				this.height));
		return false;
		//
		// renderer = new Renderer(new TranscoderInput(this.uri), this.width,
		// this.height);
		// renderer.setPriority(Thread.MIN_PRIORITY);
		//
		// renderer.start();
	}

	/**
	 * To hide the listener methods.
	 */
	protected class Listener implements GVTTreeRendererListener {

		/**
		 * Creates a new Listener.
		 */
		protected Listener() {
		}

		/**
		 * Called when a rendering is in its preparing phase.
		 */
		public void gvtRenderingPrepare(GVTTreeRendererEvent e) {
		}

		/**
		 * Called when a rendering started.
		 */
		public void gvtRenderingStarted(GVTTreeRendererEvent e) {
		}

		/**
		 * Called when a rendering was completed.
		 */
		public void gvtRenderingCompleted(GVTTreeRendererEvent e) {
			renderer = null;
			if (needRender) {
				renderGVTTree();
				needRender = false;
			}
		}

		/**
		 * Called when a rendering was cancelled.
		 */
		public void gvtRenderingCancelled(GVTTreeRendererEvent e) {
			renderingStopped();
		}

		/**
		 * Called when a rendering failed.
		 */
		public void gvtRenderingFailed(GVTTreeRendererEvent e) {
			renderingStopped();
		}

		/**
		 * The actual implementation of gvtRenderingCancelled() and
		 * gvtRenderingFailed().
		 */
		private void renderingStopped() {
			renderer = null;
			if (needRender) {
				renderGVTTree();
				needRender = false;
			}
		}
	}

	/**
	 * Adds a {@link GVTTreeRendererListener} to this {@link GVTTreeRenderer}.
	 * 
	 * @param l
	 *            Listener to add.
	 */
	@SuppressWarnings("unchecked")
	public void addGVTTreeRendererListener(GVTTreeRendererListener l) {
		listeners.add(l);
	}

	/**
	 * Removes a {@link GVTTreeRendererListener}ner from this
	 * {@link GVTTreeRenderer}.
	 * 
	 * @param l
	 *            Listener to remove.
	 */
	public void removeGVTTreeRendererListener(GVTTreeRendererListener l) {
		listeners.remove(l);
	}

	/**
	 * Dispatcher for GVT tree rendering completion.
	 */
	static Dispatcher completedDispatcher = new Dispatcher() {
		public void dispatch(Object listener, Object event) {
			((GVTTreeRendererListener) listener)
					.gvtRenderingCompleted((GVTTreeRendererEvent) event);
		}
	};

	/**
	 * Dispatcher for GVT tree rendering start.
	 */
	static Dispatcher startedDispatcher = new Dispatcher() {
		public void dispatch(Object listener, Object event) {
			((GVTTreeRendererListener) listener)
					.gvtRenderingStarted((GVTTreeRendererEvent) event);
		}
	};

	/**
	 * Dispatcher for GVT tree rendering fail.
	 */
	static Dispatcher failedDispatcher = new Dispatcher() {
		public void dispatch(Object listener, Object event) {
			((GVTTreeRendererListener) listener)
					.gvtRenderingFailed((GVTTreeRendererEvent) event);
		}
	};

	/**
	 * Dispatcher for GVT tree rendering cancel.
	 */
	static Dispatcher cancelledDispatcher = new Dispatcher() {
		public void dispatch(Object listener, Object event) {
			((GVTTreeRendererListener) listener)
					.gvtRenderingCancelled((GVTTreeRendererEvent) event);
		}
	};
}
