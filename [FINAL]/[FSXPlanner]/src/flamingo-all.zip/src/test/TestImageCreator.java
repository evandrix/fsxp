/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package test;

import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;

import javax.swing.Icon;
import javax.swing.ImageIcon;

public class TestImageCreator {
	public static final String FONT_NAME = "Serif";

	public static final String FONT_NAME2 = "Tahoma";

	/**
	 * Retrieves transparent image of specified dimension.
	 * 
	 * @param width
	 *            Image width.
	 * @param height
	 *            Image height.
	 * @return Transparent image of specified dimension.
	 */
	public static BufferedImage getBlankImage(int width, int height) {
		BufferedImage image = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_ARGB);

		// get graphics and set hints
		Graphics2D graphics = (Graphics2D) image.getGraphics().create();
		graphics.setColor(new Color(0, 0, 0, 0));
		graphics.setComposite(AlphaComposite.Src);
		graphics.fillRect(0, 0, width, height);
		graphics.dispose();

		return image;
	}

	public static Icon getBoldIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 12));

		graphics.drawString("B", 7, 14);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getItalicIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME, Font.ITALIC | Font.BOLD, 12));

		graphics.drawString("I", 8, 14);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getUnderlineIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 12));

		graphics.drawString("U", 7, 14);
		graphics.drawLine(7, 15, 15, 15);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getStrikeIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME2, Font.BOLD, 10));

		graphics.drawString("abc", 3, 14);
		graphics.drawLine(3, 11, 20, 11);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getSubscriptIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 12));
		graphics.drawString("X", 5, 13);
		graphics.setColor(new Color(0, 0, 128));
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 9));
		graphics.drawString("2", 14, 16);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getSuperscriptIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 12));
		graphics.drawString("X", 5, 15);
		graphics.setColor(new Color(0, 0, 128));
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 9));
		graphics.drawString("2", 14, 11);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getFontsIcon() {
		BufferedImage bi = getBlankImage(39, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME2, Font.BOLD, 12));
		graphics.drawString("A", 5, 15);
		graphics.setFont(new Font(FONT_NAME2, Font.BOLD, 10));
		graphics.drawString("A", 14, 15);
		graphics.setFont(new Font(FONT_NAME2, Font.PLAIN, 10));
		graphics.drawString("a", 22, 15);

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 29, 33, 31 }, new int[] { 10, 10,
				12 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getFontColorIcon() {
		BufferedImage bi = getBlankImage(33, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 12));
		graphics.drawString("A", 5, 12);

		graphics.fillRect(5, 13, 12, 3);

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 23, 27, 25 }, new int[] { 10, 10,
				12 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getBackColorIcon() {
		BufferedImage bi = getBlankImage(33, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.yellow);
		graphics.fillRect(5, 2, 11, 9);
		graphics.fillRect(5, 13, 12, 3);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME2, Font.BOLD, 10));
		graphics.drawString("ab", 5, 10);

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 23, 27, 25 }, new int[] { 10, 10,
				12 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getFontIncreaseIcon() {
		BufferedImage bi = getBlankImage(24, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 13));
		graphics.drawString("A", 5, 15);

		graphics.setColor(new Color(0, 0, 128));
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 12, 16, 14 },
				new int[] { 6, 6, 4 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getFontDecreaseIcon() {
		BufferedImage bi = getBlankImage(24, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 11));
		graphics.drawString("A", 5, 15);

		graphics.setColor(new Color(0, 0, 128));
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 11, 15, 13 },
				new int[] { 5, 5, 7 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getListNumbersIcon() {
		BufferedImage bi = getBlankImage(33, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(new Color(0, 0, 128));
		graphics.setFont(new Font(FONT_NAME2, Font.BOLD, 6));
		graphics.drawString("1", 5, 8);
		graphics.drawString("2", 5, 13);
		graphics.drawString("3", 5, 18);

		graphics.setColor(Color.black);
		graphics.drawLine(10, 5, 18, 5);
		graphics.drawLine(10, 10, 18, 10);
		graphics.drawLine(10, 15, 18, 15);

		graphics.setColor(new Color(0, 0, 128));
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 23, 27, 25 }, new int[] { 10, 10,
				12 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getListBulletsIcon() {
		BufferedImage bi = getBlankImage(33, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(new Color(0, 0, 196));
		graphics.setFont(new Font(FONT_NAME2, Font.BOLD, 6));
		graphics.fillOval(5, 3, 4, 4);
		graphics.fillOval(5, 8, 4, 4);
		graphics.fillOval(5, 13, 4, 4);

		graphics.setColor(Color.black);
		graphics.drawLine(10, 5, 18, 5);
		graphics.drawLine(10, 10, 18, 10);
		graphics.drawLine(10, 15, 18, 15);

		graphics.setColor(new Color(0, 0, 128));
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 23, 27, 25 }, new int[] { 10, 10,
				12 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getListInnerIcon() {
		BufferedImage bi = getBlankImage(33, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(new Color(0, 0, 196));
		graphics.setFont(new Font(FONT_NAME2, Font.BOLD, 6));
		graphics.fillOval(5, 3, 4, 4);
		graphics.setFont(new Font(FONT_NAME2, Font.BOLD, 6));
		graphics.drawString("1", 8, 13);
		graphics.fillOval(11, 13, 4, 4);

		graphics.setColor(Color.black);
		graphics.drawLine(10, 5, 18, 5);
		graphics.drawLine(13, 10, 18, 10);
		graphics.drawLine(16, 15, 18, 15);

		graphics.setColor(new Color(0, 0, 128));
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 23, 27, 25 }, new int[] { 10, 10,
				12 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getIndentLeftIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(new Color(0, 0, 196));
		GeneralPath arrow = new GeneralPath();
		arrow.moveTo(9, 9);
		arrow.lineTo(6, 9);
		arrow.lineTo(8, 7);
		arrow.lineTo(3, 9);
		arrow.lineTo(8, 11);
		arrow.lineTo(6, 9);
		graphics.fill(arrow);
		graphics.draw(arrow);

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		graphics.setColor(Color.black);
		graphics.drawLine(11, 3, 11, 3);
		graphics.drawLine(5, 5, 9, 5);
		graphics.drawLine(11, 5, 20, 5);
		graphics.fillRect(11, 7, 10, 2);
		graphics.fillRect(11, 10, 7, 2);
		graphics.drawLine(5, 13, 9, 13);
		graphics.drawLine(11, 13, 20, 13);
		graphics.drawLine(5, 15, 9, 15);
		graphics.drawLine(11, 15, 13, 15);
		graphics.drawLine(11, 17, 11, 17);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getIndentRightIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(new Color(0, 0, 196));
		GeneralPath arrow = new GeneralPath();
		arrow.moveTo(3, 9);
		arrow.lineTo(6, 9);
		arrow.lineTo(4, 7);
		arrow.lineTo(8, 9);
		arrow.lineTo(4, 11);
		arrow.lineTo(6, 9);
		graphics.fill(arrow);
		graphics.draw(arrow);

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		graphics.setColor(Color.black);
		graphics.drawLine(11, 3, 11, 3);
		graphics.drawLine(5, 5, 9, 5);
		graphics.drawLine(11, 5, 20, 5);
		graphics.fillRect(11, 7, 10, 2);
		graphics.fillRect(11, 10, 7, 2);
		graphics.drawLine(5, 13, 9, 13);
		graphics.drawLine(11, 13, 20, 13);
		graphics.drawLine(5, 15, 9, 15);
		graphics.drawLine(11, 15, 13, 15);
		graphics.drawLine(11, 17, 11, 17);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getFontSortIcon() {
		BufferedImage bi = getBlankImage(24, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setFont(new Font(FONT_NAME, Font.BOLD, 10));
		graphics.setColor(new Color(0, 0, 128));
		graphics.drawString("A", 5, 10);
		graphics.setColor(new Color(128, 0, 0));
		graphics.drawString("Z", 6, 18);

		graphics.setColor(Color.black);
		graphics.drawLine(16, 3, 16, 17);
		graphics.drawLine(14, 13, 16, 17);
		graphics.drawLine(14, 13, 16, 15);
		graphics.drawLine(18, 13, 16, 17);
		graphics.drawLine(18, 13, 16, 15);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getAlignLeftIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setColor(Color.black);
		graphics.drawLine(4, 5, 18, 5);
		graphics.drawLine(4, 7, 15, 7);
		graphics.drawLine(4, 9, 18, 9);
		graphics.drawLine(4, 11, 15, 11);
		graphics.drawLine(4, 13, 18, 13);
		graphics.drawLine(4, 15, 15, 15);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getAlignCenterIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setColor(Color.black);
		graphics.drawLine(4, 5, 18, 5);
		graphics.drawLine(6, 7, 16, 7);
		graphics.drawLine(4, 9, 18, 9);
		graphics.drawLine(6, 11, 16, 11);
		graphics.drawLine(4, 13, 18, 13);
		graphics.drawLine(6, 15, 16, 15);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getAlignRightIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setColor(Color.black);
		graphics.drawLine(4, 5, 18, 5);
		graphics.drawLine(7, 7, 18, 7);
		graphics.drawLine(4, 9, 18, 9);
		graphics.drawLine(7, 11, 18, 11);
		graphics.drawLine(4, 13, 18, 13);
		graphics.drawLine(7, 15, 18, 15);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getAlignFillIcon() {
		BufferedImage bi = getBlankImage(23, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setColor(Color.black);
		graphics.drawLine(4, 5, 18, 5);
		graphics.drawLine(4, 7, 18, 7);
		graphics.drawLine(4, 9, 18, 9);
		graphics.drawLine(4, 11, 18, 11);
		graphics.drawLine(4, 13, 18, 13);
		graphics.drawLine(4, 15, 18, 15);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getSpacingIcon() {
		BufferedImage bi = getBlankImage(37, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(new Color(0, 0, 196));
		GeneralPath arrowTop = new GeneralPath();
		arrowTop.moveTo(8, 9);
		arrowTop.lineTo(8, 5);
		arrowTop.lineTo(6, 6);
		arrowTop.lineTo(8, 3);
		arrowTop.lineTo(10, 6);
		arrowTop.lineTo(8, 5);
		graphics.fill(arrowTop);
		graphics.draw(arrowTop);

		GeneralPath arrowDown = new GeneralPath();
		arrowDown.moveTo(8, 11);
		arrowDown.lineTo(8, 15);
		arrowDown.lineTo(6, 14);
		arrowDown.lineTo(8, 17);
		arrowDown.lineTo(10, 14);
		arrowDown.lineTo(8, 15);
		graphics.fill(arrowDown);
		graphics.draw(arrowDown);

		graphics.setColor(Color.black);
		graphics.drawLine(13, 6, 20, 6);
		graphics.drawLine(13, 9, 20, 9);
		graphics.drawLine(13, 12, 20, 12);
		graphics.drawLine(13, 15, 20, 15);

		graphics.setColor(new Color(0, 0, 128));
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);
		Polygon tri = new Polygon(new int[] { 23, 27, 25 }, new int[] { 10, 10,
				12 }, 3);
		graphics.fillPolygon(tri);
		graphics.drawPolygon(tri);

		graphics.dispose();
		return new ImageIcon(bi);
	}

	public static Icon getParagraphIcon() {
		BufferedImage bi = getBlankImage(24, 20);
		Graphics2D graphics = (Graphics2D) bi.getGraphics().create();

		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(Color.black);
		graphics.drawLine(11, 4, 11, 15);
		graphics.drawLine(11, 4, 16, 4);
		graphics.drawLine(14, 4, 14, 15);
		graphics.fillArc(8, 4, 7, 7, 90, 180);

		graphics.dispose();
		return new ImageIcon(bi);
	}

}
