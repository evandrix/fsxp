package org.jvnet.flamingo.utils;

import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.plaf.*;

import org.jvnet.flamingo.common.icon.ArrowResizableIcon;
import org.jvnet.flamingo.common.icon.ResizableIcon;

public class FlamingoUtilities {
	public static Font getFont(String... keys) {
		for (String key : keys) {
			Font font = UIManager.getFont(key);
			if (font != null) {
				if (font instanceof UIResource)
					return font;
				else
					return new FontUIResource(font);
			}
		}
		return null;
	}

	public static Color getColor(Color defaultColor, String... keys) {
		for (String key : keys) {
			Color color = UIManager.getColor(key);
			if (color != null)
				return color;
		}
		return new ColorUIResource(defaultColor);
	}

	public static ResizableIcon getRibbonBandExpandIcon() {
		return new ArrowResizableIcon(9, SwingConstants.EAST);
		// return new IconUIResource(new Icon() {
		// public int getIconHeight() {
		// return 9;
		// }
		//
		// public int getIconWidth() {
		// return 8;
		// }
		//
		// public void paintIcon(Component c, Graphics g, int x, int y) {
		// g.setColor(Color.black);
		// g.drawLine(x + 1, y + 1, x + 6, y + 4);
		// g.drawLine(x + 1, y + 7, x + 6, y + 4);
		// }
		// });
	}

	public static ResizableIcon getGalleryExpandIcon() {
		return new ArrowResizableIcon(7, SwingConstants.SOUTH);
		//		
		// return new IconUIResource(new Icon() {
		// public int getIconHeight() {
		// return 7;
		// }
		//
		// public int getIconWidth() {
		// return 7;
		// }
		//
		// public void paintIcon(Component c, Graphics g, int x, int y) {
		// g.setColor(Color.black);
		// g.drawLine(x, y + 1, x + 3, y + 4);
		// g.drawLine(x + 3, y + 4, x + 6, y + 1);
		// }
		// });
	}

	/**
	 * Creates a thumbnail of the specified width.
	 * 
	 * @param image
	 *            The original image.
	 * @param requestedThumbWidth
	 *            The width of the resulting thumbnail.
	 * @return Thumbnail of the specified width.
	 * @author Romain Guy
	 */
	public static BufferedImage createThumbnail(BufferedImage image,
			int requestedThumbWidth) {
		float ratio = (float) image.getWidth() / (float) image.getHeight();
		int width = image.getWidth();
		BufferedImage thumb = image;

		do {
			width /= 2;
			if (width < requestedThumbWidth) {
				width = requestedThumbWidth;
			}

			BufferedImage temp = new BufferedImage(width,
					(int) (width / ratio), BufferedImage.TYPE_INT_ARGB);
			Graphics2D g2 = temp.createGraphics();
			g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
					RenderingHints.VALUE_INTERPOLATION_BILINEAR);
			g2.drawImage(thumb, 0, 0, temp.getWidth(), temp.getHeight(), null);
			g2.dispose();

			thumb = temp;
		} while (width != requestedThumbWidth);

		return thumb;
	}

	public static GeneralPath getRibbonBorderOutline(int startX, int endX,
			int startSelectedX, int endSelectedX, int topY, int bandTopY,
			int bottomY, float radius) {
		int height = bottomY - topY;
		GeneralPath result = new GeneralPath();
		float radius3 = (float) (radius / (1.5 * Math.pow(height, 0.5)));

		// start in the top left corner at the end of the curve
		result.moveTo(startX + radius, bandTopY);

		// move to the bottom start of the selected tab and curve up
		result.lineTo(startSelectedX - radius, bandTopY);
		result.quadTo(startSelectedX - radius3, bandTopY - radius3,
				startSelectedX, bandTopY - radius);

		// move to the top start of the selected tab and curve right
		result.lineTo(startSelectedX, topY + radius);
		result.quadTo(startSelectedX + radius3, topY + radius3, startSelectedX
				+ radius, topY);

		// move to the top end of the selected tab and curve down
		result.lineTo(endSelectedX - radius - 1, topY);
		result.quadTo(endSelectedX + radius3 - 1, topY + radius3,
				endSelectedX - 1, topY + radius);

		// move to the bottom end of the selected tab and curve right
		result.lineTo(endSelectedX - 1, bandTopY - radius);
		result.quadTo(endSelectedX + radius3 - 1, bandTopY - radius3,
				endSelectedX + radius - 1, bandTopY);

		// move to the top right corner and curve down
		result.lineTo(endX - radius - 1, bandTopY);
		result.quadTo(endX - radius3 - 1, bandTopY + radius3, endX - 1,
				bandTopY + radius);

		// move to the bottom right corner and curve left
		result.lineTo(endX - 1, bottomY - radius - 1);
		result.quadTo(endX - radius3 - 1, bottomY - 1 - radius3, endX - radius
				- 1, bottomY - 1);

		// move to the bottom left corner and curve up
		result.lineTo(startX + radius, bottomY - 1);
		result.quadTo(startX + radius3, bottomY - 1 - radius3, startX, bottomY
				- radius - 1);

		// move to the top left corner and curve right
		result.lineTo(startX, bandTopY + radius);
		result.quadTo(startX + radius3, bandTopY + radius3, startX + radius,
				bandTopY);

		return result;
	}

	public static GeneralPath getRibbonToggleButtonClip(int width, int height,
			float radius) {
		GeneralPath result = new GeneralPath();
		float radius3 = (float) (radius / (1.5 * Math.pow(height, 0.5)));

		// start at the bottom left
		result.moveTo(0, height);

		// move to the top start and curve right
		result.lineTo(0, radius);
		result.quadTo(radius3, radius3, radius, 0);

		// move to the top end and curve down
		result.lineTo(width - radius - 1, 0);
		result.quadTo(width + radius3 - 1, radius3, width - 1, radius);

		// move to the bottom right end
		result.lineTo(width - 1, height);

		// move to the bottom left end
		result.lineTo(0, height);

		return result;
	}

	public static GeneralPath getRibbonGalleryOutline(int startX, int endX,
			int topY, int bottomY, float radius) {

		int height = bottomY - topY;
		GeneralPath result = new GeneralPath();
		float radius3 = (float) (radius / (1.5 * Math.pow(height, 0.5)));

		// start in the top left corner at the end of the curve
		result.moveTo(startX + radius, topY);

		// move to the top right corner and curve down
		result.lineTo(endX - radius - 1, topY);
		result.quadTo(endX - radius3 - 1, topY + radius3, endX - 1, topY
				+ radius);

		// move to the bottom right corner and curve left
		result.lineTo(endX - 1, bottomY - radius - 1);
		result.quadTo(endX - radius3 - 1, bottomY - 1 - radius3, endX - radius
				- 1, bottomY - 1);

		// move to the bottom left corner and curve up
		result.lineTo(startX + radius, bottomY - 1);
		result.quadTo(startX + radius3, bottomY - 1 - radius3, startX, bottomY
				- radius - 1);

		// move to the top left corner and curve right
		result.lineTo(startX, topY + radius);
		result.quadTo(startX + radius3, topY + radius3, startX + radius, topY);

		return result;
	}
	
	/**
	 * Clips string based on specified font metrics and available width (in
	 * pixels). Returns the clipped string, which contains the beginning and the
	 * end of the input string separated by ellipses (...) in case the string is
	 * too long to fit into the specified width, and the origianl string
	 * otherwise.
	 * 
	 * @param metrics
	 *            Font metrics.
	 * @param availableWidth
	 *            Available width in pixels.
	 * @param fullText
	 *            String to clip.
	 * @return The clipped string, which contains the beginning and the end of
	 *         the input string separated by ellipses (...) in case the string
	 *         is too long to fit into the specified width, and the origianl
	 *         string otherwise.
	 */
	public static String clipString(FontMetrics metrics, int availableWidth,
			String fullText) {

		if (metrics.stringWidth(fullText) <= availableWidth)
			return fullText;

		String ellipses = "...";
		int ellipsesWidth = metrics.stringWidth(ellipses);
		if (ellipsesWidth > availableWidth)
			return "";

		String starter = "";

		int w = fullText.length();
		String prevText = "";
		for (int i = 0; i < w; i++) {
			String newStarter = starter + fullText.charAt(i);
			String newText = newStarter + ellipses;
			if (metrics.stringWidth(newText) <= availableWidth) {
				starter = newStarter;
				prevText = newText;
				continue;
			}
			return prevText;
		}
		return fullText;
	}
}
