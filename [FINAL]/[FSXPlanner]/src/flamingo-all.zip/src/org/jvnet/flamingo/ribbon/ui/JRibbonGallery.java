/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.ribbon.ui;

import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.util.*;

import javax.swing.*;

import org.jvnet.flamingo.common.*;

/**
 * In-ribbon gallery.
 * 
 * @author Kirill Grouchnikov
 */
public class JRibbonGallery extends JComponent {
	/**
	 * The buttons of <code>this</code> gallery.
	 */
	protected List<JCommandToggleButton> buttons;

	/**
	 * Button group for ensuring that only one button is selected.
	 */
	protected ButtonGroup buttonGroup;

	/**
	 * The current display state of <code>this</code> in-ribbon gallery.
	 */
	protected ElementState state;

	/**
	 * Preferred widths for each possible display state (set in the user code
	 * according to design preferences).
	 */
	protected Map<ElementState, Integer> preferredVisibleIconCount;

	protected List<StringValuePair<List<JCommandToggleButton>>> buttonGroups;

	/**
	 * Currently selected button.
	 */
	protected JCommandToggleButton selectedButton;

	/**
	 * The associated icon popup gallery.
	 */
	protected JIconPopupPanel popupGallery;

	/**
	 * Dummy button to turn the visible selection - see Javadocs for the
	 * {@link ButtonGroup} on why this is needed when the parameter to
	 * {@link #setSelectedButton(JRibbonButton)} is <code>null</code>.
	 */
	protected JToggleButton invisible;

	protected int preferredPopupMaxButtonColumns;

	protected int preferredPopupMaxVisibleButtonRows;

	protected boolean isShowingPopupGallery;

	/**
	 * The UI class ID string.
	 */
	public static final String uiClassID = "RibbonGalleryUI";

	/**
	 * Action listener wired to all the buttons in this gallery. If
	 * {@link #toDismissOnButtonClick} is <code>true</code>, the listener
	 * dismissed this gallery.
	 */
	protected ActionListener dismissActionListener;

	/**
	 * Creates new in-ribbon gallery.
	 */
	public JRibbonGallery() {
		this.buttons = new ArrayList<JCommandToggleButton>();
		this.buttonGroup = new ButtonGroup();

		this.preferredVisibleIconCount = new HashMap<ElementState, Integer>();
		// Initialize with some values. Application should provide real
		// widths using setPreferredWidth.
		for (ElementState state : ElementState.values())
			this.preferredVisibleIconCount.put(state, 100);

		this.invisible = new JToggleButton();
		this.invisible.setVisible(false);
		this.buttonGroup.add(this.invisible);

		this.isShowingPopupGallery = false;

		this.updateUI();
	}

	// public JRibbonGallery(JCommandButtonPanel buttonPanel) {
	// this.buttons = new ArrayList<JCommandToggleButton>();
	// this.buttonGroup = new ButtonGroup();
	//
	// int groupCount = buttonPanel.getGroupCount();
	// for (int i = 0; i < groupCount; i++) {
	// List<AbstractCommandButton> buttons = buttonPanel
	// .getGroupButtons(i);
	// for (AbstractCommandButton button : buttons) {
	// if (!(button instanceof JCommandToggleButton)) {
	// throw new IllegalArgumentException(
	// "Button panel should contain only JCommandToggleButtons");
	// }
	// }
	// }
	//
	// this.preferredWidths = new HashMap<ElementState, Integer>();
	// // Initialize with some values. Application should provide real
	// // widths using setPreferredWidth.
	// for (ElementState state : ElementState.values())
	// this.preferredWidths.put(state, 100);
	//
	// this.invisible = new JToggleButton();
	// this.invisible.setVisible(false);
	// this.buttonGroup.add(this.invisible);
	//
	// this.updateUI();
	//
	// }

	/**
	 * Sets the new UI delegate.
	 * 
	 * @param ui
	 *            New UI delegate.
	 */
	public void setUI(RibbonGalleryUI ui) {
		super.setUI(ui);
	}

	/**
	 * Resets the UI property to a value from the current look and feel.
	 * 
	 * @see JComponent#updateUI
	 */
	@Override
	public void updateUI() {
		if (UIManager.get(getUIClassID()) != null) {
			setUI((RibbonGalleryUI) UIManager.getUI(this));
		} else {
			setUI(new BasicRibbonGalleryUI());
		}

		if (this.popupGallery != null)
			SwingUtilities.updateComponentTreeUI(this.popupGallery);
	}

	/**
	 * Returns the UI object which implements the L&F for this component.
	 * 
	 * @return a <code>RibbonGalleryUI</code> object
	 * @see #setUI
	 */
	public RibbonGalleryUI getUI() {
		return (RibbonGalleryUI) ui;
	}

	/**
	 * Returns the name of the UI class that implements the L&F for this
	 * component.
	 * 
	 * @return the string "RibbonGalleryUI"
	 * @see JComponent#getUIClassID
	 * @see UIDefaults#getUI
	 */
	@Override
	public String getUIClassID() {
		return uiClassID;
	}

	/**
	 * Adds new gallery button to <code>this</code> in-ribbon gallery.
	 * 
	 * @param button
	 *            Gallery button to add.
	 */
	public void addGalleryButton(JCommandToggleButton button) {
		this.buttons.add(button);
		this.buttonGroup.add(button);
		button.setState(ElementState.BIG_FIXED_LANDSCAPE, true);

		button.addActionListener(this.dismissActionListener);

		super.add(button);
	}

	/**
	 * Set preferred width of <code>this</code> in-ribbon gallery for the
	 * specified display state.
	 * 
	 * @param state
	 *            Display state.
	 * @param visibleButtonCount
	 *            Preferred width for the specified state.
	 */
	public void setPreferredVisibleButtonCount(ElementState state,
			int visibleButtonCount) {
		this.preferredVisibleIconCount.put(state, visibleButtonCount);
	}

	/**
	 * Returns the preferred width of <code>this</code> in-ribbon gallery for
	 * the specified display state.
	 * 
	 * @param state
	 *            Display state.
	 * @return The preferred width of <code>this</code> in-ribbon gallery for
	 *         the specified display state.
	 */
	public int getPreferredWidth(ElementState state, int availableHeight) {
		int preferredVisibleButtonCount = this.preferredVisibleIconCount
				.get(state);

		BasicRibbonGalleryUI ui = (BasicRibbonGalleryUI) this.getUI();
		return ui.getPreferredWidth(preferredVisibleButtonCount,
				availableHeight);
	}

	/**
	 * Sets new display state for <code>this</code> in-ribbon gallery.
	 * 
	 * @param state
	 *            New display state for <code>this</code> in-ribbon gallery.
	 */
	public void setState(ElementState state) {
		this.state = state;
	}

	/**
	 * Returns the current display state for <code>this</code> in-ribbon
	 * gallery.
	 * 
	 * @return The current display state for <code>this</code> in-ribbon
	 *         gallery.
	 */
	public ElementState getState() {
		return state;
	}

	/**
	 * Returns the number of gallery buttons in <code>this</code> in-ribbon
	 * gallery.
	 * 
	 * @return The number of gallery buttons in <code>this</code> in-ribbon
	 *         gallery.
	 */
	public int getButtonCount() {
		return this.buttons.size();
	}

	/**
	 * Returns the gallery button at specified index.
	 * 
	 * @param index
	 *            Gallery button index.
	 * @return Gallery button at specified index.
	 */
	public JCommandToggleButton getButtonAt(int index) {
		return this.buttons.get(index);
	}

	/**
	 * Returns the currently selected gallery button.
	 * 
	 * @return The currently selected gallery button.
	 */
	public JCommandToggleButton getSelectedButton() {
		return selectedButton;
	}

	/**
	 * Sets new value for the currently selected gallery button.
	 * 
	 * @param selectedButton
	 *            New value for the currently selected gallery button.
	 */
	public void setSelectedButton(JCommandToggleButton selectedButton) {
		if (selectedButton != null) {
			selectedButton.setSelected(true);
		} else {
			this.invisible.setSelected(true);
		}
		this.selectedButton = selectedButton;
		this.repaint();
	}

	/**
	 * Returns the associated popup gallery.
	 * 
	 * @return The associated popup gallery.
	 */
	public JIconPopupPanel getPopupGallery() {
		// return popupGallery;

		JCommandButtonPanel buttonPanel = new JCommandButtonPanel(
				ElementState.BIG);
		buttonPanel.setMaxButtonColumns(this.preferredPopupMaxButtonColumns);
		buttonPanel.setToShowGroupLabels(true);
		int groupIndex = 0;
		for (StringValuePair<List<JCommandToggleButton>> buttonGroupEntry : this.buttonGroups) {
			String groupName = buttonGroupEntry.getKey();
			buttonPanel.addButtonGroup(groupName, groupIndex++);
			for (JCommandToggleButton button : buttonGroupEntry.getValue()) {
				// set the button to visible (the gallery hides the buttons
				// that don't fit the front row).
				button.setVisible(true);
				buttonPanel.addButtonToGroup(groupName, button);
			}
		}
		// just to make sure that the button panel will not try to add
		// the buttons to its own button group
		buttonPanel.setSingleSelectionMode(false);

		JIconPopupPanel result = new JIconPopupPanel(buttonPanel,
				this.preferredPopupMaxButtonColumns,
				this.preferredPopupMaxVisibleButtonRows);
		Dimension maxDim = result.getMaximumSize();
		if (maxDim.getWidth() < this.getWidth()) {
			result
					.setMaximumSize(new Dimension(this.getWidth(),
							maxDim.height));
			result.setPreferredSize(result.getMaximumSize());
		}
		// result.invalidate();
		// result.validate();
		// result.doLayout();
		return result;
	}

	public void setShowingPopupGallery(boolean isShowingPopupGallery) {
		this.isShowingPopupGallery = isShowingPopupGallery;

		if (!isShowingPopupGallery) {
			// populate the popup gallery back
			for (StringValuePair<List<JCommandToggleButton>> buttonGroupEntry : this.buttonGroups) {
				for (JCommandToggleButton button : buttonGroupEntry.getValue()) {
					button.setState(ElementState.BIG_FIXED_LANDSCAPE, false);
					this.add(button);
				}
			}
			// and layout
			this.doLayout();
		}
	}

	public boolean isShowingPopupGallery() {
		return isShowingPopupGallery;
	}

	public void setGroupMapping(
			List<StringValuePair<List<JCommandToggleButton>>> buttons) {
		this.buttonGroups = buttons;
		for (StringValuePair<List<JCommandToggleButton>> buttonGroupEntry : this.buttonGroups) {
			for (JCommandToggleButton button : buttonGroupEntry.getValue()) {
				this.addGalleryButton(button);
			}
		}
	}

	public void setPreferredPopupPanelDimension(
			int preferredPopupMaxButtonColumns,
			int preferredPopupMaxVisibleButtonRows) {
		this.preferredPopupMaxButtonColumns = preferredPopupMaxButtonColumns;
		this.preferredPopupMaxVisibleButtonRows = preferredPopupMaxVisibleButtonRows;
	}

}
