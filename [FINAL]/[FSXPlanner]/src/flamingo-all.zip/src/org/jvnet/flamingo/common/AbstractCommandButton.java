/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common;

import javax.swing.AbstractButton;
import javax.swing.Icon;

import org.jvnet.flamingo.common.icon.ResizableIcon;
import org.jvnet.flamingo.common.ui.CommandButtonUI;

/**
 * Abstract command button
 * 
 * @author Kirill Grouchnikov
 */
public abstract class AbstractCommandButton extends AbstractButton {
	/**
	 * Associated icon.
	 */
	protected ResizableIcon icon;

	/**
	 * Associated disabled icon.
	 */
	protected ResizableIcon disabledIcon;

	/**
	 * Associated title.
	 */
	protected String title;

	protected String extraText;

	/**
	 * Current display state of <code>this</code> button.
	 */
	protected ElementState state;

	protected int customDimension;

	protected boolean isFlat;

	/**
	 * Creates a new command button.
	 * 
	 * @param title
	 *            Button title. May contain any number of words.
	 * @param icon
	 *            Button icon.
	 */
	public AbstractCommandButton(String title, ResizableIcon icon) {
		this.title = title;
		this.icon = icon;

		this.customDimension = -1;
		this.state = ElementState.CUSTOM;
		this.setText(title);
		this.isFlat = true;
	}

	/**
	 * Sets the new UI delegate.
	 * 
	 * @param ui
	 *            New UI delegate.
	 */
	public void setUI(CommandButtonUI ui) {
		super.setUI(ui);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.AbstractButton#getUI()
	 */
	@Override
	public CommandButtonUI getUI() {
		return (CommandButtonUI) ui;
	}

	/**
	 * Sets new display state for <code>this</code> button.
	 * 
	 * @param state
	 *            New display state.
	 * @param toUpdateIcon
	 *            If <code>true</code>, the icon must be updated as well.
	 */
	public void setState(ElementState state, boolean toUpdateIcon) {
		this.state = state;

		this.getUI().updateState(state, toUpdateIcon);
	}

	/**
	 * Returns the associated icon.
	 * 
	 * @return The associated icon.
	 */
	@Override
	public ResizableIcon getIcon() {
		return icon;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.AbstractButton#setIcon(javax.swing.Icon)
	 */
	@Override
	public void setIcon(Icon defaultIcon) {
		if (defaultIcon instanceof ResizableIcon)
			this.icon = (ResizableIcon) defaultIcon;
		super.setIcon(defaultIcon);
	}

	public void setDisabledIcon(ResizableIcon disabledIcon) {
		this.disabledIcon = disabledIcon;
	}

	/**
	 * Returns the associated disabled icon.
	 * 
	 * @return The associated disabled icon.
	 */
	@Override
	public ResizableIcon getDisabledIcon() {
		return disabledIcon;
	}

	/**
	 * Return the current display state of <code>this</code> button.
	 * 
	 * @return The current display state of <code>this</code> button.
	 */
	public ElementState getState() {
		return state;
	}

	/**
	 * Returns the associated title.
	 * 
	 * @return The associated title.
	 */
	public String getTitle() {
		return title;
	}

	public String getExtraText() {
		return this.extraText;
	}

	public void setExtraText(String extraText) {
		this.extraText = extraText;
	}

	/**
	 * Updates the dimension of the icon of the associated command button in the
	 * {@link ElementState#CUSTOM} state.
	 * 
	 * @param dimension
	 *            New dimension of the icon of the associated command button in
	 *            the {@link ElementState#CUSTOM} state.
	 */
	public void updateCustomDimension(int dimension) {
		if (this.customDimension != dimension) {
			int old = this.customDimension;
			this.customDimension = dimension;
			this.firePropertyChange("customDimension", old,
					this.customDimension);
		}
	}

	public int getCustomDimension() {
		return this.customDimension;
	}

	public boolean isFlat() {
		return isFlat;
	}

	public void setFlat(boolean isFlat) {
		boolean old = this.isFlat;
		this.isFlat = isFlat;
		if (old != this.isFlat) {
			this.firePropertyChange("flat", old, this.isFlat);
		}
	}
}
