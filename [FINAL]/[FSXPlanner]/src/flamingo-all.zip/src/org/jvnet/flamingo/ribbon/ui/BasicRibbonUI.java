/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.ribbon.ui;

import java.awt.*;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.*;

import org.jvnet.flamingo.ribbon.*;
import org.jvnet.flamingo.utils.FlamingoUtilities;
import org.jvnet.flamingo.utils.RenderingUtils;

/**
 * Basic UI for ribbon {@link JRibbon}.
 * 
 * @author Kirill Grouchnikov
 */
public class BasicRibbonUI extends RibbonUI {
	/**
	 * Minimum width of a single ribbon band.
	 */
	public static final int BAND_MIN_WIDTH = 30;

	/**
	 * The associated ribbon.
	 */
	protected JRibbon ribbon;

	/**
	 * Mouse wheel listener to switch between ribbon tasks.
	 */
	protected MouseWheelListener mouseWheelListener;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicRibbonUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#installUI(javax.swing.JComponent)
	 */
	@Override
	public void installUI(JComponent c) {
		this.ribbon = (JRibbon) c;
		installDefaults();
		installComponents();
		installListeners();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		uninstallListeners();
		uninstallComponents();
		uninstallDefaults();

		this.ribbon = null;
	}

	/**
	 * Installs listeners on the associated ribbon.
	 */
	protected void installListeners() {

		this.mouseWheelListener = new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
				int delta = e.getWheelRotation();
				if (delta == 0)
					return;

				int currSelectedTaskIndex = ribbon.getSelectedTaskIndex();
				int taskCount = ribbon.getTaskCount();

				int newSelectedTaskIndex = currSelectedTaskIndex
						+ ((delta > 0) ? 1 : -1);
				if (newSelectedTaskIndex < 0)
					return;
				if (newSelectedTaskIndex >= taskCount)
					return;

				final int indexToSet = newSelectedTaskIndex;
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						ribbon.setCursor(Cursor
								.getPredefinedCursor(Cursor.WAIT_CURSOR));
						ribbon.setSelectedTask(indexToSet);
						ribbon.setCursor(Cursor
								.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
					}
				});
			}
		};
		this.ribbon.addMouseWheelListener(this.mouseWheelListener);
	}

	/**
	 * Uninstalls listeners from the associated ribbon.
	 */
	protected void uninstallListeners() {
		this.ribbon.removeMouseWheelListener(this.mouseWheelListener);
		this.mouseWheelListener = null;
	}

	/**
	 * Installs defaults on the associated ribbon.
	 */
	protected void installDefaults() {
		Border b = this.ribbon.getBorder();
		if (b == null || b instanceof UIResource) {
			Border toSet = UIManager.getBorder("Ribbon.border");
			if (toSet == null)
				toSet = new BorderUIResource.EmptyBorderUIResource(1, 2, 1, 2);
			this.ribbon.setBorder(toSet);
		}
	}

	/**
	 * Uninstalls defaults from the associated ribbon.
	 */
	protected void uninstallDefaults() {
	}

	/**
	 * Installs subcomponents on the associated ribbon.
	 */
	protected void installComponents() {
		this.ribbon.setLayout(createLayoutManager());
	}

	/**
	 * Uninstalls subcomponents from the associated ribbon.
	 */
	protected void uninstallComponents() {
		this.ribbon.setLayout(null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		Graphics2D g2d = (Graphics2D) g.create();
		RenderingUtils.installDesktopHints(g2d);
		super.update(g2d, c);
		g2d.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void paint(Graphics g, JComponent c) {
		super.paint(g, c);

		Insets ins = c.getInsets();
		this.paintTaskBorder(g, 0, ins.top + getTaskbarHeight(), c.getWidth(),
				c.getHeight() - getTaskbarHeight() - ins.top);
	}

	/**
	 * Paints the task border.
	 * 
	 * @param g
	 *            Graphics context.
	 * @param x
	 *            Left X of the tasks band bounds.
	 * @param y
	 *            Top Y of the tasks band bounds.
	 * @param width
	 *            Width of the tasks band bounds.
	 * @param height
	 *            Height of the tasks band bounds.
	 */
	protected void paintTaskBorder(Graphics g, int x, int y, int width,
			int height) {

		int selectedTaskIndex = this.ribbon.getSelectedTaskIndex();
		JToggleTabButton selectedTaskButton = this.ribbon
				.getTaskToggleButtons().get(selectedTaskIndex);
		Rectangle selectedTaskButtonBounds = selectedTaskButton.getBounds();
		Shape outerContour = FlamingoUtilities
				.getRibbonBorderOutline(x + 1, x + width - 3,
						selectedTaskButtonBounds.x + 1,
						selectedTaskButtonBounds.x
								+ selectedTaskButtonBounds.width - 1,
						selectedTaskButtonBounds.y, y, y + height - 1, 2);

		Graphics2D g2d = (Graphics2D) g.create();
		g2d.setColor(FlamingoUtilities.getColor(Color.gray,
				"TextField.inactiveForeground", "Button.disabledText",
				"ComboBox.disabledForeground"));
		g2d.draw(outerContour);
		g2d.dispose();
	}

	protected int getLayoutGap() {
		return 2;
	}

	/**
	 * Invoked by <code>installUI</code> to create a layout manager object to
	 * manage the {@link JRibbon}.
	 * 
	 * @return a layout manager object
	 */
	protected LayoutManager createLayoutManager() {
		return new RibbonLayout();
	}

	protected int getTaskbarHeight() {
		return 22;
	}

	/**
	 * Layout for the ribbon.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class RibbonLayout implements LayoutManager {
		/**
		 * Total ribbon height.
		 */
		// public static final int TOTAL_HEIGHT = TASKBAR_HEIGHT
		// + BasicRibbonBandUI.BAND_HEADER_HEIGHT
		// + BasicRibbonBandUI.BAND_CONTROL_PANEL_HEIGHT;
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container c) {
			Insets ins = c.getInsets();
			int maxPrefBandHeight = 0;
			for (JRibbonBand ribbonBand : ribbon.getBands()) {
				int bandPrefHeight = ribbonBand.getPreferredSize().height;
				Insets bandInsets = ribbonBand.getInsets();
				maxPrefBandHeight = Math.max(maxPrefBandHeight, bandPrefHeight
						+ bandInsets.top + bandInsets.bottom);
			}

			return new Dimension(c.getWidth(), maxPrefBandHeight
					+ getTaskbarHeight() + ins.top + ins.bottom);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container c) {
			// go over all ribbon bands and sum the width
			// of ribbon buttons (of collapsed state)
			Insets ins = c.getInsets();
			int width = 0;
			int maxMinBandHeight = 0;
			int gap = getLayoutGap();

			for (JRibbonBand ribbonBand : ribbon.getBands()) {
				int bandPrefHeight = ribbonBand.getMinimumSize().height;
				Insets bandInsets = ribbonBand.getInsets();
				int availableBandHeight = c.getHeight() - ins.top
						- getTaskbarHeight() 
						//- bandInsets.top
						//- bandInsets.bottom 
						- ins.bottom;
				BasicRibbonBandUI bandUI = (BasicRibbonBandUI) ribbonBand
						.getUI();
				width += bandUI.getPreferredWidth(RibbonBandCollapseKind.ICON,
						availableBandHeight);
				maxMinBandHeight = Math.max(maxMinBandHeight, bandPrefHeight
						+ bandInsets.top + bandInsets.bottom);
			}
			// add inter-band gaps
			width += gap * (ribbon.getBands().size() - 1);
			return new Dimension(width, maxMinBandHeight + getTaskbarHeight()
					+ ins.top + ins.bottom);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container c) {
			Insets ins = c.getInsets();
			int gap = getLayoutGap();

			// the top row - regular components and task buttons
			int x = ins.left;
			int taskbarHeight = getTaskbarHeight();
			for (Component regComp : ribbon.getRegularComponents()) {
				int pw = regComp.getPreferredSize().width;
				regComp.setBounds(x, ins.top, pw, taskbarHeight);
				x += (pw + gap);
			}
			// task buttons
			int totalTaskButtonsWidth = 0;
			for (JToggleTabButton taskToggleButton : ribbon
					.getTaskToggleButtons()) {
				int pw = taskToggleButton.getPreferredSize().width;
				totalTaskButtonsWidth += (pw + 10);
			}

			int helpTaskButtonWidth = 0;
			JToggleTabButton helpTaskButton = ribbon.getHelpTaskButton();
			if (helpTaskButton != null)
				helpTaskButtonWidth = helpTaskButton.getPreferredSize().width;
			totalTaskButtonsWidth -= helpTaskButtonWidth;

			switch (ribbon.getAlignment()) {
			case SwingConstants.LEFT:
				break;
			case SwingConstants.RIGHT:
				x = Math.max(x, c.getWidth() - totalTaskButtonsWidth
						- helpTaskButtonWidth);
				break;
			case SwingConstants.CENTER:
				x += Math.max(x, (c.getWidth() - totalTaskButtonsWidth) / 2
						- helpTaskButtonWidth);
			}
			for (JToggleButton taskToggleButton : ribbon.getTaskToggleButtons()) {
				int pw = taskToggleButton.getPreferredSize().width;
				if (taskToggleButton != helpTaskButton) {
					taskToggleButton.setBounds(x, ins.top, pw, taskbarHeight);
					x += (pw + 10);
				} else {
					taskToggleButton.setBounds(c.getWidth()
							- helpTaskButtonWidth - 10, ins.top, pw,
							taskbarHeight);
				}
			}

			// Ask each band how much horizontal space it needs
			// under various constraints. After that, go over total
			// width under each constraint and find the optimal
			// allocation of space.
			Map<RibbonBandCollapseKind, Integer> widths = new HashMap<RibbonBandCollapseKind, Integer>();
			for (RibbonBandCollapseKind collapseKind : RibbonBandCollapseKind
					.values()) {
				int totalWidth = 0;
				for (JRibbonBand band : ribbon.getBands()) {
					//Insets bandInsets = band.getInsets();
					int availableBandHeight = c.getHeight() - ins.top
							- getTaskbarHeight() -
							//bandInsets.top
							//- bandInsets.bottom -
							ins.bottom;
					BasicRibbonBandUI ui = (BasicRibbonBandUI) band.getUI();
					totalWidth += ui.getPreferredWidth(collapseKind,
							availableBandHeight);
				}
				totalWidth += gap * (ribbon.getBands().size() - 1);
				widths.put(collapseKind, totalWidth);
			}

			RibbonBandCollapseKind bestFitCollapse = RibbonBandCollapseKind
					.getSortedKinds().getLast();
			int availableWidth = c.getWidth() - ins.left - ins.right;
			for (RibbonBandCollapseKind collapseKind : RibbonBandCollapseKind
					.getSortedKinds()) {
				if (widths.get(collapseKind) < availableWidth) {
					bestFitCollapse = collapseKind;
					break;
				}
			}
			// System.out.println(bestFitCollapse + " is best");
			int bestFitWidth = widths.get(bestFitCollapse);
			// double coef = (double) (availableWidth) / bestFitWidth;
			// System.out.println("available : " + c.getWidth());
			// maximum 20% more than preferred width
			// if (coef >= 1.2)
			// coef = 1.2;

			// compute how many pixels we can distribute between the bands
			int widthToDistribute = availableWidth - bestFitWidth;

			x = 1 + ins.left;
			for (JRibbonBand band : ribbon.getBands()) {
				BasicRibbonBandUI ui = (BasicRibbonBandUI) band.getUI();

				//Insets bandInsets = band.getInsets();
				int availableBandHeight = c.getHeight() - ins.top
						- getTaskbarHeight() //- bandInsets.top
						//- bandInsets.bottom 
						- ins.bottom;

				int pw = Math.max(BAND_MIN_WIDTH, ui.getPreferredWidth(
						bestFitCollapse, availableBandHeight));

				// try allocating the available pixels to the current band and
				// see if the collapse kind for this specific band will change.
				int availableForBand = pw + widthToDistribute;
				RibbonBandCollapseKind bestFitForBand = RibbonBandCollapseKind
						.getSortedKinds().getLast();
				for (RibbonBandCollapseKind collapseKind : RibbonBandCollapseKind
						.getSortedKinds()) {
					if (ui.getPreferredWidth(collapseKind, availableBandHeight) <= availableForBand) {
						bestFitForBand = collapseKind;
						break;
					}
				}

				// now that the collapse kind of the band is computed according
				// to the actual available width, compute the preferred band
				// width under that collapse kind
				int fw = ui.getPreferredWidth(bestFitForBand,
						availableBandHeight);

				// and update the available width accordingly.
				widthToDistribute -= (fw - pw);

				Insets bandInsets = band.getInsets();
				band.setBounds(x, ins.top + taskbarHeight + bandInsets.top, fw,
						c.getHeight() - ins.top - taskbarHeight
								- bandInsets.top - bandInsets.bottom
								- ins.bottom);
				band.doLayout();

				RibbonBandCollapseKind actualCollapseKind = ui
						.getCurrentFitCollapse();
				if (actualCollapseKind != bestFitForBand) {
					throw new IllegalStateException("Available width of '"
							+ band.getTitle()
							+ "' under "
							+ bestFitForBand.name()
							+ " was reported to be "
							+ fw
							+ ", but the actual collapse kind is "
							+ actualCollapseKind
							+ " with width "
							+ ui.getPreferredWidth(actualCollapseKind,
									availableBandHeight));
				}

				x += (fw + gap);
			}
		}
	}
}
