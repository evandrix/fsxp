package org.jvnet.flamingo.common;

import java.awt.*;

import javax.swing.border.Border;

public class RoundBorder implements Border {
	protected Color color;

	protected Insets insets;

	public RoundBorder(Color color, Insets insets) {
		this.color = color;
		this.insets = insets;
	}

	@Override
	public Insets getBorderInsets(Component c) {
		return this.insets;
	}

	@Override
	public boolean isBorderOpaque() {
		return false;
	}

	@Override
	public void paintBorder(Component c, Graphics g, int x, int y, int width,
			int height) {
		Graphics2D g2d = (Graphics2D) g.create();
		g2d.setColor(this.color);
		g2d.drawRoundRect(x, y, width - 1, height - 1, 3, 3);
		g2d.dispose();
	}

}
