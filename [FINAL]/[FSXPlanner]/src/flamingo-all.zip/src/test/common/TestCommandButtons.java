/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package test.common;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

import javax.swing.*;
import javax.swing.UIManager.LookAndFeelInfo;

import org.jvnet.flamingo.common.*;
import org.jvnet.flamingo.common.icon.DecoratedResizableIcon;
import org.jvnet.flamingo.common.icon.ResizableIcon;
import org.jvnet.flamingo.svg.SvgBatikResizableIcon;

import test.ribbon.BasicCheckRibbon;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;

public class TestCommandButtons extends JFrame {
	protected static class QuickStylesPanel extends JCommandButtonPanel {
		public QuickStylesPanel() {
			super(32);

			for (int groupIndex = 0; groupIndex < 4; groupIndex++) {
				String iconGroupName = "Styles " + groupIndex;
				this.addButtonGroup(iconGroupName, groupIndex);
				for (int i = 0; i < 15; i++) {
					final int index = i;
					ResizableIcon fontIcon = SvgBatikResizableIcon
							.getSvgIcon(
									BasicCheckRibbon.class
											.getClassLoader()
											.getResource(
													"test/svg/font-x-generic.svg"),
									new Dimension(32, 32));
					ResizableIcon finalIcon = new DecoratedResizableIcon(
							fontIcon,
							new DecoratedResizableIcon.IconDecorator() {
								@Override
								public void paintIconDecoration(Component c,
										Graphics g, int x, int y, int width,
										int height) {
									Graphics2D g2d = (Graphics2D) g.create();
									g2d.setColor(Color.black);
									String str = "" + index;
									FontMetrics fm = g2d.getFontMetrics();
									int len = (int) fm
											.getStringBounds(str, g2d)
											.getWidth();
									g2d.drawString("" + index, x + 2, y
											+ height - 2);
								}
							});
					JCommandToggleButton jrb = new JCommandToggleButton(null,
							finalIcon);
					jrb.setName("Group " + groupIndex + ", index " + i);
					jrb.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							System.out.println("Invoked action on " + index);
						}
					});
					this.addButtonToGroup(iconGroupName, jrb);
				}
			}
			this.setSingleSelectionMode(true);
		}
	}

	private class SamplePopupActionListener implements PopupMenuListener {
		@Override
		public void menuAboutToShow(JPopupMenu popupMenu) {
			popupMenu.add(new JMenuItem("Test menu item 1"));
			popupMenu.add(new JMenuItem("Test menu item 2"));
			popupMenu.addSeparator();
			popupMenu.add(new JMenuItem("Test menu item 3"));
			popupMenu.add(new JMenuItem("Test menu item 4"));
			popupMenu.add(new JMenuItem("Test menu item 5"));
		}
	}

	public TestCommandButtons() {
		super("Command button test");
		this.setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB));

		this.setLayout(new BorderLayout());

		FormLayout lm = new FormLayout("right:pref, 10dlu, center:pref, 4dlu,"
				+ "center:pref, 4dlu, center:pref, " + "4dlu, center:pref", "");
		lm.setColumnGroups(new int[][] { { 3, 5, 7, 9 } });
		DefaultFormBuilder builder = new DefaultFormBuilder(lm);
		builder.setDefaultDialogBorder();

		builder.append("");
		builder.append("Action only");
		builder.append("Action (main) + popup");
		builder.append("Action + popup (main)");
		builder.append("Popup only");

		addButtons(builder, ElementState.BIG);
		addButtons(builder, ElementState.TILE);
		addButtons(builder, ElementState.MEDIUM);
		addButtons(builder, ElementState.SMALL);

		this.add(builder.getPanel(), BorderLayout.CENTER);

		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		this.configureControlPanel(controlPanel);

		this.add(controlPanel, BorderLayout.SOUTH);
	}

	private void addButtons(DefaultFormBuilder builder, ElementState state) {
		builder.append(state.name() + " state");

		JCommandButton mainButton = new JCommandButton("Paste",
				SvgBatikResizableIcon.getSvgIcon(TestCommandButtons.class
						.getClassLoader()
						.getResource("test/svg/edit-paste.svg"), new Dimension(
						32, 32)));
		mainButton.setMnemonic('P');
		mainButton.setExtraText("Extra for paste");
		mainButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Main paste");
			}
		});
		mainButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.ACTION_ONLY);
		mainButton.setState(state, true);
		mainButton.setFlat(false);
		builder.append(mainButton);

		JCommandButton cutButton = new JCommandButton("Cut",
				SvgBatikResizableIcon.getSvgIcon(TestCommandButtons.class
						.getClassLoader().getResource("test/svg/edit-cut.svg"),
						new Dimension(32, 32)));
		cutButton.setExtraText("Extra for cut");
		cutButton.addPopupActionListener(new SamplePopupActionListener());
		cutButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_ACTION);
		cutButton.setState(state, true);
		cutButton.setFlat(false);
		cutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Cut");
			}
		});
		builder.append(cutButton);

		JCommandButton copyButton = new JCommandButton("Copy",
				SvgBatikResizableIcon.getSvgIcon(
						TestCommandButtons.class.getClassLoader().getResource(
								"test/svg/edit-copy.svg"),
						new Dimension(32, 32)));
		copyButton.setExtraText("Extra for copy");
		copyButton.addPopupActionListener(new SamplePopupActionListener());
		copyButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_POPUP);
		copyButton.setState(state, true);
		copyButton.setFlat(false);
		copyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Copy");
			}
		});
		builder.append(copyButton);

		JCommandButton popupButton = new JCommandButton("Gallery popup",
				SvgBatikResizableIcon.getSvgIcon(TestCommandButtons.class
						.getClassLoader()
						.getResource("test/svg/edit-paste.svg"), new Dimension(
						32, 32)));
		popupButton.setExtraText("Extra for popup");
		popupButton.setPopupPanel(new JIconPopupPanel(new QuickStylesPanel(),
				5, 3));
		popupButton
				.setCommandButtonKind(JCommandButton.CommandButtonKind.POPUP_ONLY);
		popupButton.setState(state, true);
		popupButton.setFlat(false);
		popupButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Paste");
			}
		});
		builder.append(popupButton);
	}

	protected void configureControlPanel(JPanel controlPanel) {
		LookAndFeelInfo[] lafs = UIManager.getInstalledLookAndFeels();
		final JComboBox jcb = new JComboBox(lafs);
		jcb.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						JFrame frame = TestCommandButtons.this;
						boolean wasDecoratedByOS = !frame.isUndecorated();
						try {
							LookAndFeelInfo selected = (LookAndFeelInfo) jcb
									.getSelectedItem();
							UIManager.setLookAndFeel(selected.getClassName());
							SwingUtilities.updateComponentTreeUI(frame);
						} catch (Exception exc) {
						}
						boolean canBeDecoratedByLAF = UIManager
								.getLookAndFeel()
								.getSupportsWindowDecorations();
						if (canBeDecoratedByLAF == wasDecoratedByOS) {
							boolean wasVisible = frame.isVisible();

							frame.setVisible(false);
							frame.dispose();
							if (!canBeDecoratedByLAF) {
								// see the java docs under the method
								// JFrame.setDefaultLookAndFeelDecorated(boolean
								// value) for description of these 2 lines:
								frame.setUndecorated(false);
								frame.getRootPane().setWindowDecorationStyle(
										JRootPane.NONE);

							} else {
								frame.setUndecorated(true);
								frame.getRootPane().setWindowDecorationStyle(
										JRootPane.FRAME);
							}
							frame.setVisible(wasVisible);
							wasDecoratedByOS = !frame.isUndecorated();
						}
					}
				});
			}
		});
		jcb.setRenderer(new DefaultListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList list,
					Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				return super.getListCellRendererComponent(list,
						((LookAndFeelInfo) value).getName(), index, isSelected,
						cellHasFocus);
			}
		});
		controlPanel.add(jcb);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				TestCommandButtons frame = new TestCommandButtons();
				frame.setSize(800, 400);
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
	}
}
