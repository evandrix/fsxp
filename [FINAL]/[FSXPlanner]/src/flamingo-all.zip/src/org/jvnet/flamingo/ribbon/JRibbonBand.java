/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.ribbon;

import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

import javax.swing.*;

import org.jvnet.flamingo.common.*;
import org.jvnet.flamingo.common.icon.ResizableIcon;
import org.jvnet.flamingo.ribbon.ui.*;

/**
 * Ribbon band component. Is part of a logical {@link RibbonTask}.
 * 
 * @author Kirill Grouchnikov
 */
public class JRibbonBand extends JComponent {
	/**
	 * Band title.
	 */
	private String title;

	/**
	 * Optional <code>expand</code> action listener. If present, the title
	 * pane shows button with plus sign. The action listener on the button will
	 * be <code>this</code> listener.
	 */
	private ActionListener expandActionListener;

	/**
	 * Band control panel. Can be not-visible when only a collapse ribbon button
	 * can fit the available width.
	 */
	private JBandControlPanel controlPanel;

	/**
	 * The UI class ID string.
	 */
	public static final String uiClassID = "RibbonBandUI";

	/**
	 * Icon for the collapsed state.
	 */
	private ResizableIcon icon;

	/**
	 * Simple constructor.
	 * 
	 * @param title
	 *            Band title.
	 * @param icon
	 *            Associated icon (for collapsed state).
	 */
	public JRibbonBand(String title, ResizableIcon icon) {
		this(title, icon, null);
	}

	/**
	 * Simple constructor.
	 * 
	 * @param title
	 *            Band title.
	 * @param icon
	 *            Associated icon (for collapsed state).
	 * @param expandActionListener
	 *            Expand action listener (can be <code>null</code>).
	 */
	public JRibbonBand(String title, ResizableIcon icon,
			ActionListener expandActionListener) {
		super();
		this.title = title;
		this.icon = icon;
		this.expandActionListener = expandActionListener;

		this.controlPanel = new JBandControlPanel(this);
		this.add(this.controlPanel);

		updateUI();
	}

	/**
	 * Returns the title of <code>this</code> band.
	 * 
	 * @return Title of <code>this</code> band.
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets new title for <code>this</code> band.
	 * 
	 * @param title
	 *            New title for <code>this</code> band.
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Returns the associated icon (for collapsed state).
	 * 
	 * @return The associated icon (for collapsed state).
	 */
	public ResizableIcon getIcon() {
		return icon;
	}

	/**
	 * Sets the new UI delegate.
	 * 
	 * @param ui
	 *            New UI delegate.
	 */
	public void setUI(RibbonBandUI ui) {
		super.setUI(ui);
	}

	/**
	 * Resets the UI property to a value from the current look and feel.
	 * 
	 * @see JComponent#updateUI
	 */
	@Override
	public void updateUI() {
		if (UIManager.get(getUIClassID()) != null) {
			setUI((RibbonBandUI) UIManager.getUI(this));
		} else {
			setUI(new BasicRibbonBandUI());
		}
	}

	/**
	 * Returns the UI object which implements the L&F for this component.
	 * 
	 * @return a <code>RibbonBandUI</code> object
	 * @see #setUI
	 */
	public RibbonBandUI getUI() {
		return (RibbonBandUI) ui;
	}

	/**
	 * Returns the name of the UI class that implements the L&F for this
	 * component.
	 * 
	 * @return the string "RibbonBandUI"
	 * @see JComponent#getUIClassID
	 * @see UIDefaults#getUI
	 */
	@Override
	public String getUIClassID() {
		return uiClassID;
	}

	/**
	 * Adds new ribbon button to <code>this</code> band.
	 * 
	 * @param ribbonButton
	 *            Gallery button to add.
	 * @param priority
	 *            Priority of the button.
	 */
	public void addGalleryButton(JCommandButton ribbonButton,
			RibbonElementPriority priority) {
		this.controlPanel.addGalleryButton(ribbonButton, priority);
	}

	/**
	 * Adds new in-ribbon gallery to <code>this</code> band.
	 * 
	 * @param buttons
	 *            Button groups.
	 * @param preferredVisibleButtonCounts
	 *            Preferred count of visible buttons of the in-ribbon gallery
	 *            under different states.
	 * @param preferredPopupMaxButtonColumns
	 *            Preferred maximum columns in the popup gallery associated with
	 *            the in-ribbon gallery.
	 * @param preferredPopupMaxVisibleButtonRows
	 *            Preferred maximum visible rows in the popup gallery associated
	 *            with the in-ribbon gallery.
	 * @param priority
	 *            The initial in-ribbon gallery priority.
	 */
	public void addRibbonGallery(
			List<StringValuePair<List<JCommandToggleButton>>> buttons,
			Map<ElementState, Integer> preferredVisibleButtonCounts,
			int preferredPopupMaxButtonColumns,
			int preferredPopupMaxVisibleButtonRows,
			RibbonElementPriority priority) {
		JRibbonGallery gallery = new JRibbonGallery();
		for (Map.Entry<ElementState, Integer> prefCountEntry : preferredVisibleButtonCounts
				.entrySet()) {
			gallery.setPreferredVisibleButtonCount(prefCountEntry.getKey(),
					prefCountEntry.getValue());
		}
		gallery.setGroupMapping(buttons);
		gallery.setPreferredPopupPanelDimension(preferredPopupMaxButtonColumns,
				preferredPopupMaxVisibleButtonRows);

		this.controlPanel.addRibbonGallery(gallery, priority);
	}

	/**
	 * Adds new panel to <code>this</code> band.
	 * 
	 * @param panel
	 */
	public void addPanel(JPanel panel) {
		this.controlPanel.addPanel(panel);
	}

	/**
	 * Returns the expand action listener of <code>this</code> ribbon band.
	 * The result may be <code>null</code>.
	 * 
	 * @return Expand action listener of <code>this</code> ribbon band. The
	 *         result may be <code>null</code>.
	 */
	public ActionListener getExpandActionListener() {
		return this.expandActionListener;
	}

	/**
	 * Returns the control panel of <code>this</code> ribbon band. The result
	 * may be <code>null</code>.
	 * 
	 * @return Control panel of <code>this</code> ribbon band. The result may
	 *         be <code>null</code>.
	 */
	public JBandControlPanel getControlPanel() {
		return this.controlPanel;
	}

	/**
	 * Sets the control panel of <code>this</code> ribbon band. The parameter
	 * may be <code>null</code>.
	 * 
	 * @param controlPanel
	 *            The control panel for <code>this</code> ribbon band. May be
	 *            <code>null</code>.
	 */
	public void setControlPanel(JBandControlPanel controlPanel) {
		if (controlPanel == null) {
			this.remove(this.controlPanel);
		} else {
			this.add(controlPanel);
		}
		this.controlPanel = controlPanel;
	}
}
