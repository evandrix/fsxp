/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common;

import java.awt.Component;
import java.awt.event.ComponentEvent;
import java.util.*;

import javax.swing.JComponent;
import javax.swing.Popup;
import javax.swing.event.EventListenerList;

/**
 * Manager for showing and hiding {@link JPopupPanel}s.
 * 
 * @author Kirill Grouchnikov
 */
public class PopupPanelManager {
	public static interface PopupListener extends EventListener {
		void popupShown(PopupEvent event);

		void popupHidden(PopupEvent event);
	}

	public static class PopupEvent extends ComponentEvent {
		public static final int POPUP_SHOWN = 100;

		public static final int POPUP_HIDDEN = 101;

		private JComponent popupOriginator;

		public PopupEvent(Component source, int id, JComponent popupOriginator) {
			super(source, id);
			this.popupOriginator = popupOriginator;
		}

		public JComponent getPopupOriginator() {
			return popupOriginator;
		}
	}

	protected EventListenerList listenerList = new EventListenerList();

	private static final PopupPanelManager instance = new PopupPanelManager();

	public static class PopupInfo {
		private JPopupPanel popupPanel;

		private JComponent originalComponent;

		public PopupInfo(JComponent originalComponent, JPopupPanel popupPanel) {
			this.originalComponent = originalComponent;
			this.popupPanel = popupPanel;
		}

		public JPopupPanel getPopupPanel() {
			return popupPanel;
		}

		public JComponent getOriginalComponent() {
			return originalComponent;
		}
	}

	/**
	 * Returns the default popup panel manager.
	 * 
	 * @return a PopupPanelManager object
	 */
	public static PopupPanelManager defaultManager() {
		return instance;
	}

	/**
	 * All currently shown popup panels.
	 */
	protected LinkedList<PopupInfo> shownPath = new LinkedList<PopupInfo>();

	/**
	 * Map of all popup panels and associated {@link Popup} objects.
	 */
	protected Map<JPopupPanel, Popup> popupPanels = new HashMap<JPopupPanel, Popup>();

	/**
	 * Adds new popup to the tracking structures.
	 * 
	 * @param popup
	 *            The new popup.
	 * @param popupInitiator
	 *            The initiator of the popup.
	 */
	public void addPopup(JComponent originalComponent, Popup popup,
			JPopupPanel popupInitiator) {
		popupPanels.put(popupInitiator, popup);
		shownPath.addLast(new PopupInfo(originalComponent, popupInitiator));
		popup.show();
		this.firePopupShown(popupInitiator, originalComponent);
	}

	public void hideLastPopup() {
		if (shownPath.size() == 0)
			return;
		PopupInfo last = shownPath.removeLast();
		Popup popup = popupPanels.get(last.popupPanel);
		popup.hide();
		popupPanels.remove(last.popupPanel);
		this.firePopupHidden(last.popupPanel, last.originalComponent);
	}

	/**
	 * Hides all popup panels based on the specified component. We find the
	 * first ancestor of the specified component that is popup panel, and close
	 * all popup panels that were open from that popup panel. If the specified
	 * component is <code>null</code>, all popup panels are closed.
	 * 
	 * @param comp
	 *            Component.
	 */
	public void hidePopups(Component comp) {
		boolean foundAndDismissed = false;
		if (comp != null) {
			Component c = comp;
			// find JPopupGallery parent of the component
			while (c != null) {
				if (c instanceof JPopupPanel) {
					foundAndDismissed = true;
					// And close all popups that were opened
					// from the found popup panel
					while (shownPath.size() > 0) {
						if (shownPath.getLast().popupPanel == c)
							return;
						PopupInfo last = shownPath.removeLast();
						Popup popup = popupPanels.get(last.popupPanel);
						popup.hide();
						this.firePopupHidden(last.popupPanel,
								last.originalComponent);
						popupPanels.remove(last.popupPanel);
					}
				}
				c = c.getParent();
			}
		}
		if (!foundAndDismissed || (comp == null)) {
			while (shownPath.size() > 0) {
				PopupInfo last = shownPath.removeLast();
				Popup popup = popupPanels.get(last.popupPanel);
				popup.hide();
				this.firePopupHidden(last.popupPanel, last.originalComponent);
				popupPanels.remove(last.popupPanel);
			}
		}
	}

	public List<PopupInfo> getShownPath() {
		List<PopupInfo> toReturn = new ArrayList<PopupInfo>();
		for (PopupInfo pInfo : this.shownPath)
			toReturn.add(pInfo);
		return toReturn;
	}

	public void addPopupListener(PopupListener l) {
		listenerList.add(PopupListener.class, l);
	}

	public void removePopupListener(PopupListener l) {
		listenerList.remove(PopupListener.class, l);
	}

	public PopupListener[] PopupListener() {
		return listenerList.getListeners(PopupListener.class);
	}

	protected void firePopupShown(JPopupPanel panel, JComponent initiator) {
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		PopupEvent popupEvent = new PopupEvent(panel, PopupEvent.POPUP_SHOWN,
				initiator);
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length - 2; i >= 0; i -= 2) {
			if (listeners[i] == PopupListener.class) {
				((PopupListener) listeners[i + 1]).popupShown(popupEvent);
			}
		}
	}

	protected void firePopupHidden(JPopupPanel panel, JComponent initiator) {
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		PopupEvent popupEvent = new PopupEvent(panel, PopupEvent.POPUP_HIDDEN,
				initiator);
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length - 2; i >= 0; i -= 2) {
			if (listeners[i] == PopupListener.class) {
				((PopupListener) listeners[i + 1]).popupHidden(popupEvent);
			}
		}
	}
}
