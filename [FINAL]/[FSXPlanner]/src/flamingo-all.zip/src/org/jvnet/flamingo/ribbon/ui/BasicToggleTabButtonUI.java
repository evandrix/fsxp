/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.ribbon.ui;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.BasicToggleButtonUI;

import org.jvnet.flamingo.ribbon.JToggleTabButton;
import org.jvnet.flamingo.utils.FlamingoUtilities;
import org.jvnet.flamingo.utils.RenderingUtils;

/**
 * Basic UI for toggle button of ribbon tasks {@link JToggleTabButton}.
 * 
 * @author Kirill Grouchnikov
 */
public class BasicToggleTabButtonUI extends BasicToggleButtonUI {
	/**
	 * Used to provide a LAF-consistent appearance under core LAFs.
	 */
	protected CellRendererPane buttonRendererPane;

	/**
	 * Used to provide a LAF-consistent appearance under core LAFs.
	 */
	protected JToggleButton rendererButton;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicToggleTabButtonUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#installDefaults(javax.swing.AbstractButton)
	 */
	@Override
	protected void installDefaults(AbstractButton b) {
		super.installDefaults(b);
		Font f = b.getFont();
		if (f == null || f instanceof UIResource) {
			b.setFont(FlamingoUtilities.getFont("Ribbon.font", "Button.font",
					"Panel.font"));
		}

		Border border = b.getBorder();
		if (border == null || border instanceof UIResource) {
			Border toInstall = UIManager.getBorder("ToggleTabButton.border");
			if (toInstall == null)
				toInstall = new BorderUIResource.EmptyBorderUIResource(1, 4, 1,
						4);
			b.setBorder(toInstall);
		}

		this.buttonRendererPane = new CellRendererPane();
		b.add(buttonRendererPane);
		this.rendererButton = new JToggleButton("");

		b.setRolloverEnabled(true);
		b.setOpaque(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#uninstallDefaults(javax.swing.AbstractButton)
	 */
	@Override
	protected void uninstallDefaults(AbstractButton b) {
		b.remove(this.buttonRendererPane);
		this.buttonRendererPane = null;

		this.rendererButton = null;

		super.uninstallDefaults(b);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#paintButtonPressed(java.awt.Graphics,
	 *      javax.swing.AbstractButton)
	 */
	@Override
	protected void paintButtonPressed(Graphics g, AbstractButton b) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		Graphics2D g2d = (Graphics2D) g.create();
		RenderingUtils.installDesktopHints(g2d);
		this.paintButtonBackground(g2d, new Rectangle(0, 0, c.getWidth(), c
				.getHeight() + 10), (AbstractButton) c);
		super.paint(g2d, c);
		g2d.dispose();
	}

	protected void paintButtonBackground(Graphics graphics, Rectangle toFill,
			AbstractButton button) {
		this.buttonRendererPane.setBounds(toFill.x, toFill.y, toFill.width,
				toFill.height);
		ButtonModel model = this.rendererButton.getModel();
		model.setEnabled(button.isEnabled());
		model.setSelected(false);
		model
				.setRollover(button.isSelected()
						|| button.getModel().isRollover());
		model.setPressed(false);
		if (model.isSelected() || model.isRollover()) {
			Graphics2D g2d = (Graphics2D) graphics.create();
			if (!button.isSelected()) {
				g2d.setComposite(AlphaComposite.SrcOver.derive(0.4f));
			}
			g2d.translate(toFill.x, toFill.y);
			Shape clip = g2d.getClip();
			g2d.clip(FlamingoUtilities.getRibbonToggleButtonClip(toFill.width,
					toFill.height, 2));
			this.buttonRendererPane.paintComponent(g2d, this.rendererButton,
					button, toFill.x - toFill.width / 2, toFill.y
							- toFill.height / 2, 2 * toFill.width,
					2 * toFill.height, true);
			g2d.setColor(FlamingoUtilities.getColor(Color.gray,
					"TextField.inactiveForeground", "Button.disabledText",
					"ComboBox.disabledForeground").darker());
			g2d.setClip(clip);
			g2d.draw(FlamingoUtilities.getRibbonToggleButtonClip(toFill.width,
					toFill.height + 1, 2));
			g2d.dispose();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonUI#getPreferredSize(javax.swing.JComponent)
	 */
	@Override
	public Dimension getPreferredSize(JComponent c) {
		AbstractButton b = (AbstractButton) c;

		Icon icon = b.getIcon();
		String text = b.getText();

		Font font = b.getFont();
		FontMetrics fm = b.getFontMetrics(font);

		Rectangle iconR = new Rectangle();
		Rectangle textR = new Rectangle();
		Rectangle viewR = new Rectangle(Short.MAX_VALUE, Short.MAX_VALUE);

		SwingUtilities.layoutCompoundLabel(b, fm, text, icon, b
				.getVerticalAlignment(), b.getHorizontalAlignment(), b
				.getVerticalTextPosition(), b.getHorizontalTextPosition(),
				viewR, iconR, textR, (text == null ? 0 : b.getIconTextGap()));

		Rectangle r = iconR.union(textR);

		Insets insets = b.getInsets();
		r.width += insets.left + insets.right;
		r.height += insets.top + insets.bottom;

		return r.getSize();
	}
}
