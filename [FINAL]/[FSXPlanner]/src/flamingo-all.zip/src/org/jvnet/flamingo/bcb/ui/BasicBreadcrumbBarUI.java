/*
 * Copyright (c) 2003-2008 Flamingo Kirill Grouchnikov
 * and <a href="http://www.topologi.com">Topologi</a>. 
 * Contributed by <b>Rick Jelliffe</b> of <b>Topologi</b> 
 * in January 2006. in All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov Topologi nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.bcb.ui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.plaf.ComponentUI;

import org.jvnet.flamingo.bcb.*;
import org.jvnet.flamingo.common.StringValuePair;
import org.jvnet.flamingo.utils.FlamingoUtilities;

/**
 * Basic UI for breadcrumb bar ({@link BreadcrumbBar}).
 * 
 * @author Topologi
 * @author Kirill Grouchnikov
 */
public class BasicBreadcrumbBarUI extends BreadcrumbBarUI {
	/**
	 * The associated breadcrumb bar.
	 */
	protected BreadcrumbBar breadcrumbBar;

	protected JLabel iconLabel;

	protected JPanel mainPanel;

	protected ScrollablePanel scrollerPanel;

	protected ComponentListener componentListener;

	/**
	 * The index of the popup initiator.
	 */
	protected int popupInitiatorIndex;

	/**
	 * Popup menu.
	 */
	private JPopupMenu popup = null;

	private Map<Object, Component> comps = new HashMap<Object, Component>();

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicBreadcrumbBarUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#installUI(javax.swing.JComponent)
	 */
	@Override
	public void installUI(JComponent c) {
		this.breadcrumbBar = (BreadcrumbBar) c;
		installDefaults(this.breadcrumbBar);
		installComponents(this.breadcrumbBar);
		installListeners(this.breadcrumbBar);

		c.setLayout(createLayoutManager());
		this.popupInitiatorIndex = -1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		c.setLayout(null);

		uninstallListeners((BreadcrumbBar) c);
		uninstallComponents((BreadcrumbBar) c);
		uninstallDefaults((BreadcrumbBar) c);
		this.breadcrumbBar = null;
	}

	protected void installDefaults(BreadcrumbBar bar) {
		Font font = FlamingoUtilities.getFont("BreadcrumbBar.font",
				"Button.font", "Panel.font");
		bar.setFont(font);
	}

	protected void installComponents(BreadcrumbBar bar) {
		this.mainPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		this.mainPanel.setOpaque(false);
		this.scrollerPanel = new ScrollablePanel(this.mainPanel);

		bar.add(this.scrollerPanel, BorderLayout.CENTER);
		Icon barIcon = bar.getIcon();
		if (barIcon != null) {
			this.iconLabel = new JLabel(barIcon);
			this.iconLabel.setOpaque(false);
			bar.add(this.iconLabel, BorderLayout.WEST);
		}
		if (bar.getOkButton() != null)
			bar.add(bar.getOkButton(), BorderLayout.EAST);

		// this.updateComponents();
	}

	protected void installListeners(final BreadcrumbBar bar) {
		this.componentListener = new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				updateComponents();
			}
		};
		bar.addComponentListener(this.componentListener);
	}

	protected void uninstallDefaults(BreadcrumbBar bar) {
	}

	protected void uninstallComponents(BreadcrumbBar bar) {
		if (this.iconLabel != null) {
			bar.remove(this.iconLabel);
			this.iconLabel = null;
		}

		this.mainPanel.removeAll();
		this.comps.clear();

		bar.remove(this.scrollerPanel);
		if (bar.getOkButton() != null)
			bar.remove(bar.getOkButton());

		//
		// for (Iterator iter = this.breadcrumbBar.getStack().iterator(); iter
		// .hasNext();) {
		// Object element = iter.next();
		// if (element instanceof BreadcrumbItemChoices) {
		// BreadcrumbItemChoices bic = (BreadcrumbItemChoices) element;
		// this.mainPanel.remove(bic.getComponent());
		// bic.setComponent(null);
		// } else if (element instanceof BreadcrumbItem) {
		// BreadcrumbItem bi = (BreadcrumbItem) element;
		// this.mainPanel.remove(bi.getComponent());
		// bi.setComponent(null);
		// }
		// }
	}

	protected void uninstallListeners(BreadcrumbBar bar) {
		bar.removeComponentListener(this.componentListener);
		this.componentListener = null;
	}

	/**
	 * Invoked by <code>installUI</code> to create a layout manager object to
	 * manage the {@link BreadcrumbBar}.
	 * 
	 * @return a layout manager object
	 * 
	 * @see BreadcrumbBarLayout
	 */
	protected LayoutManager createLayoutManager() {
		return new BreadcrumbBarLayout();
	}

	/**
	 * Returns the popup menu of <code>this</code> breadcrumb bar.
	 * 
	 * @return The popup menu of <code>this</code> breadcrumb bar.
	 */
	@Override
	public JPopupMenu getPopup() {
		if (popup == null) {
			popup = new ScrollablePopup(15);
			popup.setFont(breadcrumbBar.getFont());
			popup.setBorder(BorderFactory.createLineBorder(Color.black));
			popup.addPopupMenuListener(new PopupMenuListener() {
				public void popupMenuCanceled(PopupMenuEvent e) {
					popupInitiatorIndex = -1;
				}

				public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
					popupInitiatorIndex = -1;
				};

				public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
				}
			});
		}
		return popup;
	}

	/**
	 * Hides the popup menu.
	 */
	@Override
	public void hidePopup() {
		getPopup().setVisible(false);
	}

	/**
	 * Layout for the breadcrumb bar.
	 * 
	 * @author Kirill Grouchnikov
	 * @author Topologi
	 */
	protected class BreadcrumbBarLayout implements LayoutManager {
		/**
		 * Creates new layout manager.
		 */
		public BreadcrumbBarLayout() {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container c) {
			return new Dimension(c.getWidth(), 21);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container c) {
			return this.preferredLayoutSize(c);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container c) {
			int width = c.getWidth();
			int height = c.getHeight();

			BreadcrumbBar bar = breadcrumbBar;

			int x = 0;
			if (iconLabel != null) {
				int ipw = iconLabel.getPreferredSize().width;
				iconLabel.setBounds(x, 0, ipw, height);
				x += ipw;
			}
			int rx = width;
			JButton okButton = bar.getOkButton();
			if (okButton != null) {
				int opw = okButton.getPreferredSize().width;
				okButton.setBounds(width - opw, 0, opw, height);
				rx -= opw;
			}

			scrollerPanel.setBounds(x, 0, rx - x, height);
		}
	}

	/**
	 * ScrollablePanel allows to have scrolling buttons on each side.
	 * 
	 * @author jb Creation date: Nov 13, 2003
	 */
	public class ScrollablePanel extends JPanel {
		private JButton leftScroller;

		private JButton rightScroller;

		private JScrollPane scrollPane;

		private JComponent view = null;

		private MouseListener scrollMouseListener = null;

		private int widthToScrollTo = 0;

		public ScrollablePanel(JComponent c) {
			super();
			view = c;
			this.scrollPane = new JScrollPane();
			this.scrollPane.setBorder(BorderFactory.createEmptyBorder(2, 0, 2,
					0));
			this.scrollPane.setOpaque(false);
			this.scrollPane
					.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			this.scrollPane
					.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
			this.scrollPane.setAutoscrolls(false);
			this.scrollPane.getViewport().setOpaque(false);
			this.scrollPane.setViewportView(c);
			setOpaque(false);
			add(this.scrollPane);

			this.leftScroller = getLeftScroller();
			this.leftScroller.setName("leftScroller");
			this.leftScroller.addMouseListener(getScrollerMouseListener());
			this.rightScroller = getRightScroller();
			this.rightScroller.setName("rightScroller");
			this.rightScroller.addMouseListener(getScrollerMouseListener());
			this.setLayout(new ScrollablePanelLayout());
		}

		public void increaseWidthBy(int increaseBy) {
			validateScrolling(widthToScrollTo + increaseBy);
		}

		public void validateScrolling(int width) {
			widthToScrollTo = width;
			int visibleWidth = view.getVisibleRect().width - 4;
			if (visibleWidth > 0 && visibleWidth < widthToScrollTo) {
				int x;
				if (getComponentCount() <= 1) {
					addScrollers();
					x = widthToScrollTo + this.leftScroller.getWidth()
							+ this.rightScroller.getWidth() - 4;
				} else {
					x = widthToScrollTo - 4;
				}
				// scroll to last item
				view.scrollRectToVisible(new Rectangle(x, 0, 4, 4));
			} else {
				removeScrollers();
			}
		}

		public void removeScrollers() {
			view.scrollRectToVisible(new Rectangle(0, 0, 2, 2));
			remove(this.leftScroller);
			remove(this.rightScroller);
			revalidate();
			repaint();
		}

		private void addScrollers() {
			add(this.leftScroller, BorderLayout.WEST);
			add(this.rightScroller, BorderLayout.EAST);
			revalidate();
			repaint();
		}

		public MouseListener getScrollerMouseListener() {
			if (scrollMouseListener == null) {
				scrollMouseListener = new MouseAdapter() {
					private boolean isPressed = false;

					@Override
					public void mousePressed(MouseEvent e) {
						isPressed = true;
						final boolean left = ((JComponent) e.getSource())
								.getName().startsWith("left");
						Thread scroller = new Thread() {
							@Override
							public void run() {
								int scrollBy = 12;
								int i = 0;
								while (isPressed) {
									double x;
									if (left)
										x = view.getVisibleRect().getX()
												- scrollBy;
									else
										x = view.getVisibleRect().getX()
												+ view.getVisibleRect()
														.getWidth();
									if (x > widthToScrollTo)
										break;
									Rectangle rect = new Rectangle((int) x, 0,
											scrollBy, 8);
									// scroll the view to see the rectangle
									view.scrollRectToVisible(rect);
									try {
										Thread.sleep(100);
									} catch (InterruptedException e1) {
									}
									if (i > 2)
										scrollBy += 5;
									i++;
									Thread.yield();
								}
							}
						};
						scroller.start();
					}

					@Override
					public void mouseReleased(MouseEvent e) {
						isPressed = false;
					}
				};
			}
			return scrollMouseListener;
		}
	}

	/**
	 * Layout for the scrollable panel.
	 * 
	 * @author Kirill Grouchnikov
	 * @author Topologi
	 */
	protected class ScrollablePanelLayout implements LayoutManager {
		/**
		 * Creates new layout manager.
		 */
		public ScrollablePanelLayout() {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container c) {
			return new Dimension(c.getWidth(), 21);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container c) {
			return this.preferredLayoutSize(c);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container c) {
			int width = c.getWidth();
			int height = c.getHeight();

			ScrollablePanel sPanel = scrollerPanel;
			boolean isScrollerButtonsShowing = (sPanel.leftScroller.getParent() == scrollerPanel);
			int scrollPanelWidth = isScrollerButtonsShowing ? width
					- sPanel.leftScroller.getPreferredSize().width
					- sPanel.rightScroller.getPreferredSize().width - 4 : width;
			int x = 0;
			if (isScrollerButtonsShowing) {
				int spw = sPanel.leftScroller.getPreferredSize().width;
				int sph = sPanel.leftScroller.getPreferredSize().height;
				sPanel.leftScroller.setBounds(0, (height - sph) / 2, spw, sph);
				x += spw + 2;
			}
			sPanel.scrollPane.setBounds(x, 0, scrollPanelWidth, height);
			x += scrollPanelWidth + 2;
			if (isScrollerButtonsShowing) {
				int spw = sPanel.rightScroller.getPreferredSize().width;
				int sph = sPanel.rightScroller.getPreferredSize().height;
				sPanel.rightScroller.setBounds(x, (height - sph) / 2, spw, sph);
			}
		}
	}

	@Override
	public int updateComponents() {
		if (this.breadcrumbBar.getStack() == null)
			return 0;
		if (!this.breadcrumbBar.isVisible())
			return 0;
		synchronized (this.breadcrumbBar.getStack()) {

			this.mainPanel.removeAll();
			comps.clear();
			this.scrollerPanel.removeScrollers();
			// update the ui
			int width = 0;
			JComponent c = null;
			for (Iterator iter = this.breadcrumbBar.getStack().iterator(); iter
					.hasNext();) {
				Object element = iter.next();
				if (element instanceof BreadcrumbItemChoices) {
					BreadcrumbItemChoices bic = (BreadcrumbItemChoices) element;
					// c = bic.getComponent();
					// if (c == null) {
					c = new ChoicesSelector(this.breadcrumbBar, bic,
							this.breadcrumbBar.getSeparator());
					// bic.setComponent(c);
					// }
					// else {
					// ((JComponent)c).updateUI();
					// }
					comps.put(bic, c);
				} else if (element instanceof BreadcrumbItem) {
					BreadcrumbItem bi = (BreadcrumbItem) element;
					// c = bi.getComponent();
					// if (c == null) {
					c = new BreadcrumbParticle(this.breadcrumbBar, bi,
							this.breadcrumbBar.getFontMetrics(
									this.breadcrumbBar.getFont()).stringWidth(
									bi.getKey()));
					// bi.setComponent(c);
					// }
					// else {
					// ((JComponent)c).updateUI();
					// }
					comps.put(bi, c);
				}
				width += c.getPreferredSize().getWidth();
				this.mainPanel.add(c);
			}
			this.scrollerPanel.validateScrolling(width);
			this.mainPanel.validate();
			this.mainPanel.repaint();
			if (c != null
					&& this.breadcrumbBar.getStack().lastElement() instanceof BreadcrumbItem)
				c.requestFocus();
			return width;
		}
	}

	@Override
	public boolean popup(int componentIndex) {
		// try to show popup
		if (componentIndex < 0
				|| componentIndex >= this.mainPanel.getComponentCount())
			return false;
		Component c = mainPanel.getComponent(componentIndex);
		if (c != null && c instanceof ChoicesSelector) {
			ChoicesSelector selector = (ChoicesSelector) c;
			return this.showPopup(selector.getIndex(), selector
					.getBreadcrumbChoices());
		}
		return false;
	}

	/**
	 * Shows the popup menu based on the specified parameters.
	 * 
	 * @param selectorIndex
	 *            The index of the originating selector.
	 * @param bic
	 *            The choice element.
	 * @return If <code>true</code>, the popup was shown (the choice element
	 *         was not empty). If <code>false</code>, the popup was not
	 *         shown.
	 */
	public boolean showPopup(int selectorIndex, BreadcrumbItemChoices bic) {
		JPopupMenu popup = this.getPopup();
		this.popupInitiatorIndex = selectorIndex;
		popup.removeAll();
		Component toSelect = null;
		for (int i = 0; i < bic.getChoices().length; i++) {
			BreadcrumbItem bi = bic.getChoices()[i];
			Action action = new PopupAction(bi, bic.getIndex());
			JMenuItem item = popup.add(action);
			if (item != null) {
				// not hidden by scrollable popup
				item.setFont(breadcrumbBar.getFont());
				popup.setBackground(item.getBackground());
				// item.setForeground(getForeground());
				item.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				// if (i == 0)
				// toSelect = item;
			}
		}
		// check for next component
		if (breadcrumbBar.getItemCount() > bic.getIndex() + 1) {
			Object c = breadcrumbBar.getItem(bic.getIndex() + 1);
			if (c != null && c instanceof BreadcrumbItem) {
				// BreadcrumbItem bi = (BreadcrumbItem)
				// getValue(BreadCrumbItem_Key);
				toSelect = new JLabel(((BreadcrumbItem) c).getKey());
			}
		}
		if (bic.getChoices().length > 0) {
			// System.out.println("Popup has " + popup.getComponentCount()
			// + " elements");
			// popup.revalidate();
			popup.show(comps.get(bic), 0, comps.get(bic).getHeight());
			if (toSelect != null)
				popup.setSelected(toSelect);
			return true;
		}
		this.popupInitiatorIndex = -1;
		return false;
	}

	@Override
	public BreadcrumbParticle getParticle(int selectorIndex) {
		if (selectorIndex == 0
				|| selectorIndex >= this.mainPanel.getComponentCount())
			return null;
		Component c = mainPanel.getComponent(selectorIndex);
		if (c != null && c instanceof ChoicesSelector) {
			return (BreadcrumbParticle) mainPanel
					.getComponent(selectorIndex - 1);
		}
		return null;
	}

	@Override
	public ChoicesSelector getSelector(int selectorIndex) {
		if (selectorIndex == 0
				|| selectorIndex >= this.mainPanel.getComponentCount())
			return null;
		Component c = mainPanel.getComponent(selectorIndex);
		if (c != null && c instanceof ChoicesSelector) {
			return (ChoicesSelector) c;
		}
		return null;
	}

	protected JButton createScrollingButton() {
		JButton b = new JButton();
		b.setBorder(BorderFactory.createEmptyBorder());
		b.setMargin(new Insets(0, 0, 0, 0));
		b.setFocusPainted(false);
		// b.setPreferredSize(new Dimension(13, 14));
		b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		return b;
	}

	protected JButton getLeftScroller() {
		JButton scroller = this.createScrollingButton();
		scroller.setText("<");
		return scroller;
	}

	protected JButton getRightScroller() {
		JButton scroller = this.createScrollingButton();
		scroller.setText(">");
		return scroller;
	}

	/**
	 * Action for the popup menu.
	 */
	private class PopupAction<T> extends AbstractAction {
		/**
		 * Key for the breadcrumb item.
		 */
		private static final String BreadCrumbItem_Key = "BreadCrumbItem";

		/**
		 * Key for parent index.
		 */
		private static final String ParentIndex_Key = "ParentIndex";

		/**
		 * Simple constructor.
		 * 
		 * @param bi
		 *            Item.
		 * @param parentIndex
		 *            Index of the parent.
		 */
		public PopupAction(BreadcrumbItem<T> bi, int parentIndex) {
			super(bi.getKey(), bi.getIcon());
			putValue(BreadCrumbItem_Key, bi);
			putValue(ParentIndex_Key, new Integer(parentIndex));
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
		 */
		public void actionPerformed(ActionEvent e) {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					final BreadcrumbItem<T> bi = (BreadcrumbItem<T>) getValue(BreadCrumbItem_Key);
					if (bi == null)
						return;
					// clear the rest of the stack
					int index = (Integer) getValue(ParentIndex_Key);
					while (breadcrumbBar.getItemCount() > index + 1)
						breadcrumbBar.pop();
					// push the new choice and update the component state, since
					// the choices will be fetched asynchronously.
					breadcrumbBar.pushChoice(bi, true);
					final String biText = bi.getKey();
					BreadcrumbParticle<T> particle = (BreadcrumbParticle<T>) comps
							.get(bi);
					particle.setText(biText + "...");
					mainPanel.validate();
					mainPanel.repaint();
					SwingWorker<List<StringValuePair<T>>, Void> worker = new SwingWorker<List<StringValuePair<T>>, Void>() {
						@Override
						protected List<StringValuePair<T>> doInBackground()
								throws Exception {
							return breadcrumbBar.getCallback().getPathChoices(
									breadcrumbBar.getPath());
						}

						@Override
						protected void done() {
							try {
								List<StringValuePair<T>> choices = get();
								if ((choices != null) && (choices.size() > 0)) {
									BreadcrumbItemChoices<T> bic = new BreadcrumbItemChoices<T>(
											choices);
									breadcrumbBar.pushChoices(bic, false);
									updateComponents();
								}
							} catch (Throwable t) {
								List<BreadcrumbBarExceptionHandler> handlers = breadcrumbBar
										.getExceptionHandlers();
								for (BreadcrumbBarExceptionHandler handler : handlers) {
									handler.onException(t);
								}
							}
							BreadcrumbParticle<T> particle = (BreadcrumbParticle<T>) comps
									.get(bi);
							if (particle == null) {
								// can happen if another selection has been made
								// while the choices were asynchronously
								// loading.
								return;
							}
							particle.setText(biText);
							mainPanel.validate();
							mainPanel.repaint();
						}
					};
					worker.execute();
				}
			});
		}
	}

	/**
	 * Returns the index of the popup initiator.
	 * 
	 * @return The index of the popup initiator.
	 */
	@Override
	public int getPopupInitiatorIndex() {
		return this.popupInitiatorIndex;
	}
}