/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common.ui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.StringTokenizer;

import javax.swing.*;
import javax.swing.plaf.BorderUIResource;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicGraphicsUtils;

import org.jvnet.flamingo.common.*;
import org.jvnet.flamingo.common.icon.ResizableIcon;
import org.jvnet.flamingo.utils.FlamingoUtilities;
import org.jvnet.flamingo.utils.RenderingUtils;

/**
 * Basic UI for command button {@link JCommandButton}.
 * 
 * @author Kirill Grouchnikov
 */
public class BasicCommandButtonUI extends CommandButtonUI {
	/**
	 * The associated command button.
	 */
	protected AbstractCommandButton commandButton;

	/**
	 * Indication whether the mouse pointer is over the associated command
	 * button.
	 */
	protected boolean isUnderMouse;

	/**
	 * Property change listener.
	 */
	protected PropertyChangeListener propertyChangeListener;

	protected BasicPopupButtonListener basicPopupButtonListener;

	// protected PopupListener galleryPopupActionListener;

	protected Rectangle actionClickArea;

	protected Rectangle popupClickArea;

	public static final String EMULATE_SQUARE_BUTTON = "flamingo.internal.commandButton.ui.emulateSquare";

	public static final String DONT_DISPOSE_POPUPS = "flamingo.internal.commandButton.ui.dontDisposePopups";

	protected ActionListener disposePopupsActionListener;

	/**
	 * The first part of (possibly) two-lined split of {@link #commandButton}'s
	 * title.
	 */
	protected String titlePart1;

	/**
	 * The second part of (possibly) two-lined split of {@link #commandButton}'s
	 * title.
	 */
	protected String titlePart2;

	/**
	 * The "expand" action icon.
	 */
	protected Icon actionIcon;

	/**
	 * Indication whether the {@link #savedDimension} should be used during the
	 * layout.
	 */
	protected boolean toTakeSavedDimension;

	/**
	 * Saved dimension for speeding up the layout.
	 */
	protected Dimension savedDimension;

	/**
	 * Used to provide a LAF-consistent appearance under core LAFs.
	 */
	protected CellRendererPane buttonRendererPane;

	/**
	 * Used to provide a LAF-consistent appearance under core LAFs.
	 */
	protected JToggleButton rendererButton;

	protected JSeparator rendererSeparator;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicCommandButtonUI();
	}

	/**
	 * Creates a new UI delegate.
	 */
	public BasicCommandButtonUI() {
		this.toTakeSavedDimension = false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#installUI(javax.swing.JComponent)
	 */
	@Override
	public void installUI(JComponent c) {
		this.commandButton = (AbstractCommandButton) c;
		installDefaults();
		installComponents();
		installListeners();
		installKeyboardActions();
		this.commandButton.setLayout(createLayoutManager());
		if (this.commandButton.getState() != null)
			this.updateState(this.commandButton.getState(), false);

		this.updateCustomDimension();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		c.setLayout(null);

		uninstallKeyboardActions();
		uninstallListeners();
		uninstallComponents();
		uninstallDefaults();
		this.commandButton = null;
	}

	/**
	 * Installs defaults on the associated command button.
	 */
	protected void installDefaults() {
		this.commandButton.setRolloverEnabled(true);
		this.buttonRendererPane = new CellRendererPane();
		this.commandButton.add(buttonRendererPane);
		this.rendererButton = new JToggleButton("");
		this.rendererSeparator = new JSeparator();

		// create a dummy button
		JToggleButton button = new JToggleButton(new Icon() {
			@Override
			public int getIconHeight() {
				return 16;
			}

			@Override
			public int getIconWidth() {
				return 16;
			}

			@Override
			public void paintIcon(Component c, Graphics g, int x, int y) {
			}
		});
		button.setText(null);
		// Compute how many pixels the specific LAF allocates
		// around the icon. Some LAFs (such as Nimbus, for example)
		// require more pixels around the button contents. This
		// code tries to re-create the LAF-specific button margins.
		int topBottom = (button.getMinimumSize().height - 16) / 2 - 2;
		int leftRight = (button.getMinimumSize().width - 16) / 3;

		this.commandButton
				.setBorder(new BorderUIResource.EmptyBorderUIResource(
						topBottom, leftRight, topBottom, leftRight));
	}

	/**
	 * Installs subcomponents on the associated command button.
	 */
	protected void installComponents() {
		// Break the title in two parts (the second part may be empty),
		// finding the "inflection" point. The inflection point is a space
		// character that breaks the title in two parts, such that the maximal
		// length of the first part and the second part + action label icon
		// is minimal between all possible space characters
		BufferedImage tempImage = new BufferedImage(30, 30,
				BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) tempImage.getGraphics();
		g.setFont(FlamingoUtilities.getFont("Ribbon.font", "Button.font",
				"Panel.font"));
		FontMetrics fm = g.getFontMetrics();

		this.updateActionIcon();
		String title = this.commandButton.getTitle();
		if (title != null) {
			StringTokenizer tokenizer = new StringTokenizer(title, " _-", true);
			if (tokenizer.countTokens() <= 1) {
				// single word
				this.titlePart1 = title;
				this.titlePart2 = "";
			} else {
				int currMaxLength = (int) fm.getStringBounds(
						this.commandButton.getTitle(), g).getWidth();
				int actionIconWidth = (this.actionIcon == null) ? 0
						: 4 + this.actionIcon.getIconWidth();

				String currLeading = "";
				while (tokenizer.hasMoreTokens()) {
					currLeading += tokenizer.nextToken();
					String part1 = currLeading;
					String part2 = title.substring(currLeading.length());

					int len1 = (int) fm.getStringBounds(part1, g).getWidth();
					int len2 = (int) fm.getStringBounds(part2, g).getWidth()
							+ actionIconWidth;
					int len = Math.max(len1, len2);

					if (currMaxLength > len) {
						currMaxLength = len;
						this.titlePart1 = part1;
						this.titlePart2 = part2;
					}
				}
			}
		} else {
			this.titlePart1 = "";
			this.titlePart2 = "";
		}

		ResizableIcon buttonIcon = this.commandButton.getIcon();
		if (buttonIcon instanceof AsynchronousLoading) {
			((AsynchronousLoading) buttonIcon)
					.addAsynchronousLoadListener(new AsynchronousLoadListener() {
						public void completed(boolean success) {
							if (success && (commandButton != null))
								commandButton.repaint();
						}
					});
		}

		if (this.commandButton instanceof JCommandButton) {
			if (((JCommandButton) this.commandButton).getPopupPanel() != null) {
				this.actionIcon = UIManager.getIcon("GalleryButton.expandIcon");
				if (this.actionIcon == null)
					this.actionIcon = FlamingoUtilities.getGalleryExpandIcon();
			}
		}
	}

	/**
	 * Installs listeners on the associated command button.
	 */
	protected void installListeners() {
		this.basicPopupButtonListener = createButtonListener(this.commandButton);
		if (this.basicPopupButtonListener != null) {
			this.commandButton.addMouseListener(this.basicPopupButtonListener);
			this.commandButton
					.addMouseMotionListener(this.basicPopupButtonListener);
			this.commandButton.addFocusListener(this.basicPopupButtonListener);
			this.commandButton
					.addPropertyChangeListener(this.basicPopupButtonListener);
			this.commandButton.addChangeListener(this.basicPopupButtonListener);
		}

		this.propertyChangeListener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (AbstractButton.ICON_CHANGED_PROPERTY.equals(evt
						.getPropertyName())) {
					Icon newIcon = (Icon) evt.getNewValue();
					if (newIcon instanceof AsynchronousLoading) {
						((AsynchronousLoading) newIcon)
								.addAsynchronousLoadListener(new AsynchronousLoadListener() {
									public void completed(boolean success) {
										if (success)
											commandButton.repaint();
									}
								});
					}
				}
				if ("commandButtonKind".equals(evt.getPropertyName())) {
					updateActionIcon();
				}
				if ("popupGallery".equals(evt.getPropertyName())) {
					updateActionIcon();
				}
				if ("customDimension".equals(evt.getPropertyName())) {
					updateCustomDimension();
				}
			}
		};
		this.commandButton
				.addPropertyChangeListener(this.propertyChangeListener);

		this.disposePopupsActionListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!Boolean.TRUE.equals(commandButton
						.getClientProperty(DONT_DISPOSE_POPUPS))) {
					PopupPanelManager.defaultManager().hidePopups(null);
				}
			}
		};
		this.commandButton.addActionListener(this.disposePopupsActionListener);

		// if (this.commandButton instanceof JCommandButton) {
		// this.galleryPopupActionListener = new PopupListener() {
		// public void actionPerformed(ActionEvent e) {
		// JPopupGallery.hidePopups(commandButton);
		//
		// if (!(commandButton instanceof JCommandButton)) {
		// return;
		// }
		//
		// SwingUtilities.invokeLater(new Runnable() {
		// public void run() {
		// PopupFactory popupFactory = PopupFactory
		// .getSharedInstance();
		//
		// JPopupGallery gallery = ((JCommandButton) commandButton)
		// .getGallery();
		// if ((commandButton == null) || (gallery == null)
		// || gallery.isEmpty())
		// return;
		// int x = commandButton.getLocationOnScreen().x;
		// int y = commandButton.getLocationOnScreen().y
		// + commandButton.getSize().height;
		// // System.out.println("Showing "
		// // + jgb.gallery.getComponent());
		//
		// // make sure that the popup gallery stays in bounds
		// Rectangle scrBounds = commandButton
		// .getGraphicsConfiguration().getBounds();
		// int pw = gallery.getPreferredSize().width;
		// if ((x + pw) > (scrBounds.x + scrBounds.width)) {
		// x = scrBounds.x + scrBounds.width - pw;
		// }
		// int ph = gallery.getPreferredSize().height;
		// if ((y + ph) > (scrBounds.y + scrBounds.height)) {
		// y = scrBounds.y + scrBounds.height - ph;
		// }
		//
		// // get the popup and show it
		// Popup popup = popupFactory.getPopup(commandButton,
		// gallery, x, y);
		// popup.show();
		// JPopupGallery.addPopup(popup, gallery);
		// // popupButtons.put(popup, jgb);
		// // popupGalleries.put(popup, jgb.gallery);
		// }
		// });
		// }
		// };
		// ((JCommandButton) this.commandButton)
		// .addPopupActionListener(this.galleryPopupActionListener);
		// }
	}

	protected BasicPopupButtonListener createButtonListener(
			AbstractCommandButton b) {
		return new BasicPopupButtonListener(b);
	}

	/**
	 * Installs the keyboard actions on the associated command button.
	 */
	protected void installKeyboardActions() {
		if (this.basicPopupButtonListener != null) {
			basicPopupButtonListener.installKeyboardActions(this.commandButton);
		}
	}

	/**
	 * Uninstalls defaults from the associated command button.
	 */
	protected void uninstallDefaults() {
		this.commandButton.remove(this.buttonRendererPane);
		this.buttonRendererPane = null;
	}

	/**
	 * Uninstalls subcomponents from the associated command button.
	 */
	protected void uninstallComponents() {
	}

	/**
	 * Uninstalls listeners from the associated command button.
	 */
	protected void uninstallListeners() {
		if (this.basicPopupButtonListener != null) {
			this.commandButton
					.removeMouseListener(this.basicPopupButtonListener);
			this.commandButton
					.removeMouseListener(this.basicPopupButtonListener);
			this.commandButton
					.removeMouseMotionListener(this.basicPopupButtonListener);
			this.commandButton
					.removeFocusListener(this.basicPopupButtonListener);
			this.commandButton
					.removeChangeListener(this.basicPopupButtonListener);
			this.commandButton
					.removePropertyChangeListener(this.basicPopupButtonListener);
		}

		this.commandButton
				.removePropertyChangeListener(this.propertyChangeListener);
		this.propertyChangeListener = null;

		this.commandButton
				.removeActionListener(this.disposePopupsActionListener);
		this.disposePopupsActionListener = null;

		//
		// if (this.commandButton instanceof JCommandButton) {
		// ((JCommandButton) this.commandButton)
		// .removePopupActionListener(this.galleryPopupActionListener);
		// this.galleryPopupActionListener = null;
		// }
	}

	/**
	 * Uninstalls the keyboard actions from the associated command button.
	 */
	protected void uninstallKeyboardActions() {
		if (this.basicPopupButtonListener != null) {
			this.basicPopupButtonListener
					.uninstallKeyboardActions(this.commandButton);
		}
	}

	/**
	 * Invoked by <code>installUI</code> to create a layout manager object to
	 * manage the {@link JButtonStrip}.
	 * 
	 * @return a layout manager object
	 */
	protected LayoutManager createLayoutManager() {
		return new CommandButtonLayout();
	}

	/**
	 * Layout for the command button.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class CommandButtonLayout implements LayoutManager {
		/**
		 * Off-screen font metrics for laying out the title labels.
		 */
		private FontMetrics fm;

		/**
		 * Off-screen graphic context for laying out the title labels.
		 */
		private Graphics2D graphics;

		/**
		 * Creates new layout manager.
		 */
		public CommandButtonLayout() {
			this.graphics = (Graphics2D) new BufferedImage(1, 1,
					BufferedImage.TYPE_INT_ARGB).getGraphics();
			this.graphics.setFont(FlamingoUtilities.getFont("Ribbon.font",
					"Button.font", "Panel.font"));
			this.fm = graphics.getFontMetrics();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container c) {

			Insets borderInsets = commandButton.getInsets();
			int bx = borderInsets.left + borderInsets.right;
			int by = borderInsets.top + borderInsets.bottom;

			Dimension iconDim = toTakeSavedDimension ? savedDimension
					: new Dimension(commandButton.getIcon().getIconWidth(),
							commandButton.getIcon().getIconHeight());

			JSeparator jsep = new JSeparator(JSeparator.VERTICAL);
			int layoutGap = getLayoutGap();

			switch (commandButton.getState()) {
			case SMALL:
				// no label, only icon and action arrow icon
				return new Dimension(bx
						+ commandButton.getIcon().getIconWidth()
						+ ((actionIcon != null) ? 2 * layoutGap
								+ jsep.getPreferredSize().width
								+ actionIcon.getIconWidth() : 0), by
						+ iconDim.height);
			case MEDIUM:
			case TILE:
				// icon, one-line label and action-arrow icon
				Rectangle2D rectTitle = fm.getStringBounds(commandButton
						.getTitle(), this.graphics);
				String extraText = commandButton.getExtraText();
				Rectangle2D rectExtra = fm.getStringBounds(
						(extraText == null) ? "" : extraText, this.graphics);
				double textWidth = (commandButton.getState() == ElementState.MEDIUM) ? rectTitle
						.getWidth()
						: Math.max(rectTitle.getWidth(), rectExtra.getWidth());
				int widthMed = iconDim.width
						+ 2
						* layoutGap
						+ jsep.getPreferredSize().width
						+ (int) textWidth
						+ ((actionIcon != null) ? actionIcon.getIconWidth() + 2
								* layoutGap + jsep.getPreferredSize().width : 0);
				// System.out.println(ribbonButton.getTitle() + ":" + widthMed);
				int textLines = 1 + ((commandButton.getState() == ElementState.TILE) ? 1
						: 0);
				return new Dimension(bx + widthMed, by
						+ Math.max(iconDim.height, textLines
								* (fm.getAscent() + fm.getDescent())
								+ (textLines - 1) * layoutGap));
			case CUSTOM:
			case BIG:
			case ORIG:
				// icon, two labels and action-arrow (on the second label)
				Rectangle2D rect1 = fm.getStringBounds(titlePart1,
						this.graphics);
				Rectangle2D rect2 = fm.getStringBounds(titlePart2,
						this.graphics);

				int width = Math.max(iconDim.width, (int) Math.max(rect1
						.getWidth(),
						rect2.getWidth()
								+ layoutGap
								+ ((actionIcon != null) ? actionIcon
										.getIconWidth() : 0)));

				int height = by + iconDim.height + layoutGap
						+ jsep.getPreferredSize().width;
				if (commandButton.getTitle() != null) {
					height += (2 * fm.getAscent() + fm.getDescent());
				}
				return new Dimension(bx + width, height);

			case BIG_FIXED_LANDSCAPE:
				// icon, label
				Rectangle2D rectFullTitle = fm.getStringBounds(commandButton
						.getTitle(), this.graphics);

				int widthFull = Math.max(iconDim.width, (int) rectFullTitle
						.getWidth());

				int heightFull = by + iconDim.height + layoutGap
						+ jsep.getPreferredSize().width;
				if (commandButton.getTitle() != null) {
					heightFull += (fm.getAscent() + fm.getDescent());
				}

				widthFull = Math.max(widthFull, heightFull * 5 / 4);
				return new Dimension(bx + widthFull, heightFull);
			}
			return null;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container c) {
			return this.preferredLayoutSize(c);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container c) {
			ElementState state = commandButton.getState();
			int height = state.getPreferredSize();
			if (height > 0) {
				commandButton.getIcon().setHeight(state.getPreferredSize());
			} else {
				if (state == ElementState.ORIG)
					commandButton.getIcon().revertToOriginalDimension();
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		Graphics2D g2d = (Graphics2D) g.create();
		RenderingUtils.installDesktopHints(g2d);
		super.update(g2d, c);
		g2d.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void paint(Graphics g, JComponent c) {
		if (this.isPaintingBackground()) {
			this.paintButtonBackground(g, new Rectangle(0, 0, c.getWidth(), c
					.getHeight()));
		}

		g.setFont(FlamingoUtilities.getFont("Ribbon.font", "Button.font",
				"Panel.font"));

		JCommandButton.CommandButtonKind buttonKind = (commandButton instanceof JCommandButton) ? ((JCommandButton) commandButton)
				.getCommandButtonKind()
				: JCommandButton.CommandButtonKind.ACTION_ONLY;

		this.actionClickArea = new Rectangle(0, 0, 0, 0);
		this.popupClickArea = new Rectangle(0, 0, 0, 0);

		Insets ins = c.getInsets();

		Rectangle iconRect = new Rectangle();
		Rectangle bigLabel1Rect = new Rectangle();
		Rectangle bigLabel2Rect = new Rectangle();
		Rectangle midLabelRect = new Rectangle();
		Rectangle midExtraLabelRect = new Rectangle();
		Rectangle actionArrowLabelRect = new Rectangle();

		layoutButtonComponents(g, c, buttonKind, iconRect, bigLabel1Rect,
				bigLabel2Rect, midLabelRect, midExtraLabelRect,
				actionArrowLabelRect);

		if (iconRect != null) {
			this.paintButtonIcon(g, iconRect);
		}
		if (actionArrowLabelRect.getWidth() > 0) {
			actionIcon.paintIcon(this.commandButton, g, actionArrowLabelRect.x,
					actionArrowLabelRect.y);
		}
		FontMetrics fm = g.getFontMetrics();
		g
				.setColor(FlamingoUtilities.getColor(Color.black,
						"Button.foreground"));
		if (bigLabel1Rect.getWidth() > 0) {
			int mnemonicChar = this.commandButton.getMnemonic();
			BasicGraphicsUtils.drawString(g, titlePart1, mnemonicChar,
					bigLabel1Rect.x, bigLabel1Rect.y + fm.getAscent());
		}
		if (bigLabel2Rect.getWidth() > 0) {
			int mnemonicChar = this.commandButton.getMnemonic();
			BasicGraphicsUtils.drawString(g, titlePart2, mnemonicChar,
					bigLabel2Rect.x, bigLabel2Rect.y + fm.getAscent());
		}
		if (midLabelRect.getWidth() > 0) {
			int mnemonicChar = this.commandButton.getMnemonic();
			String str = this.commandButton.getTitle();
			str = FlamingoUtilities.clipString(g.getFontMetrics(),
					midLabelRect.width, str);
			int xDelta = 0;
			if (commandButton.getState() == ElementState.BIG_FIXED_LANDSCAPE) {
				int width = g.getFontMetrics().stringWidth(str);
				int availableWidth = c.getWidth() - ins.left - ins.right;
				xDelta = (availableWidth - width) / 2;
			}
			BasicGraphicsUtils.drawString(g, str, mnemonicChar, xDelta
					+ midLabelRect.x, midLabelRect.y + fm.getAscent());
		}
		g.setColor(FlamingoUtilities.getColor(Color.gray,
				"Label.disabledForeground"));
		if (midExtraLabelRect.getWidth() > 0) {
			BasicGraphicsUtils.drawString(g, this.commandButton.getExtraText(),
					-1, midExtraLabelRect.x, midExtraLabelRect.y
							+ fm.getAscent());
		}

		if (buttonKind.isHasAction() && buttonKind.isHasPopup()
				&& this.isPaintingSeparators() && (actionClickArea.width > 0)
				&& (popupClickArea.width > 0)) {
			switch (commandButton.getState()) {
			case CUSTOM:
			case BIG:
			case ORIG:
				this.paintButtonHorizontalSeparator(g, actionClickArea.height);
				break;
			default:
				this.paintButtonVerticalSeparator(g, actionClickArea.width);
			}
		}
	}

	protected void layoutButtonComponents(Graphics g, JComponent c,
			JCommandButton.CommandButtonKind buttonKind, Rectangle iconRect,
			Rectangle bigLabel1Rect, Rectangle bigLabel2Rect,
			Rectangle midLabelRect, Rectangle midExtraLabelRect,
			Rectangle actionArrowLabelRect) {
		int width = c.getWidth();
		int height = c.getHeight();

		// there are three cases:
		// 1. Big icon with label beneath - BIG state.
		// 2. Small icon with label on right - MEDIUM state.
		// 3. Small icon with no label - SMALL state.
		Insets ins = commandButton.getInsets();
		int x = ins.left;
		int y = ins.top;

		FontMetrics fm = g.getFontMetrics();
		int labelHeight = fm.getAscent() + fm.getDescent();

		if (buttonKind == JCommandButton.CommandButtonKind.ACTION_ONLY) {
			actionClickArea.x = 0;
			actionClickArea.y = 0;
			actionClickArea.width = width;
			actionClickArea.height = height;
		}
		if (buttonKind == JCommandButton.CommandButtonKind.POPUP_ONLY) {
			popupClickArea.x = 0;
			popupClickArea.y = 0;
			popupClickArea.width = width;
			popupClickArea.height = height;
		}

		JSeparator jsep = new JSeparator(JSeparator.VERTICAL);
		int layoutGap = getLayoutGap();

		ResizableIcon buttonIcon = this.commandButton.getIcon();
		switch (commandButton.getState()) {
		case CUSTOM:
		case BIG:
		case ORIG:
			// Big icon, 2-line text (with possibly empty second line) and
			// action arrow on the 2nd line.

			// special case - title is null
			if (commandButton.getTitle() == null) {
				y = ins.top
						+ (height - ins.top - ins.bottom - buttonIcon
								.getIconHeight()) / 2;
			}
			iconRect.x = (width - buttonIcon.getIconWidth()) / 2;
			iconRect.y = y;
			iconRect.width = buttonIcon.getIconWidth();
			iconRect.height = buttonIcon.getIconHeight();
			y += buttonIcon.getIconHeight();

			if (buttonKind.isHasAction() && buttonKind.isHasPopup()
					&& this.isPaintingSeparators()) {
				actionClickArea.x = 0;
				actionClickArea.y = 0;
				actionClickArea.width = width;
				actionClickArea.height = y + layoutGap;

				popupClickArea.x = 0;
				popupClickArea.y = y + layoutGap;
				popupClickArea.width = width;
				popupClickArea.height = height - y - layoutGap;
			}

			y += jsep.getPreferredSize().width;

			int labelWidth = (int) fm.getStringBounds(this.titlePart1, g)
					.getWidth();

			bigLabel1Rect.x = ins.left
					+ (width - labelWidth - ins.left - ins.right) / 2;
			bigLabel1Rect.y = y;
			bigLabel1Rect.width = labelWidth;
			bigLabel1Rect.height = labelHeight;

			y += labelHeight;

			labelWidth = (int) fm.getStringBounds(this.titlePart2, g)
					.getWidth()
					+ ((actionIcon != null) ? 2 * layoutGap
							+ actionIcon.getIconWidth() : 0);

			x = ins.left + (width - labelWidth - ins.left - ins.right) / 2;

			bigLabel2Rect.x = x;
			bigLabel2Rect.y = y;
			bigLabel2Rect.width = labelWidth;
			bigLabel2Rect.height = labelHeight;

			if (actionIcon != null) {
				x += 2 * layoutGap;
				x += fm.stringWidth(this.titlePart2);

				actionArrowLabelRect.x = x;
				actionArrowLabelRect.y = y
						+ (labelHeight - actionIcon.getIconHeight()) / 2;
				actionArrowLabelRect.width = actionIcon.getIconWidth();
				actionArrowLabelRect.height = actionIcon.getIconHeight();
			}

			break;

		case BIG_FIXED_LANDSCAPE:
			// Big icon, 1-line text below it

			// special case - title is null
			if (commandButton.getTitle() == null) {
				y = ins.top
						+ (height - ins.top - ins.bottom - buttonIcon
								.getIconHeight()) / 2;
			}
			iconRect.x = (width - buttonIcon.getIconWidth()) / 2;
			iconRect.y = y;
			iconRect.width = buttonIcon.getIconWidth();
			iconRect.height = buttonIcon.getIconHeight();
			y += buttonIcon.getIconHeight();

			y += jsep.getPreferredSize().width;

			midLabelRect.x = x;
			midLabelRect.y = y;
			midLabelRect.width = fm.stringWidth(this.commandButton.getTitle());
			if ((midLabelRect.x + midLabelRect.width) > (this.commandButton
					.getWidth() - ins.right)) {
				midLabelRect.width = this.commandButton.getWidth() - ins.right
						- x;
			}
			midLabelRect.height = fm.getAscent();

			break;

		case TILE:
			// small icon, 1-line text, 1-line extra text and action arrow
			iconRect.x = x;
			iconRect.y = (height - buttonIcon.getIconHeight()) / 2;
			iconRect.width = buttonIcon.getIconWidth();
			iconRect.height = buttonIcon.getIconHeight();

			x += commandButton.getIcon().getIconWidth();
			if (this.isPaintingSeparators()
					&& (buttonKind == JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_POPUP)) {
				actionClickArea.x = 0;
				actionClickArea.y = 0;
				actionClickArea.width = x + layoutGap;
				actionClickArea.height = height;

				popupClickArea.x = x + layoutGap;
				popupClickArea.y = 0;
				popupClickArea.width = width - x - layoutGap;
				popupClickArea.height = height;
			}
			x += 2 * layoutGap + jsep.getPreferredSize().width;

			midLabelRect.x = x;
			midLabelRect.y = (height - 2 * labelHeight - layoutGap) / 2;
			midLabelRect.width = fm.stringWidth(this.commandButton.getTitle());
			midLabelRect.height = fm.getAscent();

			String extraText = this.commandButton.getExtraText();
			midExtraLabelRect.x = x;
			midExtraLabelRect.y = midLabelRect.y + labelHeight + layoutGap;
			midExtraLabelRect.width = fm.stringWidth((extraText == null) ? ""
					: extraText);
			midExtraLabelRect.height = fm.getAscent();

			x += (int) Math.max(fm.getStringBounds(
					this.commandButton.getTitle(), g).getWidth(), fm
					.getStringBounds((extraText == null) ? "" : extraText, g)
					.getWidth());
			if (this.isPaintingSeparators()
					&& (buttonKind == JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_ACTION)) {
				actionClickArea.x = 0;
				actionClickArea.y = 0;
				actionClickArea.width = x + layoutGap;
				actionClickArea.height = height;

				popupClickArea.x = x + layoutGap;
				popupClickArea.y = 0;
				popupClickArea.width = width - x - layoutGap;
				popupClickArea.height = height;
			}
			x += 2 * layoutGap + jsep.getPreferredSize().width;

			if (actionIcon != null) {
				actionArrowLabelRect.x = x;
				actionArrowLabelRect.y = (height - actionIcon.getIconHeight()) / 2;
				actionArrowLabelRect.width = actionIcon.getIconWidth();
				actionArrowLabelRect.height = actionIcon.getIconHeight();
			}

			break;

		case MEDIUM:
			// small icon, 1-line text and action arrow
			iconRect.x = x;
			iconRect.y = (height - buttonIcon.getIconHeight()) / 2;
			iconRect.width = buttonIcon.getIconWidth();
			iconRect.height = buttonIcon.getIconHeight();

			x += commandButton.getIcon().getIconWidth();
			if (this.isPaintingSeparators()
					&& (buttonKind == JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_POPUP)) {
				actionClickArea.x = 0;
				actionClickArea.y = 0;
				actionClickArea.width = x + layoutGap;
				actionClickArea.height = height;

				popupClickArea.x = x + layoutGap;
				popupClickArea.y = 0;
				popupClickArea.width = width - x - layoutGap;
				popupClickArea.height = height;
			}
			x += 2 * layoutGap + jsep.getPreferredSize().width;

			midLabelRect.x = x;
			midLabelRect.y = (height - labelHeight) / 2;
			midLabelRect.width = fm.stringWidth(this.commandButton.getTitle());
			midLabelRect.height = fm.getAscent();

			x += (int) fm.getStringBounds(this.commandButton.getTitle(), g)
					.getWidth();
			if (this.isPaintingSeparators()
					&& (buttonKind == JCommandButton.CommandButtonKind.ACTION_AND_POPUP_MAIN_ACTION)) {
				actionClickArea.x = 0;
				actionClickArea.y = 0;
				actionClickArea.width = x + layoutGap;
				actionClickArea.height = height;

				popupClickArea.x = x + layoutGap;
				popupClickArea.y = 0;
				popupClickArea.width = width - x - layoutGap;
				popupClickArea.height = height;
			}
			x += 2 * layoutGap + jsep.getPreferredSize().width;

			if (actionIcon != null) {
				actionArrowLabelRect.x = x;
				actionArrowLabelRect.y = (height - actionIcon.getIconHeight()) / 2;
				actionArrowLabelRect.width = actionIcon.getIconWidth();
				actionArrowLabelRect.height = actionIcon.getIconHeight();
			}

			break;

		case SMALL:
			// small icon and action arrow
			iconRect.x = x;
			iconRect.y = (height - buttonIcon.getIconHeight()) / 2;
			iconRect.width = buttonIcon.getIconWidth();
			iconRect.height = buttonIcon.getIconHeight();

			x += commandButton.getIcon().getIconWidth();
			if (buttonKind.isHasAction() && buttonKind.isHasPopup()
					&& this.isPaintingSeparators()) {
				actionClickArea.x = 0;
				actionClickArea.y = 0;
				actionClickArea.width = x + layoutGap;
				actionClickArea.height = height;

				popupClickArea.x = x + layoutGap;
				popupClickArea.y = 0;
				popupClickArea.width = width - x - layoutGap;
				popupClickArea.height = height;
			}
			x += 2 * layoutGap + jsep.getPreferredSize().width;

			if (actionIcon != null) {
				actionArrowLabelRect.x = x;
				actionArrowLabelRect.y = (height - actionIcon.getIconHeight()) / 2;
				actionArrowLabelRect.width = actionIcon.getIconWidth();
				actionArrowLabelRect.height = actionIcon.getIconHeight();
			}

			break;
		}
		commandButton.putClientProperty("icon.bounds", iconRect);
	}

	/**
	 * Returns the current icon.
	 * 
	 * @return Current icon.
	 */
	protected Icon getIconToPaint() {
		return this.commandButton.getIcon();
	}

	/**
	 * Paints command button vertical separator.
	 * 
	 * @param graphics
	 *            Graphics context.
	 * @param separatorX
	 *            X coordinate of the separator.
	 */
	protected void paintButtonVerticalSeparator(Graphics graphics,
			int separatorX) {
		this.buttonRendererPane.setBounds(0, 0, this.commandButton.getWidth(),
				this.commandButton.getHeight());
		Graphics2D g2d = (Graphics2D) graphics.create();
		this.rendererSeparator.setOrientation(JSeparator.VERTICAL);
		this.buttonRendererPane.paintComponent(g2d, this.rendererSeparator,
				this.commandButton, separatorX, 2, 2, this.commandButton
						.getHeight() - 4, true);
		g2d.dispose();
	}

	/**
	 * Paints command button horizontal separator.
	 * 
	 * @param graphics
	 *            Graphics context.
	 * @param separatorY
	 *            Y coordinate of the separator.
	 */
	protected void paintButtonHorizontalSeparator(Graphics graphics,
			int separatorY) {
		this.buttonRendererPane.setBounds(0, 0, this.commandButton.getWidth(),
				this.commandButton.getHeight());
		Graphics2D g2d = (Graphics2D) graphics.create();
		this.rendererSeparator.setOrientation(JSeparator.HORIZONTAL);
		this.buttonRendererPane.paintComponent(g2d, this.rendererSeparator,
				this.commandButton, 2, separatorY, this.commandButton
						.getWidth() - 4, 2, true);
		g2d.dispose();
	}

	/**
	 * Paints command button background.
	 * 
	 * @param graphics
	 *            Graphics context.
	 * @param toFill
	 *            Rectangle for the background.
	 */
	protected void paintButtonBackground(Graphics graphics, Rectangle toFill) {
		this.buttonRendererPane.setBounds(toFill.x, toFill.y, toFill.width,
				toFill.height);
		ButtonModel model = this.rendererButton.getModel();
		model.setEnabled(this.commandButton.isEnabled());
		model.setSelected(this.commandButton.isSelected());
		model.setRollover(this.commandButton.getModel().isRollover());
		Graphics2D g2d = (Graphics2D) graphics.create();

		if (Boolean.TRUE.equals(this.commandButton
				.getClientProperty(EMULATE_SQUARE_BUTTON))) {
			this.buttonRendererPane.paintComponent(g2d, this.rendererButton,
					this.commandButton, toFill.x - toFill.width / 2, toFill.y
							- toFill.height / 2, 2 * toFill.width,
					2 * toFill.height, true);
			g2d.setColor(FlamingoUtilities.getColor(Color.gray,
					"TextField.inactiveForeground", "Button.disabledText",
					"ComboBox.disabledForeground"));
			g2d.drawRect(toFill.x, toFill.y, toFill.width - 1,
					toFill.height - 1);
		} else {
			this.buttonRendererPane.paintComponent(g2d, this.rendererButton,
					this.commandButton, toFill.x, toFill.y, toFill.width,
					toFill.height, true);
		}
		g2d.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jvnet.flamingo.common.ui.CommandButtonUI#updateState(org.jvnet.flamingo.common.ElementState,
	 *      boolean)
	 */
	@Override
	public void updateState(ElementState state, boolean toUpdateIcon) {
		int maxHeight = 0;
		switch (state) {
		case SMALL:
		case MEDIUM:
		case BIG:
		case BIG_FIXED_LANDSCAPE:
		case TILE:
			maxHeight = state.getPreferredSize();
			break;
		case ORIG:
			maxHeight = this.commandButton.getIcon().getIconHeight();
			break;
		}

		toTakeSavedDimension = !toUpdateIcon && (state != ElementState.CUSTOM);
		savedDimension = new Dimension(maxHeight, maxHeight);
		if (toUpdateIcon) {
			if (state != ElementState.CUSTOM) {
				this.commandButton.getIcon().setHeight(maxHeight);
			}
		}
	}

	protected void updateCustomDimension() {
		int dimension = this.commandButton.getCustomDimension();

		if (dimension > 0) {
			this.commandButton.getIcon().setDimension(
					new Dimension(dimension, dimension));
			this.commandButton.setState(ElementState.CUSTOM, true);

			this.commandButton.doLayout();
			this.commandButton.repaint();
		}
	}

	protected void updateActionIcon() {
		JCommandButton button = (JCommandButton) this.commandButton;
		if ((button.getPopupPanel() != null)
				|| button.getCommandButtonKind().isHasPopup()) {
			this.actionIcon = UIManager.getIcon("GalleryButton.expandIcon");
			if (this.actionIcon == null)
				this.actionIcon = FlamingoUtilities.getGalleryExpandIcon();
		} else {
			this.actionIcon = null;
		}
	}

	/**
	 * Paints the button icon.
	 * 
	 * @param g
	 *            Graphics context.
	 * @param iconRect
	 *            Icon rectangle.
	 */
	protected void paintButtonIcon(Graphics g, Rectangle iconRect) {
		Icon iconToPaint = this.getIconToPaint();
		if (iconRect != null) {
			iconToPaint
					.paintIcon(this.commandButton, g, iconRect.x, iconRect.y);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#getPreferredSize(javax.swing.JComponent)
	 */
	@Override
	public Dimension getPreferredSize(JComponent c) {
		return c.getLayout().preferredLayoutSize(c);
	}

	@Override
	public Rectangle getActionClickArea() {
		return this.actionClickArea;
	}

	@Override
	public Rectangle getPopupClickArea() {
		return this.popupClickArea;
	}

	protected int getLayoutGap() {
		return 2;
	}

	protected boolean isPaintingSeparators() {
		return (this.commandButton.getModel().isRollover());
	}

	protected boolean isPaintingBackground() {
		return (this.commandButton.isSelected()
				|| this.commandButton.getModel().isRollover() || !this.commandButton
				.isFlat());
	}
}
