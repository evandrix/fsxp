/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common.ui;

import java.awt.Rectangle;
import java.awt.event.FocusEvent;
import java.awt.event.MouseEvent;

import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonListener;

import org.jvnet.flamingo.common.AbstractCommandButton;
import org.jvnet.flamingo.common.PopupButtonModel;

public class BasicPopupButtonListener extends BasicButtonListener {
	public BasicPopupButtonListener(AbstractButton b) {
		super(b);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonListener#focusLost(java.awt.event.FocusEvent)
	 */
	@Override
	public void focusLost(FocusEvent e) {
		super.focusLost(e);

		AbstractCommandButton b = (AbstractCommandButton) e.getSource();
		ButtonModel model = b.getModel();
		if (model instanceof PopupButtonModel)
			((PopupButtonModel) model).setPopupPressed(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonListener#mousePressed(java.awt.event.MouseEvent)
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		if (SwingUtilities.isLeftMouseButton(e)) {
			AbstractCommandButton b = (AbstractCommandButton) e.getSource();

			if (b.contains(e.getX(), e.getY())) {
				ButtonModel model = b.getModel();
				if (!model.isEnabled()) {
					// Disabled buttons ignore all input...
					return;
				}
				if (!model.isArmed()) {
					// button not armed, should be
					model.setArmed(true);
				}

				CommandButtonUI ui = b.getUI();
				Rectangle actionRect = ui.getActionClickArea();
				Rectangle popupRect = ui.getPopupClickArea();

				if ((actionRect != null) && actionRect.contains(e.getPoint())) {
					model.setPressed(true);
				} else {
					if ((model instanceof PopupButtonModel)
							&& (popupRect != null)
							&& popupRect.contains(e.getPoint())) {
						((PopupButtonModel) model).setPopupPressed(true);
					}
				}

				model.setPressed(true);
				if (!b.hasFocus() && b.isRequestFocusEnabled()) {
					b.requestFocus();
				}
			}
		}
	};

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.basic.BasicButtonListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		if (SwingUtilities.isLeftMouseButton(e)) {
			AbstractCommandButton b = (AbstractCommandButton) e.getSource();
			ButtonModel model = b.getModel();

			CommandButtonUI ui = b.getUI();
			Rectangle actionRect = ui.getActionClickArea();
			Rectangle popupRect = ui.getPopupClickArea();

			if ((actionRect != null) && actionRect.contains(e.getPoint())) {
				model.setPressed(false);
			} else {
				if ((model instanceof PopupButtonModel) && (popupRect != null)
						&& popupRect.contains(e.getPoint())) {
					((PopupButtonModel) model).setPopupPressed(false);
				}
			}

			model.setArmed(false);
		}
	};

}
