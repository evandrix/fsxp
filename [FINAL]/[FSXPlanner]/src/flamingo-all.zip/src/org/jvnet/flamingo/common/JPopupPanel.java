/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common;

import java.awt.*;

import javax.swing.JPanel;
import javax.swing.UIManager;

import org.jvnet.flamingo.common.ui.BasicPopupPanelUI;
import org.jvnet.flamingo.common.ui.PopupPanelUI;

/**
 * Base class for popup-mode panels.
 * 
 * @author Kirill Grouchnikov
 */
public class JPopupPanel extends JPanel {
	/**
	 * @see #getUIClassID
	 */
	public static final String uiClassID = "PopupPanelUI";

	/**
	 * The main component of <code>this</code> popup panel. Can be
	 * <code>null</code>.
	 */
	protected Component component;

	/**
	 * Creates an empty popup gallery.
	 */
	public JPopupPanel() {
	}

	/**
	 * Creates popup gallery with the specified component.
	 * 
	 * @param component
	 *            The main component of the popup gallery.
	 * @param originalSize
	 *            The original dimension of the main component.
	 */
	public JPopupPanel(Component component, Dimension originalSize) {
		this();
		// System.out.println("Creating popup " + component);
		this.component = component;
		this.setLayout(new BorderLayout());
		this.add(component, BorderLayout.CENTER);
		// System.out.println("Popup dim is " + originalSize);
		this.setPreferredSize(originalSize);
		this.setSize(originalSize);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.JPanel#getUI()
	 */
	@Override
	public PopupPanelUI getUI() {
		return (PopupPanelUI) ui;
	}

	/**
	 * Sets the look and feel (L&F) object that renders this component.
	 * 
	 * @param ui
	 *            the PopupGalleryUI L&F object
	 */
	public void setUI(PopupPanelUI ui) {
		super.setUI(ui);
	}

	/**
	 * Removes the main component of <code>this</code> popup gallery.
	 * 
	 * @return The removed main component.
	 */
	public Component removeComponent() {
		this.remove(this.component);
		return this.component;
	}

	/**
	 * Returns the main component of <code>this</code> popup gallery.
	 * 
	 * @return The main component.
	 */
	public Component getComponent() {
		return this.component;
	}

	/**
	 * Checks whether <code>this</code> popup gallery has main component.
	 * 
	 * @return <code>true</code> if <code>this</code> popup gallery has main
	 *         component, <code>false</code> otherwise.
	 */
	public boolean isEmpty() {
		return (this.component == null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.JPanel#getUIClassID()
	 */
	@Override
	public String getUIClassID() {
		return uiClassID;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.JPanel#updateUI()
	 */
	@Override
	public void updateUI() {
		if (UIManager.get(getUIClassID()) != null) {
			setUI((PopupPanelUI) UIManager.getUI(this));
		} else {
			setUI(new BasicPopupPanelUI());
		}
	}
}
