/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.ribbon.ui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.*;

import org.jvnet.flamingo.common.*;
import org.jvnet.flamingo.common.icon.ResizableIcon;
import org.jvnet.flamingo.common.icon.StackIcon;
import org.jvnet.flamingo.common.ui.BasicCommandButtonUI;
import org.jvnet.flamingo.ribbon.JBandControlPanel;
import org.jvnet.flamingo.ribbon.JRibbonBand;
import org.jvnet.flamingo.utils.FlamingoUtilities;
import org.jvnet.flamingo.utils.RenderingUtils;

/**
 * Basic UI for ribbon band {@link JRibbonBand}.
 * 
 * @author Kirill Grouchnikov
 */
public class BasicRibbonBandUI extends RibbonBandUI {
	/**
	 * The associated ribbon band.
	 */
	protected JRibbonBand ribbonBand;

	/**
	 * The button for collapsed state.
	 */
	protected JCommandButton collapsedButton;

	/**
	 * The current collapse kind.
	 */
	protected RibbonBandCollapseKind currentFitCollapse;

	/**
	 * The band expand button. Is visible when the
	 * {@link JRibbonBand#getExpandActionListener()} of the associated ribbon
	 * band is not <code>null</code>.
	 */
	protected AbstractButton expandButton;

	/**
	 * Indication whether the mouse pointer is over the associated ribbon band.
	 */
	protected boolean isUnderMouse;

	/**
	 * Mouse listener on the associated ribbon band.
	 */
	protected MouseListener mouseListener;

	/**
	 * Action listener on the expand button.
	 */
	protected ActionListener expandButtonActionListener;

	/**
	 * Used to provide a LAF-consistent appearance under core LAFs.
	 */
	protected CellRendererPane buttonRendererPane;

	/**
	 * Used to provide a LAF-consistent appearance under core LAFs.
	 */
	protected JButton rendererButton;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicRibbonBandUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#installUI(javax.swing.JComponent)
	 */
	@Override
	public void installUI(JComponent c) {
		this.ribbonBand = (JRibbonBand) c;
		installDefaults();
		installComponents();
		installListeners();
		c.setLayout(createLayoutManager());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		c.setLayout(null);
		uninstallListeners();
		uninstallDefaults();
		uninstallComponents();
	}

	/**
	 * Installs default parameters on the associated ribbon band.
	 */
	protected void installDefaults() {
		Color bg = this.ribbonBand.getBackground();
		if (bg == null || bg instanceof UIResource) {
			this.ribbonBand.setBackground(FlamingoUtilities.getColor(
					Color.lightGray, "RibbonBand.background",
					"Panel.background"));
		}

		Border b = this.ribbonBand.getBorder();
		if (b == null || b instanceof UIResource) {
			Border toSet = UIManager.getBorder("RibbonBand.border");
			if (toSet == null)
				toSet = new BorderUIResource(new RoundBorder(FlamingoUtilities
						.getColor(Color.gray, "TextField.inactiveForeground",
								"Button.disabledText",
								"ComboBox.disabledForeground"), new Insets(2,
						2, 2, 2)));
			this.ribbonBand.setBorder(toSet);
		}
		this.buttonRendererPane = new CellRendererPane();
		this.ribbonBand.add(buttonRendererPane);
		this.rendererButton = new JButton("");
	}

	/**
	 * Installs subcomponents on the associated ribbon band.
	 */
	protected void installComponents() {
		StackIcon icon = new StackIcon(this.ribbonBand.getIcon(), 0.25);
		this.collapsedButton = new JCommandButton(this.ribbonBand.getTitle(),
				icon);
		this.collapsedButton.setState(ElementState.BIG, true);
		this.ribbonBand.add(this.collapsedButton);

		if (this.ribbonBand.getExpandActionListener() != null) {
			this.expandButton = this.createExpandButton();
			this.ribbonBand.add(this.expandButton);
		}
	}

	/**
	 * Creates the expand button for the associated ribbon band.
	 * 
	 * @return Expand button for the associated ribbon band.
	 */
	protected AbstractButton createExpandButton() {
		ResizableIcon icon = FlamingoUtilities.getRibbonBandExpandIcon();
		JCommandButton result = new JCommandButton(null, icon);
		result.setFlat(true);
		result.putClientProperty(BasicCommandButtonUI.EMULATE_SQUARE_BUTTON,
				Boolean.TRUE);
		result.setPreferredSize(new Dimension(
				result.getIcon().getIconWidth() + 4, result.getIcon()
						.getIconHeight() + 4));
		return result;
	}

	/**
	 * Installs listeners on the associated ribbon band.
	 */
	protected void installListeners() {
		this.mouseListener = new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				isUnderMouse = true;
				ribbonBand.repaint();
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// check if mouse is still on one of the child components
				if (ribbonBand.contains(e.getPoint()))
					return;

				isUnderMouse = false;
				ribbonBand.repaint();
			}
		};
		this.ribbonBand.addMouseListener(this.mouseListener);

		if (this.expandButton != null) {
			this.expandButton.addActionListener(this.ribbonBand
					.getExpandActionListener());

			this.expandButtonActionListener = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							isUnderMouse = false;
							if (ribbonBand != null)
								ribbonBand.repaint();
						}
					});
				}
			};
			this.expandButton
					.addActionListener(this.expandButtonActionListener);
		}
	}

	/**
	 * Uninstalls default parameters from the associated ribbon band.
	 */
	protected void uninstallDefaults() {
		this.ribbonBand.remove(this.buttonRendererPane);
		this.buttonRendererPane = null;

		LookAndFeel.uninstallBorder(this.ribbonBand);
	}

	/**
	 * Uninstalls components from the associated ribbon band.
	 */
	protected void uninstallComponents() {
		if (this.collapsedButton.isVisible()) {
			// restore the control panel to the ribbon band.
			JPopupPanel popupGallery = collapsedButton.getPopupPanel();
			if (popupGallery != null) {
				JRibbonBand bandFromPopup = (JRibbonBand) collapsedButton
						.getPopupPanel().removeComponent();
				ribbonBand.setControlPanel(bandFromPopup.getControlPanel());
				collapsedButton.setPopupPanel(null);
			}
		}

		this.ribbonBand.remove(this.collapsedButton);
		this.collapsedButton = null;

		if (this.expandButton != null)
			this.ribbonBand.remove(this.expandButton);

		this.expandButton = null;
		this.ribbonBand = null;
	}

	/**
	 * Uninstalls listeners from the associated ribbon band.
	 */
	protected void uninstallListeners() {
		this.ribbonBand.removeMouseListener(this.mouseListener);
		this.mouseListener = null;

		if (this.expandButton != null) {
			this.expandButton
					.removeActionListener(this.expandButtonActionListener);
			this.expandButtonActionListener = null;
			this.expandButton.removeActionListener(this.ribbonBand
					.getExpandActionListener());
		}
	}

	/**
	 * Invoked by <code>installUI</code> to create a layout manager object to
	 * manage the {@link JButtonStrip}.
	 * 
	 * @return a layout manager object
	 */
	protected LayoutManager createLayoutManager() {
		return new RibbonBandLayout();
	}

	/**
	 * Layout for the ribbon band.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class RibbonBandLayout implements LayoutManager {

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container c) {
			Insets ins = c.getInsets();
			JBandControlPanel controlPanel = ribbonBand.getControlPanel();
			boolean useCollapsedButton = (controlPanel == null)
					|| (!controlPanel.isVisible());
			int width = useCollapsedButton ? collapsedButton.getPreferredSize().width
					: controlPanel.getPreferredSize().width;
			int height = useCollapsedButton ? collapsedButton
					.getPreferredSize().height : controlPanel
					.getPreferredSize().height
					+ getBandTitleHeight();

			// Preferred height of the ribbon band is:
			// 1. Insets on top and bottom
			// 2. Preferred height of the control panel
			// 3. Preferred height of the band title panel
			return new Dimension(width + 2 + ins.left + ins.right, height
					+ ins.top + ins.bottom);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container c) {
			Insets ins = c.getInsets();
			JBandControlPanel controlPanel = ribbonBand.getControlPanel();
			boolean useCollapsedButton = (controlPanel == null)
					|| (!controlPanel.isVisible());
			int width = useCollapsedButton ? collapsedButton.getMinimumSize().width
					: controlPanel.getMinimumSize().width;
			int height = useCollapsedButton ? collapsedButton.getMinimumSize().height
					: controlPanel.getMinimumSize().height
							+ getBandTitleHeight();

			// Preferred height of the ribbon band is:
			// 1. Insets on top and bottom
			// 2. Preferred height of the control panel
			// 3. Preferred height of the band title panel
			return new Dimension(width + 2 + ins.left + ins.right, height
					+ ins.top + ins.bottom);

		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container c) {
			if (!c.isVisible())
				return;
			Insets ins = c.getInsets();

			int availableHeight = c.getHeight() - ins.top - ins.bottom;
			// Compute the best collapse kind
			RibbonBandCollapseKind bestFitCollapse = RibbonBandCollapseKind
					.getSortedKinds().getLast();
			for (RibbonBandCollapseKind collapseKind : RibbonBandCollapseKind
					.getSortedKinds()) {
				int collapsedWidth = getPreferredWidth(collapseKind,
						availableHeight);
				if (collapsedWidth <= c.getWidth()) {
					bestFitCollapse = collapseKind;
					break;
				}
			}

			currentFitCollapse = bestFitCollapse;
			if (bestFitCollapse == RibbonBandCollapseKind.ICON) {
				collapsedButton.setVisible(true);
				int w = collapsedButton.getPreferredSize().width;
				// System.out.println("Width for collapsed of '"
				// + ribbonBand.getTitle() + "' is " + w);
				collapsedButton.setBounds((c.getWidth() - w) / 2, ins.top, w, c
						.getHeight()
						- ins.top - ins.bottom);

				if (collapsedButton.getPopupPanel() == null) {
					JRibbonBand popupBand = new JRibbonBand(ribbonBand
							.getTitle(), ribbonBand.getIcon(), ribbonBand
							.getExpandActionListener());
					popupBand.setControlPanel(ribbonBand.getControlPanel());
					Dimension size = new Dimension(4 + getPreferredWidth(
							RibbonBandCollapseKind.NONE, availableHeight),
							4
									+ ribbonBand.getControlPanel()
											.getPreferredSize().height
									+ getBandTitleHeight());
					collapsedButton.setPopupPanel(new JPopupPanel(popupBand,
							size));
					collapsedButton
							.setCommandButtonKind(JCommandButton.CommandButtonKind.POPUP_ONLY);
					// collapsedButton.setGallery(new JPopupGallery(ribbonBand
					// .getControlPanel(), size));
					ribbonBand.setControlPanel(null);
				}

				if (expandButton != null)
					expandButton.setBounds(0, 0, 0, 0);

				return;
			}

			if (collapsedButton.isVisible()) {
				// was icon and now is normal band - have to restore the
				// control panel
				JPopupPanel popupGallery = collapsedButton.getPopupPanel();
				if (popupGallery != null) {
					JRibbonBand bandFromPopup = (JRibbonBand) collapsedButton
							.getPopupPanel().removeComponent();
					ribbonBand.setControlPanel(bandFromPopup.getControlPanel());
					// JBandControlPanel panelFromPopup = (JBandControlPanel)
					// collapsedButton
					// .getGallery().removeComponent();
					// ribbonBand.setControlPanel(panelFromPopup);
					collapsedButton.setPopupPanel(null);
				}
			}
			collapsedButton.setVisible(false);

			JBandControlPanel controlPanel = ribbonBand.getControlPanel();
			controlPanel.setVisible(true);
			controlPanel.setBounds(ins.left, ins.top, c.getWidth() - ins.left
					- ins.right, c.getHeight() - getBandTitleHeight() - ins.top
					- ins.bottom + 1);
			controlPanel.doLayout();

			if (expandButton != null) {
				int ebpw = expandButton.getPreferredSize().width;
				int ebph = expandButton.getPreferredSize().height;

				int expandButtonBottomY = c.getHeight()
						- (getBandTitleHeight() - ebph) / 2;

				expandButton.setBounds(c.getWidth() - ins.right - ebpw,
						expandButtonBottomY - ebph, ebpw, ebph);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		Graphics2D g2d = (Graphics2D) g.create();
		RenderingUtils.installDesktopHints(g2d);
		super.update(g2d, c);
		g2d.dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void paint(Graphics g, JComponent c) {
		Graphics2D graphics = (Graphics2D) g.create();

		Insets ins = ribbonBand.getInsets();

		this.paintBandBackground(graphics, new Rectangle(0, 0, c.getWidth(), c
				.getHeight()));

		if (this.currentFitCollapse != RibbonBandCollapseKind.ICON) {
			String title = ribbonBand.getTitle();
			int titleHeight = getBandTitleHeight();

			int bandTitleTopY = c.getHeight() - titleHeight;

			this.paintBandTitleBackground(graphics, new Rectangle(0,
					bandTitleTopY, c.getWidth(), titleHeight), title);
			int titleWidth = (expandButton != null) ? expandButton.getX() - 2
					* ins.right - 2 * ins.left : c.getWidth() - 2 * ins.left
					- 2 * ins.right;
			this.paintBandTitle(graphics, new Rectangle(2 * ins.left,
					bandTitleTopY, titleWidth, titleHeight), title);
		}

		graphics.dispose();
	}

	/**
	 * Paints band title pane.
	 * 
	 * @param g
	 *            Graphics context.
	 * @param titleRectangle
	 *            Rectangle for the title pane.
	 * @param title
	 *            Title string.
	 */
	protected void paintBandTitle(Graphics g, Rectangle titleRectangle,
			String title) {

		Graphics2D graphics = (Graphics2D) g.create();
		graphics.setFont(FlamingoUtilities.getFont("Ribbon.font",
				"Button.font", "Panel.font"));

		FontMetrics fm = graphics.getFontMetrics();
		int y = titleRectangle.y - 2 + (titleRectangle.height + fm.getAscent())
				/ 2;

		int currLength = (int) fm.getStringBounds(title, g).getWidth();
		String titleToPaint = title;
		while (currLength > titleRectangle.width) {
			title = title.substring(0, title.length() - 1);
			titleToPaint = title + "...";
			currLength = (int) fm.getStringBounds(titleToPaint, g).getWidth();
		}

		int x = titleRectangle.x + (titleRectangle.width - currLength) / 2;
		graphics.setColor(this.ribbonBand.getForeground());
		graphics.drawString(titleToPaint, x, y);
		graphics.dispose();
	}

	/**
	 * Paints band title pane.
	 * 
	 * @param g
	 *            Graphics context.
	 * @param titleRectangle
	 *            Rectangle for the title pane.
	 * @param title
	 *            Title string.
	 */
	protected void paintBandTitleBackground(Graphics g,
			Rectangle titleRectangle, String title) {

		this.buttonRendererPane.setBounds(titleRectangle.x, titleRectangle.y,
				titleRectangle.width, titleRectangle.height);
		ButtonModel model = this.rendererButton.getModel();
		model.setRollover(this.isUnderMouse);
		Graphics2D g2d = (Graphics2D) g.create();

		if (!this.isUnderMouse)
			g2d.setComposite(AlphaComposite.SrcOver.derive(0.7f));
		g2d.clipRect(titleRectangle.x, titleRectangle.y, titleRectangle.width,
				titleRectangle.height);
		this.buttonRendererPane.paintComponent(g2d, this.rendererButton,
				this.ribbonBand, titleRectangle.x - 20, titleRectangle.y
						- titleRectangle.height / 2, titleRectangle.width + 40,
				2 * titleRectangle.height, true);

		g2d.setColor(FlamingoUtilities.getColor(Color.gray,
				"TextField.inactiveForeground", "Button.disabledText",
				"ComboBox.disabledForeground"));
		g2d.drawLine(titleRectangle.x, titleRectangle.y, titleRectangle.x
				+ titleRectangle.width - 1, titleRectangle.y);

		g2d.dispose();
	}

	/**
	 * Paints band background.
	 * 
	 * @param graphics
	 *            Graphics context.
	 * @param toFill
	 *            Rectangle for the background.
	 */
	protected void paintBandBackground(Graphics graphics, Rectangle toFill) {
		graphics.setColor(ribbonBand.getBackground());
		graphics.fillRect(toFill.x, toFill.y, toFill.width, toFill.height);
	}

	/**
	 * Gets preferred width of <code>this</code> ribbon band in the specified
	 * collapse kind.
	 * 
	 * @param collapseKind
	 *            Collapse kind.
	 * @return Preferred width of <code>this</code> ribbon band in the
	 *         specified collapse kind.
	 */
	public int getPreferredWidth(RibbonBandCollapseKind collapseKind,
			int availableHeight) {
		if (collapseKind == RibbonBandCollapseKind.ICON)
			return this.collapsedButton.getPreferredSize().width + 2;

		JBandControlPanel controlPanel = ribbonBand.getControlPanel();
		if (controlPanel == null) {
			JPopupPanel gallery = collapsedButton.getPopupPanel();
			// controlPanel = (JBandControlPanel) gallery.getComponent();
			JRibbonBand popupBand = (JRibbonBand) gallery.getComponent();
			BasicRibbonBandUI popupBandUi = (BasicRibbonBandUI) popupBand
					.getUI();
			return popupBandUi.getPreferredWidth(collapseKind, availableHeight);
		}
		BasicBandControlPanelUI baseUI = (BasicBandControlPanelUI) controlPanel
				.getUI();
		Insets ins = this.ribbonBand.getInsets();
		int result = baseUI.getPreferredWidth(collapseKind, availableHeight
				- getBandTitleHeight() - ins.top - ins.bottom)
				+ ins.left + ins.right;
		// System.out.println(this.ribbonBand.getTitle() + ":" + collapseKind +
		// ":" + result);
		return result;
	}

	/**
	 * Returns indication whether the mouse is over the associated ribbon band.
	 * 
	 * @return <code>true</code> if the mouse is over the associated ribbon
	 *         band, <code>false</code> otherwise.
	 */
	public boolean isUnderMouse() {
		return isUnderMouse;
	}

	public RibbonBandCollapseKind getCurrentFitCollapse() {
		return currentFitCollapse;
	}

	public int getBandTitleHeight() {
		Font font = FlamingoUtilities.getFont("Ribbon.font", "Button.font",
				"Panel.font");
		if (font == null) {
			// Nimbus - is that you?
			font = new JLabel().getFont();
		}
		int result = font.getSize() + 5;
		if (result % 2 == 0)
			result++;
		return result;
	}
}
