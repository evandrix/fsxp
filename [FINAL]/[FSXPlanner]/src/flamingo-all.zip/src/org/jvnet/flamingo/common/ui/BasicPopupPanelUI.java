/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common.ui;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.*;

import org.jvnet.flamingo.common.JPopupPanel;
import org.jvnet.flamingo.common.PopupPanelManager;
import org.jvnet.flamingo.common.PopupPanelManager.PopupEvent;
import org.jvnet.flamingo.utils.FlamingoUtilities;

/**
 * Basic UI for popup panel {@link JPopupPanel}.
 * 
 * @author Kirill Grouchnikov
 */
public class BasicPopupPanelUI extends PopupPanelUI {
	protected JPopupPanel popupPanel;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicPopupPanelUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#installUI(javax.swing.JComponent)
	 */
	@Override
	public void installUI(JComponent c) {
		this.popupPanel = (JPopupPanel) c;
		super.installUI(this.popupPanel);
		installDefaults();
		installListeners();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		uninstallListeners();
		uninstallDefaults();
		super.uninstallUI(this.popupPanel);
	}

	/**
	 * Installs default settings for the associated popup gallery.
	 */
	protected void installDefaults() {
		Color bg = this.popupPanel.getBackground();
		if (bg == null || bg instanceof UIResource) {
			this.popupPanel.setBackground(FlamingoUtilities.getColor(
					Color.lightGray, "PopupPanel.background",
					"Panel.background"));
		}

		Border b = this.popupPanel.getBorder();
		if (b == null || b instanceof UIResource) {
			Border toSet = UIManager.getBorder("PopupPanel.border");
			if (toSet == null)
				toSet = new BorderUIResource.CompoundBorderUIResource(
						new LineBorder(FlamingoUtilities.getColor(Color.gray,
								"TextField.inactiveForeground",
								"Button.disabledText",
								"ComboBox.disabledForeground")),
						new EmptyBorder(1, 1, 1, 1));
			this.popupPanel.setBorder(toSet);
		}
		LookAndFeel.installProperty(this.popupPanel, "opaque", Boolean.TRUE);
	}

	protected void installListeners() {
		initiliazeGlobalListeners();
	}

	/**
	 * Uninstalls default settings from the associated popup panel.
	 */
	protected void uninstallDefaults() {
		LookAndFeel.uninstallBorder(this.popupPanel);
	}

	protected void uninstallListeners() {
	}

	protected static PopupPanelManager.PopupListener popupPanelManagerListener;

	protected static final String MARKER = "flamingo.internal.popupPanel.marker";

	protected static synchronized void initiliazeGlobalListeners() {
		if (popupPanelManagerListener != null) {
			return;
		}

		popupPanelManagerListener = new PopupPanelManagerListener();
		PopupPanelManager.defaultManager().addPopupListener(
				popupPanelManagerListener);

		new MouseGrabber();
	}

	protected static class PopupPanelManagerListener implements
			PopupPanelManager.PopupListener {
		private ActionMap newActionMap;
		private InputMap newInputMap;

		List<PopupPanelManager.PopupInfo> lastPathSelected;
		private JRootPane tracedRootPane;

		public PopupPanelManagerListener() {
			PopupPanelManager popupPanelManager = PopupPanelManager
					.defaultManager();
			this.lastPathSelected = popupPanelManager.getShownPath();
			if (this.lastPathSelected.size() != 0) {
				traceRootPane(this.lastPathSelected);
			}
		}

		@Override
		public void popupHidden(PopupEvent event) {
			PopupPanelManager msm = PopupPanelManager.defaultManager();
			List<PopupPanelManager.PopupInfo> p = msm.getShownPath();

			if (lastPathSelected.size() != 0 && p.size() == 0) {
				untraceRootPane();
			}

			lastPathSelected = p;
		}

		private void untraceRootPane() {
			if (this.tracedRootPane != null) {
				removeUIActionMap(this.tracedRootPane, this.newActionMap);
				removeUIInputMap(this.tracedRootPane, this.newInputMap);
			}
		}

		@Override
		public void popupShown(PopupEvent event) {
			PopupPanelManager msm = PopupPanelManager.defaultManager();
			List<PopupPanelManager.PopupInfo> p = msm.getShownPath();

			if (lastPathSelected.size() == 0 && p.size() != 0) {
				traceRootPane(p);
			}

			lastPathSelected = p;
		}

		private void traceRootPane(List<PopupPanelManager.PopupInfo> shownPath) {
			JComponent originator = shownPath.get(0).getOriginalComponent();
			this.tracedRootPane = SwingUtilities.getRootPane(originator);

			if (this.tracedRootPane != null) {
				newInputMap = new ComponentInputMapUIResource(tracedRootPane);
				newInputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
						"hidePopupPanel");

				newActionMap = new ActionMapUIResource();
				newActionMap.put("hidePopupPanel", new AbstractAction() {
					@Override
					public void actionPerformed(ActionEvent e) {
						PopupPanelManager.defaultManager().hideLastPopup();
					}
				});

				addUIInputMap(tracedRootPane, newInputMap);
				addUIActionMap(tracedRootPane, newActionMap);
			}
		}

		void addUIInputMap(JComponent c, InputMap map) {
			InputMap lastNonUI = null;
			InputMap parent = c.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);

			while (parent != null && !(parent instanceof UIResource)) {
				lastNonUI = parent;
				parent = parent.getParent();
			}

			if (lastNonUI == null) {
				c.setInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW, map);
			} else {
				lastNonUI.setParent(map);
			}
			map.setParent(parent);
		}

		void addUIActionMap(JComponent c, ActionMap map) {
			ActionMap lastNonUI = null;
			ActionMap parent = c.getActionMap();

			while (parent != null && !(parent instanceof UIResource)) {
				lastNonUI = parent;
				parent = parent.getParent();
			}

			if (lastNonUI == null) {
				c.setActionMap(map);
			} else {
				lastNonUI.setParent(map);
			}
			map.setParent(parent);
		}

		void removeUIInputMap(JComponent c, InputMap map) {
			InputMap im = null;
			InputMap parent = c.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);

			while (parent != null) {
				if (parent == map) {
					if (im == null) {
						c.setInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW, map
								.getParent());
					} else {
						im.setParent(map.getParent());
					}
					break;
				}
				im = parent;
				parent = parent.getParent();
			}
		}

		void removeUIActionMap(JComponent c, ActionMap map) {
			ActionMap im = null;
			ActionMap parent = c.getActionMap();

			while (parent != null) {
				if (parent == map) {
					if (im == null) {
						c.setActionMap(map.getParent());
					} else {
						im.setParent(map.getParent());
					}
					break;
				}
				im = parent;
				parent = parent.getParent();
			}
		}
	}

	protected static class MouseGrabber implements
			PopupPanelManager.PopupListener, AWTEventListener,
			ComponentListener, WindowListener {

		Window grabbedWindow;
		List<PopupPanelManager.PopupInfo> lastPathSelected;

		public MouseGrabber() {
			PopupPanelManager popupPanelManager = PopupPanelManager
					.defaultManager();
			popupPanelManager.addPopupListener(this);
			this.lastPathSelected = popupPanelManager.getShownPath();
			if (this.lastPathSelected.size() != 0) {
				grabWindow(this.lastPathSelected);
			}
		}

		void uninstall() {
			PopupPanelManager.defaultManager().removePopupListener(this);
			ungrabWindow();
		}

		void grabWindow(List<PopupPanelManager.PopupInfo> shownPath) {
			// A grab needs to be added
			final Toolkit tk = Toolkit.getDefaultToolkit();
			java.security.AccessController
					.doPrivileged(new java.security.PrivilegedAction() {
						public Object run() {
							tk.addAWTEventListener(MouseGrabber.this,
									AWTEvent.MOUSE_EVENT_MASK
											| AWTEvent.MOUSE_MOTION_EVENT_MASK
											| AWTEvent.MOUSE_WHEEL_EVENT_MASK
											| AWTEvent.WINDOW_EVENT_MASK);
							return null;
						}
					});

			Component invoker = shownPath.get(0).getOriginalComponent();
			grabbedWindow = invoker instanceof Window ? (Window) invoker
					: SwingUtilities.getWindowAncestor(invoker);
			if (grabbedWindow != null) {
				grabbedWindow.addComponentListener(this);
				grabbedWindow.addWindowListener(this);
			}
		}

		void ungrabWindow() {
			final Toolkit tk = Toolkit.getDefaultToolkit();
			// The grab should be removed
			java.security.AccessController
					.doPrivileged(new java.security.PrivilegedAction() {
						public Object run() {
							tk.removeAWTEventListener(MouseGrabber.this);
							return null;
						}
					});
			if (grabbedWindow != null) {
				grabbedWindow.removeComponentListener(this);
				grabbedWindow.removeWindowListener(this);
				grabbedWindow = null;
			}
		}

		@Override
		public void popupShown(PopupEvent event) {
			PopupPanelManager msm = PopupPanelManager.defaultManager();
			List<PopupPanelManager.PopupInfo> p = msm.getShownPath();

			if (lastPathSelected.size() == 0 && p.size() != 0) {
				grabWindow(p);
			}

			lastPathSelected = p;
		}

		@Override
		public void popupHidden(PopupEvent event) {
			PopupPanelManager msm = PopupPanelManager.defaultManager();
			List<PopupPanelManager.PopupInfo> p = msm.getShownPath();

			if (lastPathSelected.size() != 0 && p.size() == 0) {
				ungrabWindow();
			}

			lastPathSelected = p;
		}

		public void eventDispatched(AWTEvent ev) {
			if (!(ev instanceof MouseEvent)) {
				// We are interested in MouseEvents only
				return;
			}
			MouseEvent me = (MouseEvent) ev;
			Component src = me.getComponent();
			switch (me.getID()) {
			case MouseEvent.MOUSE_PRESSED:
				if (isInPopupPanel(src)) {
					return;
				}
				PopupPanelManager.defaultManager().hidePopups(src);
				// Consume the event so that normal processing stops.
				me.consume();
				break;

			case MouseEvent.MOUSE_WHEEL:
				if (isInPopupPanel(src)) {
					return;
				}
				PopupPanelManager.defaultManager().hidePopups(src);
				break;
			}
		}

		boolean isInPopupPanel(Component src) {
			for (Component c = src; c != null; c = c.getParent()) {
				if (c instanceof Applet || c instanceof Window) {
					break;
				} else if (c instanceof JPopupPanel) {
					return true;
				}
			}
			return false;
		}

		public void componentResized(ComponentEvent e) {
			PopupPanelManager.defaultManager().hidePopups(null);
		}

		public void componentMoved(ComponentEvent e) {
			PopupPanelManager.defaultManager().hidePopups(null);
		}

		public void componentShown(ComponentEvent e) {
			PopupPanelManager.defaultManager().hidePopups(null);
		}

		public void componentHidden(ComponentEvent e) {
			PopupPanelManager.defaultManager().hidePopups(null);
		}

		public void windowClosing(WindowEvent e) {
			PopupPanelManager.defaultManager().hidePopups(null);
		}

		public void windowClosed(WindowEvent e) {
			PopupPanelManager.defaultManager().hidePopups(null);
		}

		public void windowIconified(WindowEvent e) {
			PopupPanelManager.defaultManager().hidePopups(null);
		}

		public void windowDeactivated(WindowEvent e) {
			PopupPanelManager.defaultManager().hidePopups(null);
		}

		public void windowOpened(WindowEvent e) {
		}

		public void windowDeiconified(WindowEvent e) {
		}

		public void windowActivated(WindowEvent e) {
		}
	}
}
