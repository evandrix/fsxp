/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.ribbon;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

import javax.swing.*;

import org.jvnet.flamingo.ribbon.ui.BasicRibbonUI;
import org.jvnet.flamingo.ribbon.ui.RibbonUI;

/**
 * Ribbon component.
 * 
 * @author Kirill Grouchnikov
 */
public class JRibbon extends JComponent {
	/**
	 * The list of all {@link RibbonTask} tasks.
	 */
	private ArrayList<RibbonTask> tasks;

	/**
	 * All regular components (to the left of task tabs).
	 */
	private ArrayList<Component> regularComponents;

	/**
	 * Toggle buttons of task tabs.
	 */
	private ArrayList<JToggleTabButton> taskToggleButtons;

	/**
	 * Bands of the currently shown task.
	 */
	private ArrayList<JRibbonBand> bands;

	/**
	 * Currently selected (shown) task).
	 */
	private RibbonTask currentlySelectedTask;

	/**
	 * Help task (will be displayed in the right part of the ribbon if set).
	 */
	private RibbonTask helpTask;

	/**
	 * Button group for task toggle buttons.
	 */
	private ButtonGroup taskToggleButtonGroup;

	/**
	 * The alignment kind of <code>this</code> ribbon. Should be one of
	 * {@link SwingConstants#LEFT}, {@link SwingConstants#CENTER} or
	 * {@link SwingConstants#RIGHT}.
	 */
	private int alignment;

	/**
	 * Map of toggle buttons of all tasks.
	 */
	private Map<RibbonTask, JToggleTabButton> taskButtons;

	/**
	 * The UI class ID string.
	 */
	public static final String uiClassID = "RibbonUI";

	/**
	 * Simple constructor.
	 */
	public JRibbon() {
		this.tasks = new ArrayList<RibbonTask>();
		this.regularComponents = new ArrayList<Component>();
		this.taskToggleButtons = new ArrayList<JToggleTabButton>();
		this.bands = new ArrayList<JRibbonBand>();
		this.currentlySelectedTask = null;
		this.taskToggleButtonGroup = new ButtonGroup();
		this.alignment = SwingConstants.LEFT;
		this.taskButtons = new HashMap<RibbonTask, JToggleTabButton>();

		updateUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Container#add(java.awt.Component, int)
	 */
	@Override
	public Component add(Component comp, int index) {
		throw new UnsupportedOperationException();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Container#add(java.awt.Component, java.lang.Object, int)
	 */
	@Override
	public void add(Component comp, Object constraints, int index) {
		throw new UnsupportedOperationException();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Container#add(java.awt.Component, java.lang.Object)
	 */
	@Override
	public void add(Component comp, Object constraints) {
		throw new UnsupportedOperationException();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Container#add(java.awt.Component)
	 */
	@Override
	public Component add(Component comp) {
		this.regularComponents.add(comp);
		return super.add(comp);
	}

	/**
	 * Adds new component without putting it into the {@link #regularComponents}
	 * list.
	 * 
	 * @param comp
	 *            Component to add.
	 * @return Added component.
	 */
	private Component addInternal(Component comp) {
		return super.add(comp);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Container#remove(java.awt.Component)
	 */
	@Override
	public void remove(Component comp) {
		this.regularComponents.remove(comp);
		super.remove(comp);
	}

	/**
	 * Adds new task.
	 * 
	 * @param name
	 *            Task name.
	 * @param task
	 *            Task object.
	 * @return The toggle button for the new task.
	 */
	public JToggleButton addTask(String name, final RibbonTask task) {
		if (this.helpTask != null) {
			this.tasks.add(this.tasks.size() - 1, task);
		} else {
			this.tasks.add(task);
		}
		JToggleTabButton taskToggleButton = new JToggleTabButton(name);
		this.taskToggleButtonGroup.add(taskToggleButton);
		if (this.helpTask != null) {
			this.taskToggleButtons.add(this.taskToggleButtons.size() - 1,
					taskToggleButton);
		} else {
			this.taskToggleButtons.add(taskToggleButton);
		}
		this.addInternal(taskToggleButton);

		this.taskButtons.put(task, taskToggleButton);

		if (this.tasks.size() == 1) {
			this.setSelectedTask(task);
			taskToggleButton.setSelected(true);
		}
		taskToggleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						setSelectedTask(task);
					}
				});
			}
		});

		for (int i = 0; i < task.getBandCount(); i++) {
			JRibbonBand panel = task.getBand(i);
			this.addInternal(panel);
			if (this.tasks.size() > 1)
				panel.setVisible(false);
		}

		return taskToggleButton;
	}

	/**
	 * Removes a task.
	 * 
	 * @param task
	 *            Task to remove.
	 */
	public void removeTask(RibbonTask task) {
		int index = this.tasks.indexOf(task);
		this.removeTask(index);
	}

	/**
	 * Removes task at specified index.
	 * 
	 * @param index
	 *            Index of the task to remove.
	 */
	public void removeTask(int index) {
		if (index >= 0) {
			RibbonTask toRemove = this.tasks.get(index);
			this.tasks.remove(toRemove);
			if (this.currentlySelectedTask == toRemove) {
				index--;
				if (index < 0)
					index++;
				if (index < this.tasks.size())
					this.setSelectedTask(this.tasks.get(index));
			}
			if (this.helpTask == toRemove)
				this.helpTask = null;

			JToggleTabButton taskToggleButton = this.taskButtons.get(toRemove);
			this.taskToggleButtons.remove(taskToggleButton);
			this.taskToggleButtons.remove(taskToggleButton);
			this.taskToggleButtonGroup.remove(taskToggleButton);
			this.remove(taskToggleButton);
		}
	}

	/**
	 * Returns the number of tasks in <code>this</code> ribbon.
	 * 
	 * @return Number of tasks in <code>this</code> ribbon.
	 */
	public int getTaskCount() {
		return this.tasks.size();
	}

	/**
	 * Retrieves task at specified index.
	 * 
	 * @param index
	 *            Task index.
	 * @return Task that matches the specified index.
	 */
	public RibbonTask getTask(int index) {
		return this.tasks.get(index);
	}

	/**
	 * Selects the specified task.
	 * 
	 * @param task
	 *            Task to select.
	 */
	public void setSelectedTask(RibbonTask task) {
		for (JRibbonBand panel : this.bands) {
			// this.remove(panel);
			panel.setVisible(false);
		}
		this.bands.clear();

		for (int i = 0; i < task.getBandCount(); i++) {
			JRibbonBand panel = task.getBand(i);
			// this.addInternal(panel);
			panel.setVisible(true);
			this.bands.add(panel);
		}

		this.currentlySelectedTask = task;
		this.taskButtons.get(task).setSelected(true);

		this.revalidate();
		this.repaint();
	}

	/**
	 * Selects the specified task.
	 * 
	 * @param taskIndex
	 *            Task index to select.
	 */
	public void setSelectedTask(int taskIndex) {
		int taskCount = this.getTaskCount();
		if ((taskIndex < 0) || (taskIndex >= taskCount))
			return;

		this.setSelectedTask(this.tasks.get(taskIndex));
	}

	/**
	 * Returns the index of currently selected task.
	 * 
	 * @return The index of currently selected task.
	 */
	public int getSelectedTaskIndex() {
		return this.tasks.indexOf(this.currentlySelectedTask);
	}

	/**
	 * Returns the currently selected task.
	 * 
	 * @return The currently selected task.
	 */
	public RibbonTask getSelectedTask() {
		return this.currentlySelectedTask;
	}

	/**
	 * Sets the new UI delegate.
	 * 
	 * @param ui
	 *            New UI delegate.
	 */
	public void setUI(RibbonUI ui) {
		super.setUI(ui);
	}

	/**
	 * Resets the UI property to a value from the current look and feel.
	 * 
	 * @see JComponent#updateUI
	 */
	@Override
	public void updateUI() {
		if (UIManager.get(getUIClassID()) != null) {
			setUI((RibbonUI) UIManager.getUI(this));
		} else {
			setUI(new BasicRibbonUI());
		}
	}

	/**
	 * Returns the UI object which implements the L&F for this component.
	 * 
	 * @return a <code>RibbonUI</code> object
	 * @see #setUI
	 */
	public RibbonUI getUI() {
		return (RibbonUI) ui;
	}

	/**
	 * Returns the name of the UI class that implements the L&F for this
	 * component.
	 * 
	 * @return the string "RibbonUI"
	 * @see JComponent#getUIClassID
	 * @see UIDefaults#getUI
	 */
	@Override
	public String getUIClassID() {
		return uiClassID;
	}

	/**
	 * Gets all regular components of <code>this</code> ribbon.
	 * 
	 * @return All regular components of <code>this</code> ribbon.
	 */
	public ArrayList<Component> getRegularComponents() {
		return regularComponents;
	}

	/**
	 * Gets all bands of currently selected task of <code>this</code> ribbon.
	 * 
	 * @return All bands of currently selected task of <code>this</code>
	 *         ribbon.
	 */
	public ArrayList<JRibbonBand> getBands() {
		return bands;
	}

	/**
	 * Gets all task toggle buttons of <code>this</code> ribbon.
	 * 
	 * @return All task toggle buttons of <code>this</code> ribbon.
	 */
	public ArrayList<JToggleTabButton> getTaskToggleButtons() {
		return taskToggleButtons;
	}

	/**
	 * Returns the alignment of <code>this</code> ribbon.
	 * 
	 * @return Alignment of <code>this</code> ribbon. Is one of
	 *         {@link SwingConstants#LEFT}, {@link SwingConstants#CENTER} or
	 *         {@link SwingConstants#RIGHT}.
	 */
	public int getAlignment() {
		return alignment;
	}

	/**
	 * Sets the new alignment of <code>this</code> ribbon. In addition,
	 * repaints the ribbon.
	 * 
	 * @param alignment
	 *            New alignment of <code>this</code> ribbon. Should be one of
	 *            {@link SwingConstants#LEFT}, {@link SwingConstants#CENTER} or
	 *            {@link SwingConstants#RIGHT}.
	 */
	public void setAlignment(int alignment) {
		this.alignment = alignment;
		this.doLayout();
		this.repaint();
	}

	/**
	 * Returns the help task of <code>this</code> button.
	 * 
	 * @return Help task of <code>this</code> button.
	 */
	public RibbonTask getHelpTask() {
		return helpTask;
	}

	/**
	 * Sets an existing ribbon task to be the new help task.
	 * 
	 * @param helpTask
	 *            New help task.
	 * @throws IllegalArgumentException
	 *             If there is no such task in <code>this</code> ribbon.
	 */
	public void setHelpTask(RibbonTask helpTask) {
		if (!this.tasks.contains(helpTask))
			throw new IllegalArgumentException("No such task in ribbon");
		this.helpTask = helpTask;

		// move to the last index
		int prevIndex = this.tasks.indexOf(this.helpTask);
		this.tasks.remove(this.helpTask);
		this.tasks.add(this.helpTask);

		JToggleTabButton matchingTabButton = this.taskToggleButtons
				.get(prevIndex);
		this.taskToggleButtons.remove(matchingTabButton);
		this.taskToggleButtons.add(matchingTabButton);
	}

	/**
	 * Returns the toggle button of the help task of <code>this</code> ribbon.
	 * 
	 * @return Toggle button of the help task of <code>this</code> ribbon.
	 */
	public JToggleTabButton getHelpTaskButton() {
		if (this.helpTask == null)
			return null;
		else
			return this.taskButtons.get(this.helpTask);
	}
}
