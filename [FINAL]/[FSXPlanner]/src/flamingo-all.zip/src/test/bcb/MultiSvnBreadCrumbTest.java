/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package test.bcb;

import java.awt.BorderLayout;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;

import org.jvnet.flamingo.bcb.*;
import org.jvnet.flamingo.bcb.core.BreadcrumbMultiSvnSelector;
import org.jvnet.flamingo.common.*;
import org.jvnet.flamingo.common.icon.ResizableIcon;

import test.common.ExplorerFileViewPanel;

public class MultiSvnBreadCrumbTest extends JFrame {
	private ExplorerFileViewPanel<String> filePanel;

	private BreadcrumbMultiSvnSelector bar;

	public static class SvnFolderListModel extends AbstractListModel {
		private ArrayList<String> entries = new ArrayList<String>();

		public void add(String entry) {
			entries.add(entry);
		}

		public void sort() {
			Collections.sort(entries);
		}

		public Object getElementAt(int index) {
			return entries.get(index);
		}

		public int getSize() {
			return entries.size();
		}
	}

	public MultiSvnBreadCrumbTest() {
		super("BreadCrumb test");

		this.bar = new BreadcrumbMultiSvnSelector();
		this.bar
				.addSvnRepositoryInfo(new BreadcrumbMultiSvnSelector.SvnRepositoryInfo(
						"SVNKit", "http://svn.svnkit.com/repos/svnkit",
						"anonymous", "anonymous"));
		this.bar
				.addSvnRepositoryInfo(new BreadcrumbMultiSvnSelector.SvnRepositoryInfo(
						"KDE", "svn://anonsvn.kde.org/home/kde/trunk",
						"anonymous", "anonymous"));
		this.bar
				.addSvnRepositoryInfo(new BreadcrumbMultiSvnSelector.SvnRepositoryInfo(
						"Apache", "http://svn.apache.org/repos/asf",
						"anonymous", "anonymous"));
		this.bar.setThrowsExceptions(true);
		this.bar.addExceptionHandler(new BreadcrumbBarExceptionHandler() {
			public void onException(Throwable t) {
				MessageListDialog.showMessageDialog(
						MultiSvnBreadCrumbTest.this, "Error", t);
			}
		});

		// "http://svn.svnkit.com/repos/svnkit", "anonymous", "anonymous");
		bar.addListener(new BreadcrumbBarListener<String>() {
			public void breadcrumbBarEvent(
					final BreadcrumbBarEvent<String> event) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						if (event.getType() == BreadcrumbBarEvent.PATH_CHANGED) {
							final BreadcrumbItem<String>[] newPath = (BreadcrumbItem<String>[]) event
									.getNewValue();
							System.out.println("New path is ");
							for (BreadcrumbItem<String> item : newPath) {
								System.out.println("\t" + item.getValue());
							}

							if (newPath.length > 0) {
								SwingWorker<List<StringValuePair<String>>, Void> worker = new SwingWorker<List<StringValuePair<String>>, Void>() {
									@Override
									protected List<StringValuePair<String>> doInBackground() {
										return bar.getCallback().getLeafs(
												newPath);
									}

									@Override
									protected void done() {
										try {
											List<StringValuePair<String>> leafs = get();
											filePanel.setFolder(leafs);
										} catch (Exception exc) {
										}
									}
								};
								worker.execute();
							}
							return;
						}
					}
				});
			}
		});

		JToolBar toolbar = new JToolBar();
		toolbar.setLayout(new BorderLayout(3, 0));
		toolbar.setFloatable(false);

		toolbar.add(bar, BorderLayout.CENTER);

		this.setLayout(new BorderLayout());
		this.add(toolbar, BorderLayout.NORTH);

		this.filePanel = new ExplorerFileViewPanel<String>(bar,
				ElementState.MEDIUM, null) {
			@Override
			protected void configureCommandButton(
					org.jvnet.flamingo.common.AbstractFileViewPanel.Leaf leaf,
					JCommandButton button, ResizableIcon icon) {
				long size = (Long) leaf.getLeafProp("size");
				Date date = (Date) leaf.getLeafProp("date");
				SimpleDateFormat sdf = new SimpleDateFormat("d MMM yyyy");
				button.setExtraText(size + " bytes, " + sdf.format(date));
			}
		};
		this.filePanel.setUseNativeIcons(true);
		JScrollPane fileListScrollPane = new JScrollPane(this.filePanel);
		this.add(fileListScrollPane, BorderLayout.CENTER);
	}

	public static void main(String... args) {
		try {
			System.setProperty("java.net.useSystemProxies", "true");
		} catch (SecurityException e) {
		}
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				MultiSvnBreadCrumbTest test = new MultiSvnBreadCrumbTest();
				test.setSize(550, 385);
				test.setLocationRelativeTo(null);
				test.setVisible(true);
				test.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
	}
}
