/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.common;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;

import javax.swing.*;
import javax.swing.event.EventListenerList;

import org.jvnet.flamingo.common.icon.ResizableIcon;
import org.jvnet.flamingo.common.ui.BasicCommandButtonUI;
import org.jvnet.flamingo.common.ui.CommandButtonUI;

/**
 * Command button.
 * 
 * @author Kirill Grouchnikov
 */
public class JCommandButton extends AbstractCommandButton {
	/**
	 * The UI class ID string.
	 */
	public static final String uiClassID = "CommandButtonUI";

	/**
	 * Associated popup panel. May be <code>null</code>.
	 */
	protected JPopupPanel popupPanel;

	protected CommandButtonKind commandButtonKind;

	protected PopupActionListener popupActionListener = null;

	public static enum CommandButtonKind {
		ACTION_ONLY(true, false),

		POPUP_ONLY(false, true),

		ACTION_AND_POPUP_MAIN_ACTION(true, true),

		ACTION_AND_POPUP_MAIN_POPUP(true, true);

		private boolean hasAction;

		private boolean hasPopup;

		private CommandButtonKind(boolean hasAction, boolean hasPopup) {
			this.hasAction = hasAction;
			this.hasPopup = hasPopup;
		}

		public boolean isHasAction() {
			return hasAction;
		}

		public boolean isHasPopup() {
			return hasPopup;
		}
	}

	private static class DefaultPopupButtonModel extends DefaultButtonModel
			implements PopupButtonModel {
		private JCommandButton commandButton;

		public final static int POPUP_PRESSED = 1 << 8;

		public DefaultPopupButtonModel(JCommandButton commandButton) {
			super();
			this.commandButton = commandButton;
		}

		public void addPopupActionListener(PopupActionListener l) {
			listenerList.add(PopupActionListener.class, l);
		}

		public void removePopupActionListener(PopupActionListener l) {
			listenerList.remove(PopupActionListener.class, l);
		}

		/**
		 * Notifies all listeners that have registered interest for notification
		 * on this event type.
		 * 
		 * @param e
		 *            the <code>ActionEvent</code> to deliver to listeners
		 * @see EventListenerList
		 */
		protected void firePopupActionPerformed(ActionEvent e) {
			// Guaranteed to return a non-null array
			Object[] listeners = listenerList.getListenerList();
			// Process the listeners last to first, notifying
			// those that are interested in this event
			for (int i = listeners.length - 2; i >= 0; i -= 2) {
				if (listeners[i] == PopupActionListener.class) {
					((PopupActionListener) listeners[i + 1]).actionPerformed(e);
				}
			}
		}

		public boolean isPopupPressed() {
			return (stateMask & POPUP_PRESSED) != 0;
		}

		@Override
		public void setPopupPressed(boolean b) {
			if ((isPopupPressed() == b) || !isEnabled()) {
				return;
			}

			if (b) {
				stateMask |= POPUP_PRESSED;
			} else {
				stateMask &= ~POPUP_PRESSED;
			}

			if (!isPopupPressed() && isArmed()) {
				int modifiers = 0;
				AWTEvent currentEvent = EventQueue.getCurrentEvent();
				if (currentEvent instanceof InputEvent) {
					modifiers = ((InputEvent) currentEvent).getModifiers();
				} else if (currentEvent instanceof ActionEvent) {
					modifiers = ((ActionEvent) currentEvent).getModifiers();
				}
				firePopupActionPerformed(new ActionEvent(this,
						ActionEvent.ACTION_PERFORMED, getActionCommand(),
						EventQueue.getMostRecentEventTime(), modifiers));
			}

			fireStateChanged();
		}
	}

	/**
	 * Creates a new command button.
	 * 
	 * @param title
	 *            Button title. May contain any number of words.
	 * @param icon
	 *            Button icon.
	 */
	public JCommandButton(String title, ResizableIcon icon) {
		super(title, icon);
		this.setModel(new DefaultPopupButtonModel(this));
		this.commandButtonKind = CommandButtonKind.ACTION_ONLY;
		this.state = ElementState.ORIG;
		this.updateUI();
	}

	public CommandButtonKind getCommandButtonKind() {
		return this.commandButtonKind;
	}

	/**
	 * Sets the kind for this button.
	 * 
	 * @param commandButtonKind
	 *            The new button kind.
	 */
	public void setCommandButtonKind(CommandButtonKind commandButtonKind) {
		CommandButtonKind old = this.commandButtonKind;
		this.commandButtonKind = commandButtonKind;
		if (old != this.commandButtonKind) {
			firePropertyChange("commandButtonKind", old, this.commandButtonKind);
		}
	}

	/**
	 * Resets the UI property to a value from the current look and feel.
	 * 
	 * @see JComponent#updateUI
	 */
	@Override
	public void updateUI() {
		if (UIManager.get(getUIClassID()) != null) {
			setUI((CommandButtonUI) UIManager.getUI(this));
		} else {
			setUI(new BasicCommandButtonUI());
		}
		if (this.popupPanel != null) {
			this.popupPanel.updateUI();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.JComponent#getUIClassID()
	 */
	@Override
	public String getUIClassID() {
		return uiClassID;
	}

	/**
	 * Returns the associated popup panel.
	 * 
	 * @return The associated popup panel.
	 */
	public JPopupPanel getPopupPanel() {
		return popupPanel;
	}

	/**
	 * Sets new popup panel for <code>this</code> button.
	 * 
	 * @param panel
	 *            New popup panel for <code>this</code> button.
	 */
	public void setPopupPanel(JPopupPanel panel) {
		JPopupPanel old = this.popupPanel;
		this.popupPanel = panel;
		if (old != this.popupPanel) {
			firePropertyChange("popupGallery", old, this.popupPanel);
		}
	}

	/**
	 * Adds a popup action listener to this button. All registered listeners
	 * will be called when the "popup area" of this button is activated,
	 * providing a convenient way to populate the popup menu without creating,
	 * positioning or tracking the lifecycle of the popup menu itself. Note that
	 * if {@link #getPopupPanel()} returns a non-<code>null</code> result,
	 * the popup click will show that panel and not invoke any of the registered
	 * listeners.
	 * 
	 * @param l
	 *            The popup action listener to be added
	 */
	public void addPopupActionListener(PopupMenuListener l) {
		listenerList.add(PopupMenuListener.class, l);
	}

	/**
	 * Removes an <code>PopupActionListener</code> from the button. If the
	 * listener is the currently set <code>Action</code> for the button, then
	 * the <code>Action</code> is set to <code>null</code>.
	 * 
	 * @param l
	 *            the listener to be removed
	 */
	public void removePopupActionListener(PopupMenuListener l) {
		if ((l != null) && (getAction() == l)) {
			setAction(null);
		} else {
			listenerList.remove(PopupMenuListener.class, l);
		}
	}

	protected PopupActionListener createPopupActionListener() {
		return new PopupActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// dismiss all the popups that are currently showing
				// up until <this> button.
				PopupPanelManager.defaultManager().hidePopups(
						JCommandButton.this);

				// check if the command button has an associated popup
				// gallery
				final JPopupPanel gallery = getPopupPanel();
				if (gallery != null) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							PopupFactory popupFactory = PopupFactory
									.getSharedInstance();

							if ((JCommandButton.this == null)
									|| (gallery == null) || gallery.isEmpty())
								return;
							int x = getLocationOnScreen().x;
							int y = getLocationOnScreen().y + getSize().height;
							// System.out.println("Showing "
							// + jgb.gallery.getComponent());

							// make sure that the popup gallery stays in bounds
							Rectangle scrBounds = getGraphicsConfiguration()
									.getBounds();
							int pw = gallery.getPreferredSize().width;
							if ((x + pw) > (scrBounds.x + scrBounds.width)) {
								x = scrBounds.x + scrBounds.width - pw;
							}
							int ph = gallery.getPreferredSize().height;
							if ((y + ph) > (scrBounds.y + scrBounds.height)) {
								y = scrBounds.y + scrBounds.height - ph;
							}

							// get the popup and show it
							Popup popup = popupFactory.getPopup(
									JCommandButton.this, gallery, x, y);
							PopupPanelManager.defaultManager().addPopup(
									JCommandButton.this, popup, gallery);
							// popupButtons.put(popup, jgb);
							// popupGalleries.put(popup, jgb.gallery);
						}
					});
					return;
				}

				// otherwise - create a popup menu and ask all the listeners
				// to populate it
				JPopupMenu popupMenu = new JPopupMenu();
				// Guaranteed to return a non-null array
				Object[] listeners = listenerList.getListenerList();
				// Process the listeners last to first, notifying
				// those that are interested in this event
				for (int i = listeners.length - 2; i >= 0; i -= 2) {
					if (listeners[i] == PopupMenuListener.class) {
						((PopupMenuListener) listeners[i + 1])
								.menuAboutToShow(popupMenu);
					}
				}
				popupMenu.show(JCommandButton.this, 0, getHeight());
				// popupMenu.addPopupMenuListener(new PopupMenuListener() {
				// @Override
				// public void popupMenuCanceled(PopupMenuEvent e) {
				// System.out.println("Cancelled");
				// }
				//
				// @Override
				// public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
				// System.out.println("Will become invisible");
				// }
				//
				// @Override
				// public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
				// }
				// });
			}
		};
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.AbstractButton#setModel(javax.swing.ButtonModel)
	 */
	@Override
	public void setModel(ButtonModel newModel) {
		DefaultPopupButtonModel newPopupModel = (DefaultPopupButtonModel) newModel;
		PopupButtonModel oldModel = (DefaultPopupButtonModel) getModel();

		if (oldModel != null) {
			oldModel.removePopupActionListener(this.popupActionListener);
			this.popupActionListener = null;
		}

		if (newModel != null) {
			this.popupActionListener = createPopupActionListener();
			newPopupModel.addPopupActionListener(this.popupActionListener);
		}
		super.setModel(newModel);
	}

}
