/*
 * Copyright (c) 2005-2008 Flamingo Kirill Grouchnikov. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of Flamingo Kirill Grouchnikov nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */
package org.jvnet.flamingo.ribbon.ui;

import java.awt.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.*;

import org.jvnet.flamingo.common.ElementState;
import org.jvnet.flamingo.common.JCommandButton;
import org.jvnet.flamingo.common.icon.EmptyResizableIcon;
import org.jvnet.flamingo.common.ui.CommandButtonUI;
import org.jvnet.flamingo.ribbon.JBandControlPanel;
import org.jvnet.flamingo.ribbon.RibbonElementPriority;
import org.jvnet.flamingo.utils.FlamingoUtilities;

/**
 * Basic UI for control panel of ribbon band {@link JBandControlPanel}.
 * 
 * @author Kirill Grouchnikov
 */
public class BasicBandControlPanelUI extends BandControlPanelUI {
	/**
	 * The associated control panel.
	 */
	protected JBandControlPanel controlPanel;

	/**
	 * The current collapse kind.
	 */
	protected RibbonBandCollapseKind currentFitCollapse;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#createUI(javax.swing.JComponent)
	 */
	public static ComponentUI createUI(JComponent c) {
		return new BasicBandControlPanelUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#installUI(javax.swing.JComponent)
	 */
	@Override
	public void installUI(JComponent c) {
		this.controlPanel = (JBandControlPanel) c;
		installDefaults();
		installComponents();
		installListeners();

		c.setLayout(createLayoutManager());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#uninstallUI(javax.swing.JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		uninstallListeners();
		uninstallComponents();
		uninstallDefaults();

		c.setLayout(null);
		this.controlPanel = null;
	}

	/**
	 * Installs listeners on the associated control panel of a ribbon band.
	 */
	protected void installListeners() {
	}

	/**
	 * Uninstalls listeners from the associated control panel of a ribbon band.
	 */
	protected void uninstallListeners() {
	}

	/**
	 * Installs components on the associated control panel of a ribbon band.
	 */
	protected void installComponents() {
	}

	/**
	 * Uninstalls components from the associated control panel of a ribbon band.
	 */
	protected void uninstallComponents() {
	}

	/**
	 * Installs default parameters on the associated control panel of a ribbon
	 * band.
	 */
	protected void installDefaults() {
		Color bg = this.controlPanel.getBackground();
		if (bg == null || bg instanceof UIResource) {
			this.controlPanel.setBackground(FlamingoUtilities.getColor(
					Color.lightGray, "ControlPanel.background",
					"Panel.background"));
		}

		Border b = this.controlPanel.getBorder();
		if (b == null || b instanceof UIResource) {
			Border toSet = UIManager.getBorder("ControlPanel.border");
			if (toSet == null)
				new BorderUIResource.EmptyBorderUIResource(1, 2, 1, 2);
			this.controlPanel.setBorder(toSet);
		}
	}

	/**
	 * Uninstalls default parameters from the associated control panel.
	 */
	protected void uninstallDefaults() {
		LookAndFeel.uninstallBorder(this.controlPanel);
	}

	/**
	 * Invoked by <code>installUI</code> to create a layout manager object to
	 * manage the {@link JBandControlPanel}.
	 * 
	 * @return a layout manager object
	 */
	protected LayoutManager createLayoutManager() {
		return new ControlPanelLayout();
	}

	/**
	 * Layout for the control panel of ribbon band.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class ControlPanelLayout implements LayoutManager {

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#addLayoutComponent(java.lang.String,
		 *      java.awt.Component)
		 */
		public void addLayoutComponent(String name, Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#removeLayoutComponent(java.awt.Component)
		 */
		public void removeLayoutComponent(Component c) {
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#preferredLayoutSize(java.awt.Container)
		 */
		public Dimension preferredLayoutSize(Container c) {
			// The height of ribbon band control panel is
			// computed based on the preferred height of a command
			// button in BIG state.
			JCommandButton dummyButton = new JCommandButton("Dummy",
					new EmptyResizableIcon(16));
			dummyButton.setState(ElementState.BIG, true);
			int buttonHeight = dummyButton.getPreferredSize().height;

			Insets ins = c.getInsets();
			return new Dimension(c.getWidth(), buttonHeight + ins.top
					+ ins.bottom);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#minimumLayoutSize(java.awt.Container)
		 */
		public Dimension minimumLayoutSize(Container c) {
			return this.preferredLayoutSize(c);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.awt.LayoutManager#layoutContainer(java.awt.Container)
		 */
		public void layoutContainer(Container c) {
			// need place for border
			Insets ins = c.getInsets();
			int x = ins.left;
			int gap = getLayoutGap();
			int availableHeight = c.getHeight() - ins.top - ins.bottom;

			// Compute the best collapse kind
			RibbonBandCollapseKind bestFitCollapse = RibbonBandCollapseKind
					.getSortedKinds().getLast();
			for (RibbonBandCollapseKind collapseKind : RibbonBandCollapseKind
					.getSortedKinds()) {
				int collapsedWidth = getPreferredWidth(collapseKind,
						availableHeight);
				if (collapsedWidth <= c.getWidth()) {
					bestFitCollapse = collapseKind;
					break;
				}
			}

			currentFitCollapse = bestFitCollapse;
			if (bestFitCollapse == RibbonBandCollapseKind.ICON) {
				return;
			}

			// Now the galleries
			java.util.List<JRibbonGallery> topGalleries = controlPanel
					.getRibbonGalleries(RibbonElementPriority.TOP);
			java.util.List<JRibbonGallery> mediumGalleries = controlPanel
					.getRibbonGalleries(RibbonElementPriority.MEDIUM);
			java.util.List<JRibbonGallery> lowGalleries = controlPanel
					.getRibbonGalleries(RibbonElementPriority.LOW);

			switch (bestFitCollapse) {
			case NONE:
				// put all galleries to top
				for (JRibbonGallery top : topGalleries)
					top.setState(ElementState.BIG);
				for (JRibbonGallery med : mediumGalleries)
					med.setState(ElementState.BIG);
				for (JRibbonGallery low : lowGalleries)
					low.setState(ElementState.BIG);
				break;

			case LOW_TO_MID:
				// put all low priority galleries to medium list
				for (JRibbonGallery top : topGalleries)
					top.setState(ElementState.BIG);
				for (JRibbonGallery med : mediumGalleries)
					med.setState(ElementState.BIG);
				for (JRibbonGallery low : lowGalleries)
					low.setState(ElementState.MEDIUM);
				break;

			case MID_TO_MID:
				// put all low / medium priority galleries to medium list
				for (JRibbonGallery top : topGalleries)
					top.setState(ElementState.BIG);
				for (JRibbonGallery med : mediumGalleries)
					med.setState(ElementState.MEDIUM);
				for (JRibbonGallery low : lowGalleries)
					low.setState(ElementState.MEDIUM);
				break;

			case LOW_TO_LOW:
				// put all low priority galleries to low list
				// put all medium priority buttons to medium list
				for (JRibbonGallery top : topGalleries)
					top.setState(ElementState.BIG);
				for (JRibbonGallery med : mediumGalleries)
					med.setState(ElementState.MEDIUM);
				for (JRibbonGallery low : lowGalleries)
					low.setState(ElementState.SMALL);
				break;

			case MID_TO_LOW:
				// put all medium / low priority galleries to low list
				for (JRibbonGallery top : topGalleries)
					top.setState(ElementState.BIG);
				for (JRibbonGallery med : mediumGalleries)
					med.setState(ElementState.SMALL);
				for (JRibbonGallery low : lowGalleries)
					low.setState(ElementState.SMALL);
				break;

			case HIGH_TO_MID:
				// put all medium / low priority galleries to low list
				// put all top priority galleries to medium list
				for (JRibbonGallery top : topGalleries)
					top.setState(ElementState.MEDIUM);
				for (JRibbonGallery med : mediumGalleries)
					med.setState(ElementState.SMALL);
				for (JRibbonGallery low : lowGalleries)
					low.setState(ElementState.SMALL);
				break;

			case HIGH_TO_LOW:
				// put all galleries to low list
				for (JRibbonGallery top : topGalleries)
					top.setState(ElementState.SMALL);
				for (JRibbonGallery med : mediumGalleries)
					med.setState(ElementState.SMALL);
				for (JRibbonGallery low : lowGalleries)
					low.setState(ElementState.SMALL);
				break;
			}

			Map<ElementState, java.util.List<JRibbonGallery>> galleryStateMap = new HashMap<ElementState, java.util.List<JRibbonGallery>>();
			galleryStateMap.put(ElementState.BIG,
					new LinkedList<JRibbonGallery>());
			galleryStateMap.put(ElementState.MEDIUM,
					new LinkedList<JRibbonGallery>());
			galleryStateMap.put(ElementState.SMALL,
					new LinkedList<JRibbonGallery>());

			for (JRibbonGallery top : topGalleries)
				galleryStateMap.get(top.getState()).add(top);
			for (JRibbonGallery med : mediumGalleries)
				galleryStateMap.get(med.getState()).add(med);
			for (JRibbonGallery low : lowGalleries)
				galleryStateMap.get(low.getState()).add(low);

			// bigs
			for (JRibbonGallery big : galleryStateMap.get(ElementState.BIG)) {
				int pw = big.getPreferredWidth(ElementState.BIG,
						availableHeight);
				big.setBounds(x, ins.top, pw, availableHeight);
				//System.out.println("BIG " + big.getBounds());
				x += pw;
				x += gap;
			}

			// mediums
			for (JRibbonGallery med : galleryStateMap.get(ElementState.MEDIUM)) {
				int pw = med.getPreferredWidth(ElementState.MEDIUM,
						availableHeight);
				med.setBounds(x, ins.top, pw, availableHeight);
				//System.out.println("MED " + med.getBounds());
				x += pw;
				x += gap;
			}

			// smalls
			for (JRibbonGallery small : galleryStateMap.get(ElementState.SMALL)) {
				int pw = small.getPreferredWidth(ElementState.SMALL,
						availableHeight);
				small.setBounds(x, ins.top, pw, availableHeight);
				//System.out.println("SMALL " + small.getBounds());
				x += pw;
				x += gap;
			}

			// Regular panels
			for (JPanel panel : controlPanel.getPanels()) {
				int pw = panel.getPreferredSize().width;
				panel.setBounds(x, ins.top, pw, availableHeight);
				x += pw;
				x += gap;
			}

			// And finally the ribbon buttons
			java.util.List<JCommandButton> topButtons = controlPanel
					.getRibbonButtons(RibbonElementPriority.TOP);
			java.util.List<JCommandButton> mediumButtons = controlPanel
					.getRibbonButtons(RibbonElementPriority.MEDIUM);
			java.util.List<JCommandButton> lowButtons = controlPanel
					.getRibbonButtons(RibbonElementPriority.LOW);

//			System.out.println("BEST FIT : " + bestFitCollapse + ", pref "
//					+ getPreferredWidth(bestFitCollapse, availableHeight));

			switch (bestFitCollapse) {
			case NONE:
				// put all buttons to top
				for (JCommandButton top : topButtons)
					top.setState(ElementState.BIG, true);
				for (JCommandButton med : mediumButtons)
					med.setState(ElementState.BIG, true);
				for (JCommandButton low : lowButtons)
					low.setState(ElementState.BIG, true);
				break;

			case LOW_TO_MID:
				// put all low priority buttons to medium list
				for (JCommandButton top : topButtons)
					top.setState(ElementState.BIG, true);
				for (JCommandButton med : mediumButtons)
					med.setState(ElementState.BIG, true);
				for (JCommandButton low : lowButtons)
					low.setState(ElementState.MEDIUM, true);
				break;

			case MID_TO_MID:
				// put all low / medium priority buttons to medium list
				for (JCommandButton top : topButtons)
					top.setState(ElementState.BIG, true);
				for (JCommandButton med : mediumButtons)
					med.setState(ElementState.MEDIUM, true);
				for (JCommandButton low : lowButtons)
					low.setState(ElementState.MEDIUM, true);
				break;

			case LOW_TO_LOW:
				// put all low priority buttons to low list
				// put all medium priority buttons to medium list
				for (JCommandButton top : topButtons)
					top.setState(ElementState.BIG, true);
				for (JCommandButton med : mediumButtons)
					med.setState(ElementState.MEDIUM, true);
				for (JCommandButton low : lowButtons)
					low.setState(ElementState.SMALL, true);
				break;

			case MID_TO_LOW:
				// put all medium / low priority buttons to low list
				for (JCommandButton top : topButtons)
					top.setState(ElementState.BIG, true);
				for (JCommandButton med : mediumButtons)
					med.setState(ElementState.SMALL, true);
				for (JCommandButton low : lowButtons)
					low.setState(ElementState.SMALL, true);
				break;

			case HIGH_TO_MID:
				// put all medium / low priority buttons to low list
				// put all top priority buttons to medium list
				for (JCommandButton top : topButtons)
					top.setState(ElementState.MEDIUM, true);
				for (JCommandButton med : mediumButtons)
					med.setState(ElementState.SMALL, true);
				for (JCommandButton low : lowButtons)
					low.setState(ElementState.SMALL, true);
				break;

			case HIGH_TO_LOW:
				// put all buttons to low list
				for (JCommandButton top : topButtons)
					top.setState(ElementState.SMALL, true);
				for (JCommandButton med : mediumButtons)
					med.setState(ElementState.SMALL, true);
				for (JCommandButton low : lowButtons)
					low.setState(ElementState.SMALL, true);
				break;
			}

			Map<ElementState, java.util.List<JCommandButton>> buttonStateMap = new HashMap<ElementState, java.util.List<JCommandButton>>();
			buttonStateMap.put(ElementState.BIG,
					new LinkedList<JCommandButton>());
			buttonStateMap.put(ElementState.MEDIUM,
					new LinkedList<JCommandButton>());
			buttonStateMap.put(ElementState.SMALL,
					new LinkedList<JCommandButton>());

			for (JCommandButton top : topButtons)
				buttonStateMap.get(top.getState()).add(top);
			for (JCommandButton med : mediumButtons)
				buttonStateMap.get(med.getState()).add(med);
			for (JCommandButton low : lowButtons)
				buttonStateMap.get(low.getState()).add(low);

			// start from BIGs
			for (JCommandButton big : buttonStateMap.get(ElementState.BIG)) {
				big.setBounds(x, ins.top, getPreferredWidth(big),
						availableHeight);
				x += getPreferredWidth(big);
				x += gap;
			}

			int medSize = buttonStateMap.get(ElementState.MEDIUM).size();
			if (medSize > 0) {
				// try to move buttons from small to medium to make
				// three-somes.
				while (((buttonStateMap.get(ElementState.MEDIUM).size() % 3) != 0)
						&& (buttonStateMap.get(ElementState.SMALL).size() > 0)) {
					JCommandButton low = buttonStateMap.get(ElementState.SMALL)
							.get(0);
					buttonStateMap.get(ElementState.SMALL).remove(low);
					low.setState(ElementState.MEDIUM, true);
					buttonStateMap.get(ElementState.MEDIUM).add(low);
				}
			}

			// at this point, mediumButtons list contains either
			// threesomes, or there are no buttons in lowButtons.
			int index3 = 0;
			int maxWidth3 = 0;
			Set<JCommandButton> threesome = new HashSet<JCommandButton>();
			for (JCommandButton medium : buttonStateMap
					.get(ElementState.MEDIUM)) {
				int medWidth = getPreferredWidth(medium);
				maxWidth3 = Math.max(maxWidth3, medWidth);

				medium.setBounds(x, ins.top + index3 * (availableHeight) / 3,
						medWidth, (availableHeight) / 3 - 1);
				threesome.add(medium);

				index3++;
				if (index3 == 3) {
					// last button in threesome
					for (JCommandButton button : threesome) {
						Rectangle bounds = button.getBounds();
						button.setBounds(bounds.x, bounds.y, maxWidth3,
								bounds.height);
					}

					index3 = 0;
					x += maxWidth3;
					x += gap;
					maxWidth3 = 0;
					threesome.clear();
				}
			}
			// at this point, maxWidth3 may be non-null. We can safely
			// add it, since in this case there will be no buttons
			// left in lowButtons
			x += maxWidth3;
			if (maxWidth3 > 0)
				x += gap;

			index3 = 0;
			maxWidth3 = 0;
			for (JCommandButton small : buttonStateMap.get(ElementState.SMALL)) {
				int lowWidth = getPreferredWidth(small);
				maxWidth3 = Math.max(maxWidth3, lowWidth);
				small.setBounds(x, ins.top + index3 * (availableHeight) / 3,
						lowWidth, (availableHeight) / 3 - 1);
				threesome.add(small);

				index3++;
				if (index3 == 3) {
					// last button in threesome
					for (JCommandButton button : threesome) {
						Rectangle bounds = button.getBounds();
						button.setBounds(bounds.x, bounds.y, maxWidth3,
								bounds.height);
					}

					index3 = 0;
					x += maxWidth3;
					x += gap;
					maxWidth3 = 0;
					threesome.clear();
				}
			}
			x += maxWidth3;
			if (maxWidth3 > 0)
				x += gap;

			// At this point there may be some pixels left to the right.
			// We need to shift everything to the right for
			// center-alignment.
			int shiftX = (c.getWidth() - x) / 2;
			if (controlPanel.hasRibbonGalleries()) {
				int galleryCount = controlPanel.getRibbonGalleriesCount();
				int delta = 0;
				if (shiftX < 0) {
					// need to remove some pixels from galleries
					delta = -2
							* (int) Math.ceil((double) (-shiftX)
									/ (double) galleryCount);
				} else {
					// need to add pixels to galleries
					delta = 2 * (int) Math.ceil((double) (shiftX)
							/ (double) galleryCount);
				}

				int totalDelta = 0;
				for (JRibbonGallery top : topGalleries) {
					Rectangle bounds = top.getBounds();
					top.setBounds(bounds.x + totalDelta, bounds.y, bounds.width
							+ delta, bounds.height);
					totalDelta += delta;
				}
				for (JRibbonGallery med : mediumGalleries) {
					Rectangle bounds = med.getBounds();
					med.setBounds(bounds.x + totalDelta, bounds.y, bounds.width
							+ delta, bounds.height);
					totalDelta += delta;
				}
				for (JRibbonGallery low : lowGalleries) {
					Rectangle bounds = low.getBounds();
					low.setBounds(bounds.x + totalDelta, bounds.y, bounds.width
							+ delta, bounds.height);
					totalDelta += delta;
				}

				for (JPanel panel : controlPanel.getPanels()) {
					Rectangle bounds = panel.getBounds();
					panel.setBounds(bounds.x + 2 * shiftX, bounds.y,
							bounds.width, bounds.height);
				}

				for (JCommandButton top : topButtons) {
					Rectangle bounds = top.getBounds();
					top.setBounds(bounds.x + 2 * shiftX, bounds.y,
							bounds.width, bounds.height);
				}
				for (JCommandButton med : mediumButtons) {
					Rectangle bounds = med.getBounds();
					med.setBounds(bounds.x + 2 * shiftX, bounds.y,
							bounds.width, bounds.height);
				}
				for (JCommandButton low : lowButtons) {
					Rectangle bounds = low.getBounds();
					low.setBounds(bounds.x + 2 * shiftX, bounds.y,
							bounds.width, bounds.height);
				}
			} else {
				if (shiftX > 0) {
					// see if have galleries
					for (JPanel panel : controlPanel.getPanels()) {
						Rectangle bounds = panel.getBounds();
						panel.setBounds(bounds.x + shiftX, bounds.y,
								bounds.width, bounds.height);
					}

					for (JCommandButton top : topButtons) {
						Rectangle bounds = top.getBounds();
						top.setBounds(bounds.x + shiftX, bounds.y,
								bounds.width, bounds.height);
					}
					for (JCommandButton med : mediumButtons) {
						Rectangle bounds = med.getBounds();
						med.setBounds(bounds.x + shiftX, bounds.y,
								bounds.width, bounds.height);
					}
					for (JCommandButton low : lowButtons) {
						Rectangle bounds = low.getBounds();
						low.setBounds(bounds.x + shiftX, bounds.y,
								bounds.width, bounds.height);
					}
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 *      javax.swing.JComponent)
	 */
	@Override
	public void paint(Graphics g, JComponent c) {
		Graphics2D graphics = (Graphics2D) g.create();
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_OFF);

		this.paintBandBackground(graphics, new Rectangle(0, 0, c.getWidth(), c
				.getHeight()));

		graphics.dispose();
	}

	/**
	 * Paints band background.
	 * 
	 * @param graphics
	 *            Graphics context.
	 * @param toFill
	 *            Rectangle for the background.
	 */
	protected void paintBandBackground(Graphics graphics, Rectangle toFill) {
		graphics.setColor(controlPanel.getBackground());
		graphics.fillRect(toFill.x, toFill.y, toFill.width, toFill.height);
	}

	/**
	 * Returns the preferred width of <code>this</code> control panel in the
	 * specified collapse kind.
	 * 
	 * @param collapseKind
	 *            Collapse kind.
	 * @return Preferred width of <code>this</code> control panel in the
	 *         specified collapse kind.
	 */
	public int getPreferredWidth(RibbonBandCollapseKind collapseKind,
			int availableHeight) {
		int panelWidth = 0;

		// ribbon galleries
		java.util.List<JRibbonGallery> topGalleries = controlPanel
				.getRibbonGalleries(RibbonElementPriority.TOP);
		java.util.List<JRibbonGallery> mediumGalleries = controlPanel
				.getRibbonGalleries(RibbonElementPriority.MEDIUM);
		java.util.List<JRibbonGallery> lowGalleries = controlPanel
				.getRibbonGalleries(RibbonElementPriority.LOW);

		java.util.List<JRibbonGallery> tempTopGalleries = new LinkedList<JRibbonGallery>();
		java.util.List<JRibbonGallery> tempMediumGalleries = new LinkedList<JRibbonGallery>();
		java.util.List<JRibbonGallery> tempLowGalleries = new LinkedList<JRibbonGallery>();

		switch (collapseKind) {
		case NONE:
			// put all galleries to top
			for (JRibbonGallery top : topGalleries)
				tempTopGalleries.add(top);
			for (JRibbonGallery med : mediumGalleries)
				tempTopGalleries.add(med);
			for (JRibbonGallery low : lowGalleries)
				tempTopGalleries.add(low);
			break;

		case LOW_TO_MID:
			// put all low priority galleries to medium list
			for (JRibbonGallery top : topGalleries)
				tempTopGalleries.add(top);
			for (JRibbonGallery med : mediumGalleries)
				tempTopGalleries.add(med);
			for (JRibbonGallery low : lowGalleries)
				tempMediumGalleries.add(low);
			break;

		case MID_TO_MID:
			// put all low / medium priority galleries to medium list
			for (JRibbonGallery top : topGalleries)
				tempTopGalleries.add(top);
			for (JRibbonGallery med : mediumGalleries)
				tempMediumGalleries.add(med);
			for (JRibbonGallery low : lowGalleries)
				tempMediumGalleries.add(low);
			break;

		case LOW_TO_LOW:
			// put all low priority galleries to low list
			// put all medium priority galleries to medium list
			for (JRibbonGallery top : topGalleries)
				tempTopGalleries.add(top);
			for (JRibbonGallery med : mediumGalleries)
				tempMediumGalleries.add(med);
			for (JRibbonGallery low : lowGalleries)
				tempLowGalleries.add(low);
			break;

		case MID_TO_LOW:
			// put all medium / low priority galleries to low list
			for (JRibbonGallery top : topGalleries)
				tempTopGalleries.add(top);
			for (JRibbonGallery med : mediumGalleries)
				tempLowGalleries.add(med);
			for (JRibbonGallery low : lowGalleries)
				tempLowGalleries.add(low);
			break;

		case HIGH_TO_MID:
			// put all medium / low priority galleries to low list
			// put all top priority galleries to medium list
			for (JRibbonGallery top : topGalleries)
				tempMediumGalleries.add(top);
			for (JRibbonGallery med : mediumGalleries)
				tempLowGalleries.add(med);
			for (JRibbonGallery low : lowGalleries)
				tempLowGalleries.add(low);
			break;

		case HIGH_TO_LOW:
			// put all galleries to low list
			for (JRibbonGallery top : topGalleries)
				tempLowGalleries.add(top);
			for (JRibbonGallery med : mediumGalleries)
				tempLowGalleries.add(med);
			for (JRibbonGallery low : lowGalleries)
				tempLowGalleries.add(low);
			break;
		}

		int gap = getLayoutGap();
		Insets ins = this.controlPanel.getInsets();
		int galleryAvailableHeight = availableHeight - ins.top - ins.bottom;
		for (JRibbonGallery top : tempTopGalleries)
			panelWidth += (top.getPreferredWidth(ElementState.BIG,
					galleryAvailableHeight) + gap);
		for (JRibbonGallery med : tempMediumGalleries)
			panelWidth += (med.getPreferredWidth(ElementState.MEDIUM,
					galleryAvailableHeight) + gap);
		for (JRibbonGallery low : tempLowGalleries)
			panelWidth += (low.getPreferredWidth(ElementState.SMALL,
					galleryAvailableHeight) + gap);

		// panels
		for (JPanel panel : controlPanel.getPanels())
			panelWidth += panel.getPreferredSize().width;

		// ribbon buttons
		java.util.List<JCommandButton> topButtons = controlPanel
				.getRibbonButtons(RibbonElementPriority.TOP);
		java.util.List<JCommandButton> mediumButtons = controlPanel
				.getRibbonButtons(RibbonElementPriority.MEDIUM);
		java.util.List<JCommandButton> lowButtons = controlPanel
				.getRibbonButtons(RibbonElementPriority.LOW);

		java.util.List<JCommandButton> tempTopButtons = new LinkedList<JCommandButton>();
		java.util.List<JCommandButton> tempMediumButtons = new LinkedList<JCommandButton>();
		java.util.List<JCommandButton> tempLowButtons = new LinkedList<JCommandButton>();

		Map<ElementState, java.util.List<JCommandButton>> buttonStateMap = new HashMap<ElementState, java.util.List<JCommandButton>>();
		buttonStateMap.put(ElementState.BIG, new LinkedList<JCommandButton>());
		buttonStateMap.put(ElementState.MEDIUM,
				new LinkedList<JCommandButton>());
		buttonStateMap
				.put(ElementState.SMALL, new LinkedList<JCommandButton>());

		// store current button state
		for (JCommandButton top : topButtons)
			buttonStateMap.get(top.getState()).add(top);
		for (JCommandButton med : mediumButtons)
			buttonStateMap.get(med.getState()).add(med);
		for (JCommandButton low : lowButtons)
			buttonStateMap.get(low.getState()).add(low);

		switch (collapseKind) {
		case NONE:
			// put all buttons to top
			for (JCommandButton top : topButtons)
				tempTopButtons.add(top);
			for (JCommandButton med : mediumButtons)
				tempTopButtons.add(med);
			for (JCommandButton low : lowButtons)
				tempTopButtons.add(low);
			break;

		case LOW_TO_MID:
			// put all low priority buttons to medium list
			for (JCommandButton top : topButtons)
				tempTopButtons.add(top);
			for (JCommandButton med : mediumButtons)
				tempTopButtons.add(med);
			for (JCommandButton low : lowButtons)
				tempMediumButtons.add(low);
			break;

		case MID_TO_MID:
			// put all low / medium priority buttons to medium list
			for (JCommandButton top : topButtons)
				tempTopButtons.add(top);
			for (JCommandButton med : mediumButtons)
				tempMediumButtons.add(med);
			for (JCommandButton low : lowButtons)
				tempMediumButtons.add(low);
			break;

		case LOW_TO_LOW:
			// put all low priority buttons to low list
			// put all medium priority buttons to medium list
			for (JCommandButton top : topButtons)
				tempTopButtons.add(top);
			for (JCommandButton med : mediumButtons)
				tempMediumButtons.add(med);
			for (JCommandButton low : lowButtons)
				tempLowButtons.add(low);
			break;

		case MID_TO_LOW:
			// put all medium / low priority buttons to low list
			for (JCommandButton top : topButtons)
				tempTopButtons.add(top);
			for (JCommandButton med : mediumButtons)
				tempLowButtons.add(med);
			for (JCommandButton low : lowButtons)
				tempLowButtons.add(low);
			break;

		case HIGH_TO_MID:
			// put all medium / low priority buttons to low list
			// put all top priority buttons to medium list
			for (JCommandButton top : topButtons)
				tempMediumButtons.add(top);
			for (JCommandButton med : mediumButtons)
				tempLowButtons.add(med);
			for (JCommandButton low : lowButtons)
				tempLowButtons.add(low);
			break;

		case HIGH_TO_LOW:
			// put all buttons to low list
			for (JCommandButton top : topButtons)
				tempLowButtons.add(top);
			for (JCommandButton med : mediumButtons)
				tempLowButtons.add(med);
			for (JCommandButton low : lowButtons)
				tempLowButtons.add(low);
			break;
		}

		for (JCommandButton top : tempTopButtons)
			top.setState(ElementState.BIG, false);
		for (JCommandButton med : tempMediumButtons)
			med.setState(ElementState.MEDIUM, false);
		for (JCommandButton low : tempLowButtons)
			low.setState(ElementState.SMALL, false);

		panelWidth += this.getWidth(tempTopButtons, tempMediumButtons,
				tempLowButtons);

		// restore buttons to their original state
		for (Map.Entry<ElementState, java.util.List<JCommandButton>> stateEntry : buttonStateMap
				.entrySet()) {
			for (JCommandButton button : stateEntry.getValue())
				button.setState(stateEntry.getKey(), false);
		}

		panelWidth += (ins.left + ins.right);

		// System.out.println("Collapse " + collapseKind.name() +
		// // " [" +
		// // tempTopButtons.size() + ", " + tempMediumButtons.size() + ", " +
		// // tempLowButtons.size() + "], " +
		// " width is "
		// + panelWidth);

		return panelWidth;
	}

	/**
	 * Returns the total width of the specified buttons.
	 * 
	 * @param bigButtons
	 *            List of buttons in big display state.
	 * @param mediumButtons
	 *            List of buttons in medium display state.
	 * @param smallButtons
	 *            List of buttons in small display state.
	 * @return Total width of the specified buttons.
	 */
	protected int getWidth(java.util.List<JCommandButton> bigButtons,
			java.util.List<JCommandButton> mediumButtons,
			java.util.List<JCommandButton> smallButtons) {
		Insets ins = this.controlPanel.getInsets();
		int gap = getLayoutGap();

		int result = ins.left;
		for (JCommandButton top : bigButtons) {
			result += getPreferredWidth(top);
			result += gap;
		}

		int medSize = mediumButtons.size();
		if (medSize > 0) {
			// try to move buttons from low to med to make
			// three-somes.
			while (((mediumButtons.size() % 3) != 0)
					&& (smallButtons.size() > 0)) {
				JCommandButton low = smallButtons.remove(0);
				low.setState(ElementState.MEDIUM, false);
				mediumButtons.add(low);
			}
		}

		// at this point, mediumButtons list contains either
		// threesomes, or there are no buttons in lowButtons.
		int index3 = 0;
		int maxWidth3 = 0;
		for (JCommandButton medium : mediumButtons) {
			int medWidth = getPreferredWidth(medium);
			maxWidth3 = Math.max(maxWidth3, medWidth);
			index3++;

			if (index3 == 3) {
				// last button in threesome
				index3 = 0;
				result += maxWidth3;
				result += gap;
				maxWidth3 = 0;
			}
		}
		// at this point, maxWidth3 may be non-zero. We can safely
		// add it, since in this case there will be no buttons
		// left in lowButtons
		result += maxWidth3;
		if (maxWidth3 > 0)
			result += gap;

		index3 = 0;
		maxWidth3 = 0;
		for (JCommandButton low : smallButtons) {
			int lowWidth = getPreferredWidth(low);
			maxWidth3 = Math.max(maxWidth3, lowWidth);
			index3++;

			if (index3 == 3) {
				// last button in threesome
				index3 = 0;
				result += maxWidth3;
				result += gap;
				maxWidth3 = 0;
			}
		}
		// at this point, maxWidth3 may be non-zero. We can safely
		// add it, since in this case there will be no buttons left
		result += maxWidth3;
		result += ins.right;

		return result;
	}

	private int getPreferredWidth(JCommandButton jrb) {
		CommandButtonUI ui = jrb.getUI();
		Dimension uiPref = ui.getPreferredSize(jrb);
		return uiPref.width;
	}

	protected int getLayoutGap() {
		return 4;
	}
}
