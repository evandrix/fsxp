package test;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.*;

import org.jvnet.flamingo.common.JButtonStrip;

public class ButtonStripTest extends JFrame {
	public ButtonStripTest() {
		this.setLayout(new FlowLayout());

		JButtonStrip fontSortStrip = new JButtonStrip();
		AbstractButton button = this.getIconButton(TestImageCreator
				.getFontSortIcon(), false, false, false);
		AbstractButton button2 = this.getIconButton(TestImageCreator
				.getFontSortIcon(), false, false, false);
		// button.setBorder(new LineBorder(Color.red, 2));

		fontSortStrip.add(button);
		fontSortStrip.add(button2);
		this.add(fontSortStrip);

		this.pack();
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private AbstractButton getIconButton(Icon icon, boolean isToggle,
			boolean isSelected, boolean hasPopup) {
		AbstractButton button = isToggle ? new JToggleButton(icon)
				: new JButton(icon);
		if (isSelected)
			button.setSelected(true);
		button.setPreferredSize(new Dimension(icon.getIconWidth(), icon
				.getIconHeight()));
		return button;
	}

	public static void main(String[] args) {
		ButtonStripTest bst = new ButtonStripTest();
		bst.setVisible(true);
	}
}
